<?php
/**
 * PIM Search Filters ACF Settings.
 *
 * @package    Akeneo Plugin
 * @subpackage ACF
 * @since      1.0.0
 */

if ( function_exists( 'acf_add_options_sub_page' ) ) {
	acf_add_options_sub_page(
		array(
			'page_title'  => 'PIM Search Filters',
			'menu_title'  => 'PIM Search Filters',
			'menu_slug'   => 'mbek-filters-settings',
			'capability'  => 'manage_options',
			'redirect'    => false,
			'parent_slug' => 'mbek',
		)
	);
}
if ( function_exists( 'acf_add_options_sub_page' ) ) {
	add_action(
		'acf/init',
		function () {
			$allowed_pim_types = array(
				'pim_catalog_simpleselect',
				'pim_catalog_multiselect',
			);
			$main_attributes   = get_option( MBEK_ATTRIBUTES );
			$mapped_attributes = get_option( MBEK_ATTRIBUTE_MAPS );

			$filtered_attributes = array();
			if ( is_array( $main_attributes ) && is_array( $mapped_attributes ) ) {
				$filtered_attributes = array_filter(
					$main_attributes,
					function ( $n ) use ( $allowed_pim_types, $mapped_attributes ) {
						if ( ! is_array( $n ) || empty( $n['type'] ) || empty( $n['code'] ) ) {
							return false;
						}
						if ( ! in_array( $n['type'], $allowed_pim_types, true ) ) {
							return false;
						}
						$code = $n['code'];
						if ( ! isset( $mapped_attributes[ $code ] ) ) {
							return false;
						}
						if ( is_array( $mapped_attributes[ $code ] ) ) {
							return ! empty( $mapped_attributes[ $code ]['value'] );
						}

						return ! empty( $mapped_attributes[ $code ] );
					}
				);
			}

			$attr_types = array();
			$pim_field_options = array();

			foreach ( $filtered_attributes as $attribute_label => $attribute_data ) {
				if ( ! is_array( $attribute_data ) ) {
					continue;
				}
				if ( ! empty( $attribute_data['type'] ) ) {
					$attr_types[ $attribute_data['type'] ] = $attribute_data['type'];
				}
				$label = '';
				if ( isset( $attribute_data['labels']['en_US'] ) && '' !== $attribute_data['labels']['en_US'] ) {
					$label = $attribute_data['labels']['en_US'];
				} elseif ( isset( $attribute_data['labels'] ) && is_array( $attribute_data['labels'] ) && ! empty( $attribute_data['labels'] ) ) {
					$first_label = reset( $attribute_data['labels'] );
					if ( ! empty( $first_label ) ) {
						$label = $first_label;
					}
				} elseif ( isset( $attribute_data['reference_data_name'] ) && '' !== $attribute_data['reference_data_name'] ) {
					$label = $attribute_data['reference_data_name'];
				} elseif ( isset( $attribute_data['code'] ) && '' !== $attribute_data['code'] ) {
					$label = $attribute_data['code'];
				} else {
					$label = (string) $attribute_label;
				}
				$pim_field_options[ $attribute_label ] = $label;
			}

			asort( $pim_field_options );
			$search_filters_key      = 'field_mbek_filter_1';
			$search_filter_label_key = 'field_mbek_filter_2';
			$search_filter_pim_key   = 'field_mbek_filter_3';

			if ( function_exists( 'acf_add_local_field_group' ) ) {
				acf_add_local_field_group(
					array(
						'key'                   => 'group_mbek_1',
						'title'                 => 'Search Filters',
						'fields'                => array(
							array(
								'key'               => $search_filters_key,
								'label'             => 'PIM Search Filters',
								'name'              => 'mbek_pim_search_filters',
								'aria-label'        => '',
								'type'              => 'repeater',
								'instructions'      => '',
								'required'          => 0,
								'conditional_logic' => 0,
								'wrapper'           => array(
									'width' => '',
									'class' => '',
									'id'    => '',
								),
								'layout'            => 'block',
								'pagination'        => 0,
								'min'               => 0,
								'max'               => 0,
								'collapsed'         => '',
								'button_label'      => 'Add Filter',
								'rows_per_page'     => defined( 'MBEK_CHUNK_DEFAULT' ) ? MBEK_CHUNK_DEFAULT : 20,
								'sub_fields'        => array(
									array(
										'key'               => $search_filter_label_key,
										'label'             => 'Label',
										'name'              => 'mbek_pim_search_label',
										'aria-label'        => '',
										'type'              => 'text',
										'instructions'      => '',
										'required'          => 0,
										'conditional_logic' => 0,
										'wrapper'           => array(
											'width' => '100',
											'class' => '',
											'id'    => '',
										),
										'default_value'     => '',
										'maxlength'         => '',
										'placeholder'       => '',
										'prepend'           => '',
										'append'            => '',
										'parent_repeater'   => $search_filters_key,
									),
									array(
										'key'               => $search_filter_pim_key,
										'label'             => 'PIM Field',
										'name'              => 'mbek_pim_search_field_ref',
										'aria-label'        => '',
										'type'              => 'select',
										'choices'           => $pim_field_options,
										'allow_null'        => 1,
										'instructions'      => '',
										'required'          => 0,
										'conditional_logic' => 0,
										'wrapper'           => array(
											'width' => '100',
											'class' => '',
											'id'    => '',
										),
										'default_value'     => '',
										'maxlength'         => '',
										'placeholder'       => '',
										'prepend'           => '',
										'append'            => '',
										'parent_repeater'   => $search_filters_key,
									),
								),
							),
						),
						'location'              => array(
							array(
								array(
									'param'    => 'options_page',
									'operator' => '==',
									'value'    => 'mbek-filters-settings',
								),
							),
						),
						'menu_order'            => 0,
						'position'              => 'normal',
						'style'                 => 'default',
						'label_placement'       => 'top',
						'instruction_placement' => 'label',
						'hide_on_screen'        => '',
						'active'                => true,
						'description'           => '',
						'show_in_rest'          => 0,
					)
				);
			}
		}
	);
}
