=== Middleby Akeneo ===
Contributors: wisersites
Tags: Akeneo, Middleby, PIM
Requires at least: 6.6
Tested up to: 6.6
Stable tag: 1.0.25
Requires PHP: 8.1
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

PIM Integration from Akeneo

== Description ==

Plugin to Integrate the Akeneo PIM. Sync the product and or accessory data from PIM into the wordpress products.

== Installation ==

This section describes how to install the plugin and get it working.

1. Upload `middleby-akeneo` folder to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Run the Setup Wizard (coming)

== Frequently Asked Questions ==

== Screenshots ==


== Changelog ==

= 1.0.31 =
* Update for WooTab plugin integration for the 15 new PIM product feature fields.

= 1.0.30 =
* Start work on creation of new Filters.
* Coding Standards for Wordpress and TODO list for en_US.
* Replace Hard coding of en_US within Settings.
* Update for WooTab plugin integration for the 15 new PIM product feature fields.

= 1.0.29 =
* Remove E_NOTICE output.

= 1.0.28 =
* Bug fix for issues with the sub cron parts from pull_products that calls pull_assets and pull_resources.

= 1.0.27 =
* Can now exclude accessories from PIM if the Accessory flag is set and no post_type is set for accessories.
* When updating PIM categories: Will now set features

= 1.0.26 =
* Update for delete cpt if use only uuid to delete any cpt without uuid
* Update list product option url
* Delete CPT for assets if no PIM assets exists
* Update the Readme file

= 1.0.25 =
* Adding two new ajax methods for the mapping
* Replace magic number with DEFINE


= 1.0.24 =
* Update to dropdown for asset mapping 'family'
* Update cron tools so they require nonce
* Update cron.js - code refactoring
* Add clearing of pim_data and the CPT used for products.
* Also add new setting to limit to one category for products.
* Add clearing of pim_asset table when purging pim_data.
* Add nonce checks for admin ajax calls.
* Add confirm to some of the Tools.

= 1.0.23 =
* Updating code for check photos to deal with non repeater fields


= 1.0.22 =
* Turning off the updating of category data from PIM
* Add screen in admin for checking that all CPT have featured photos


= 1.0.21 =
* Woocommerce Action Schedule updated to version 3.7.2
* Tabulator list product view now has pagination and filtering for name, model and uuid columns
* Documentation Updates
* Setup Grunt and readme
* Updating Cron task

= 1.0.20 =
* Update PHP Docs
* Cleanup and rename menu items
* Add page for Accessories
* Update woo action scheduler to v3.7.2
* Update Tabulator for list Products to add filtering for Title, Model and UUID
* Add Pagination to List Products (Tabulator)