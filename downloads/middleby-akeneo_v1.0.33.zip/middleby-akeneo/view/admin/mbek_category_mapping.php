<?php
require_once MBEK_PLUGIN_DIR . '/lib/class.akeneo.php';
require_once MBEK_PLUGIN_DIR . '/lib/class.mbek-products.php';

$fields = array();
$akeneo = new \Middleby\Akeneo\MBEK_Akeneo();
$akeneo->start_client();
$categories = $akeneo->get_saved_brand_categories();
$test_data  = unserialize( $categories[1]['data'] );

if ( ! empty( $categories ) ) {
	foreach ( $categories as $cat_data ) {
		$filtered = array_filter( unserialize( $cat_data['data'] ), function ( $key ) {
			return preg_match( '%website_series_*%', $key );
		}, ARRAY_FILTER_USE_KEY );
		foreach ( $filtered as $filter_key => $filter_data ) {
			if ( ! isset( $fields[ $filter_key ] ) ) {
				$attribute             = $akeneo->get_attribute( $filter_key );
				$fields[ $filter_key ] = ( ! empty( $attribute ) ? $attribute : $filter_key );
			}
		}
	}
}
?>
<div class="wrap">
	<h1>Akeneo API Category Mapping</h1>
	<div class="container">
		<?php
		if ( isset( $_REQUEST['success'] ) && $_REQUEST['success'] ) {
			?>
			<div class="col-sm-6">
				<div class="alert alert-success" role="alert">
					<h4 class="alert-heading">Success!</h4>
					<hr>
					<p class="mb-0">Mapping Saved Successfully!</p>
				</div>
			</div>
			<?php
		}
		?>
		<form method="post" class="row g-3" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="save_mbek_brand_categories"/>
			<input type="hidden" name="mbek_nonce" value="<?php echo wp_create_nonce( 'mbek_nonce' ); ?>"/>
			<?php
			echo '<pre>' . print_r( $categories, true ) . '</pre>';
			echo '<pre>' . print_r( $fields, true ) . '</pre>';
			if ( ! empty( $fields ) ) {
				foreach ( $fields as $field_key ) {
					echo '<div class="col-md-12">';
					echo '<label for="' . $field_key . '" class="form-label">' . $field_key . '</label>';
					echo '</div>';
				}
			}

			?>
			<div class="col-12">
				<button type="submit" class="btn btn-primary">Save</button>
			</div>
		</form>
	</div>

</div>
