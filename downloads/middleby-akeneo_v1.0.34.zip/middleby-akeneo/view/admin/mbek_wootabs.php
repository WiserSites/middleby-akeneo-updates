<div class="wrap">
    <h1>Akeneo Wootabs Mapping</h1>
    <div class="container">
        <div class="row">
            <div class="col-md-6">


		<?php
		/**
		 * Wootabs Mapping Page
		 */
		if ( ! empty( $_REQUEST['save'] ) && $_REQUEST['save'] === 'true' ) {
			if ( isset( $_REQUEST['mbek_nonce'] ) && wp_verify_nonce( $_REQUEST['mbek_nonce'], 'mbek_nonce' ) ) {
                $woo_options = array();
                $fids = array_filter( array_map( 'trim', $_REQUEST['woo_tab_field_id'] ) );
				$opts = array_filter( array_map( 'trim', $_REQUEST['woo_tab_option'] ) );
                $vals = array_filter( array_map( 'trim', $_REQUEST['woo_tab_value'] ) );

                foreach ( $fids as $fkey => $fid ) {
                    $woo_options[] = array(
                        'id'     => $fid,
                        'option' => $opts[$fkey],
                        'value'  => $vals[$fkey],
                    );
                }
				update_option( MBEK_WOOTABS, $woo_options );
                update_option( MBEK_WOOTAB_FIELD_ID, $_REQUEST['woo_tab_field_id'] );
				?>
                <div class="col-sm-6">
                    <div class="alert alert-success" role="alert">
                        <h4 class="alert-heading">Success!</h4>
                        <hr>
                        <p class="mb-0">Mapping Saved Successfully!</p>
                    </div>
                </div>
				<?php
			}
		}
		$main_attributes = get_option( MBEK_ATTRIBUTES );
		$akeneo = new \Middleby\Akeneo\MBEK_Akeneo();
		$akeneo->start_client();
		$attributes      = array();
		$family          = $akeneo->get_family();
		$options         = get_option( MBEK_WOOTABS );
        $field_id_opt    = get_option( MBEK_WOOTAB_FIELD_ID );
		$products = new \Middleby\Akeneo\MBEK_Products();
		$test_fields = $products->get_acf_fields();

//        echo '<pre>$test_fealds: '.print_r($test_fields, true).'</pre>';

		if ( ! empty( $test_fields ) ) {
			foreach ( $test_fields as $field ) {
				$fields[$field['name']] = array(
					'name' => $field['name'],
					'type' => $field['type'],
				);
			}

		}
        $has_pim_feature_fields = ( isset( $fields['pim_product_feature_1'] ) ) ? true : false;
        if ( $has_pim_feature_fields ) {
            for ( $i = 1; $i <= 15; $i++ ) {
                if ( isset( $fields["pim_product_feature_$i"] ) ) {
                    unset( $fields["pim_product_feature_$i"] );
                }
            }
        }
        if ( $has_pim_feature_fields ) {
            $fields['pim_product_feature_fields-NEW'] = array(
                'name' => 'pim_product_feature_fields-NEW',
                'type' => 'text',
            );
        }
		if ( $family ) {
			$attributes = $akeneo->get_attribute_wp_options();
			if ( ! $attributes ) {
				$akeneo->save_attributes( $family );
				$attributes = $akeneo->get_attribute_wp_options();
			}

		}
        $wootab_fields = get_posts(
            array(
                'numberposts' => -1,
                'post_type'   => 'extra_product_tab',
                'post_status' => 'publish',
            )
        );
		?>

        <form method="post" class="row g-3"
              action="<?php echo esc_url( admin_url( 'admin.php' ) ); ?>?page=mbek-woo-tabs">
            <input type="hidden" name="mbek_nonce" value="<?php echo wp_create_nonce( 'mbek_nonce' ); ?>">
            <input type="hidden" name="page" value="mbek-woo-tabs">
            <input type="hidden" name="save" value="true">
            <fieldset class="row g-3">
                <legend>Add New Mapping</legend>
                <div class="col-md-3">
                    <select name="woo_tab_field_id[0]">
                        <option></option>
                        <?php
                        if ( ! empty( $wootab_fields ) ) {
                            foreach ( $wootab_fields as $wootab_data ) {
                                echo '<option value="' . $wootab_data->ID . '"';
                                echo '>' . $wootab_data->post_title . '</option>';
                            }
                        }
                        ?>
                    </select>
                </div>
                <div class="col-md-4">
                    <input class="form-control" type="text" name="woo_tab_option[0]" value="">
                </div>
                <div class="col-md-4">
                    <?php
                    echo '<select name="woo_tab_value[0]" class="form-select">';
                    echo '<option></option>';
                    foreach ( $fields as $field ) {
                        echo '<option value="' . $field['name'] . '"';
                        echo '>' . $field['name'] . '</option>';
                    }
                    echo '</select>';
                    ?>
                </div>
            </fieldset>
            <fieldset class="row g-3">
                <legend>Current Mappings</legend>
			<?php
			if ( ! empty( $options ) ) {
				//echo '<pre>'.print_r( $options, true ).'</pre>';
				foreach ( $options as $key => $option ) {
                    $count = $key + 1;
					?>
                    <div class="col-md-3">
                        <select name="woo_tab_field_id[<?php echo $count; ?>]">
                            <option></option>
                            <?php
                            if ( ! empty( $wootab_fields ) ) {
                                foreach ( $wootab_fields as $wootab_data ) {
                                    echo '<option value="' . $wootab_data->ID . '"';
                                    if ( $option['id'] == $wootab_data->ID ) {
                                        echo ' selected';
                                    }
                                    echo '>' . $wootab_data->post_title . '</option>';
                                }
                            }
                            ?>
                        </select>
                    </div>
                    <div class="col-md-4">
                        <input class="form-control" type="text" name="woo_tab_option[<?php echo $count; ?>]" value="<?php echo $option['option']; ?>">
                    </div>
                    <div class="col-md-5">
						<?php
                        echo '<select name="woo_tab_value['.$count.']" class="form-select">';
                        echo '<option></option>';
                        foreach ( $fields as $field ) {
                            echo '<option value="' . $field['name'] . '"';
                            if ($field['name'] === $option['value']) {
                                echo ' selected';
                            }
                            echo '>' . $field['name'] . '</option>';
                        }
                        echo '</select>';
						?>
                    </div>
					<?php
				}
			}
			?>
            </fieldset>
            <div class="col-12">
                <button type="submit" class="btn btn-primary">Save</button>
            </div>
        </form>

            </div>
        </div>
    </div>
</div>

