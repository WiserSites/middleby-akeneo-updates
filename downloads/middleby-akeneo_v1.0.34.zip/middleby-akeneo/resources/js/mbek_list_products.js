'use strict';

// import {TabulatorFull as Tabulator} from "./tabulator.min";

var table = new Tabulator("#mbek_products", {
    ajaxURL: mbek_lp_infos.ajax_url_for_data,
//                    height: "600px",
    layout: "fitColumns",
    placeholder: "No Data Set",
    pagination: true,
    paginationMode: "remote",
    paginationSive: 10,
    filterMode: "remote",
    columns: [
        {
            title: "ID", field: "id", sorter: "number", width: 100, formatter: function (cell, formatterParams) {
                var value = cell.getValue();
                return `<a target="_blank" href='${mbek_lp_infos.edit_url}${value}&action=edit&classic-editor'>${value}</a>`;
            }
        },
        {title: "Title", field: "title", sorter: "string", formatter: "html", headerFilter: "input"},
        {title: "Model", field: "model", sorter: "string", headerFilter: "input"},
        {title: "UUID", field: "uuid", sorter: "string", headerFilter: "input"},
        {
            title: "Option", field: "option", width: 150, formatter: function (cell, formatterParams) {
                var value = cell.getValue();
                let returnCode = '';
                if (mbek_lp_infos.use_only_uuid === 'true'){
                    returnCode = `<a target="_blank" href='${mbek_lp_infos.uuid_url}${value}'>Pull From PIM Data</a>`;
                } else {
                    returnCode = `<a target="_blank" href='${mbek_lp_infos.model_url}${value}'>Pull From PIM Data</a>`;
                }
                return returnCode;
            }
        },
        {
            title: "View", field: "view", width: 100, formatter: function (cell, formatterParams) {
                var value = cell.getValue();
                return `<a target="_blank" href='${value}'>View</a>`;
            }
        }
    ]
});
//trigger download of data.csv file
document.getElementById("download-csv").addEventListener("click", function () {
    table.download("csv", "data.csv");
});

//trigger download of data.json file
document.getElementById("download-json").addEventListener("click", function () {
    table.download("json", "data.json");
});