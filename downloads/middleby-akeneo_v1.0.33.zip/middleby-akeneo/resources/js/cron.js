'use strict';

const links = document.querySelectorAll('.cron_js_link');
const toolResults = document.getElementById('tool-results');

/**
 * Creates an HTML table with the given headers and data.
 *
 * @param {Array} headers - The array of table headers.
 * @param {Function} createRow - The function to create a table row from a JSON data item.
 * @param {Array} jsonData - The array of JSON data items to populate the table rows.
 * @return {HTMLElement} - The created table as a DIV element.
 */
function createTable(headers, createRow, jsonData) {
    const items = jsonData.map(createRow).join(' ');
    const html = `
        <table class="table">
            <thead>
                <tr>
                    ${headers.join('\n')}
                </tr>    
            </thead>
            <tbody>
                ${items}
            </tbody>
        </table>`;
    const myDiv = document.createElement('div');
    myDiv.innerHTML = html;
    return myDiv;
}

/**
 * Retrieves JSON data from a specified URL using the Fetch API.
 *
 * @param {string} url - The URL to fetch the JSON data from.
 * @param {string} [errorMsg='Something went wrong'] - The error message to display if the request fails.
 * @returns {Promise} - A Promise that resolves to the JSON data returned from the URL.
 * @throws {Error} - An error is thrown if the request fails or if the response status is not okay.
 */
const getJSON = function (url, errorMsg = 'Something went wrong') {
    const ajax_url = url + '&mbek_nonce=' + mbek_infos.nonce;
    return fetch(ajax_url).then(response => {
        if (!response.ok) throw new Error(`${errorMsg} (${response.status})`);

        return response.json();
    });
};
/**
 * Generate an HTML table to display products based on the provided JSON data
 *
 * @param {Array} jsonData - The JSON data containing product information
 * @returns {HTMLDivElement} - The HTML div element that contains the generated table
 */
const displayProducts = function (jsonData) {
    const headers = ['<th>UUID</th>', '<th>Name</th>', '<th>Updated</th>'];
    const createRow = product => `
        <tr>
            <th scope="row">${product.uuid}</th>
            <td>${product.values.product_name[0].data}</td>
            <td>${product.updated}</td>
        </tr>`;
    return createTable(headers, createRow, jsonData);
};
/**
 * Generate HTML table to display categories.
 *
 * @param {Object[]} jsonData - Array of category objects.
 * @param {string} jsonData[].code - The code of the category.
 * @param {string} jsonData[].labels.en_US - The name of the category.
 * @param {string} jsonData[].parent - The parent category.
 * @param {string} jsonData[].updated - The last updated timestamp of the category.
 * @returns {HTMLElement} - The HTML div element containing the table.
 */
const displayCategories = function (jsonData) {
    const headers = ['<th>Code</th>', '<th>Name</th>', '<th>Parent</th>', '<th>Updated</th>'];
    // TODO: en_US Needs Attention.
    const createRow = category => `
        <tr>
            <th scope="row">${category.code}</th>
            <td>${category.labels.en_US}</td>
            <td>${category.parent}</td>
            <td>${category.updated}</td>
        </tr>`;
    return createTable(headers, createRow, jsonData);
};
/**
 * This function takes a JSON data and creates a table displaying the resources.
 *
 * @param {Array} jsonData - The JSON data containing the resources information.
 * @return {HTMLElement} - The HTML element containing the table.
 */
const displayResources = function (jsonData) {
    const headers = ['<th>Code</th>', '<th>Code</th>', '<th>Updated</th>'];
    const createRow = resources => `
        <tr>
            <th scope="row">${resources.code}</th>
            <td>${resources.updated}</td>
        </tr>`;
    return createTable(headers, createRow, jsonData);
};
/**
 * Clears the tool results by emptying the HTML content.
 * @function clearToolResults
 */
const clearToolResults = function () {
    toolResults.innerHTML = '';
}
/**
 * Adds the specified content to the toolResults element.
 *
 * @param {Element} content - The content to be added.
 */
const updateToolResults = function (content) {
    if (content) {
        toolResults.appendChild(content);
    }
}
let start = 0;
/**
 * A callback function that handles clicking on a link element.
 * @param {Event} e - The event object.
 */
const clickLinkCallback = (e) => {
    e.preventDefault();
    const CronType = e.target.dataset.type;
    clearToolResults();
    switch (CronType) {
        case 'products':
        case 'accessories':
            getJSON(e.target.href, 'admin ajax call failed!')
                .then(data => {
                    if (data.data.length === 0) {
                        console.log(`No ${e.target.dataset.type} Updated or Added`);
                    } else {
                        console.table(data.data);
                        updateToolResults(displayProducts(data.data));
                    }
                })
                .catch(err => {
                    console.error(`${err} 💥💥💥`);
                });
            break;
        case 'categories':
        case 'taxonomies':
            getJSON(e.target.href, 'admin ajax call failed!')
                .then(data => {
                    if (data.data.length === 0) {
                        console.log(`No ${e.target.dataset.type} Updated or Added`);
                    } else {
                        console.table(data.data);
                        updateToolResults(displayCategories(data.data));
                    }
                })
                .catch(err => {
                    console.error(`${err} 💥💥💥`);
                });
            break;
        case 'ice_types':
            getJSON(e.target.href, 'admin ajax call failed!')
                .then(data => {
                    if (data.data.length === 0) {
                        console.log(`No ${e.target.dataset.type} Updated or Added`);
                    } else {
                        console.table(data.data);
                    }
                })
                .catch(err => {
                    console.error(`${err} 💥💥💥`);
                });
            break;
        case 'resources':
            getJSON(e.target.href, 'admin ajax call failed!')
                .then(data => {
                    if (data.data.length === 0) {
                        console.log(`No ${e.target.dataset.type} Updated or Added`);
                    } else {
                        console.table(data.data);
                        updateToolResults(displayResources(data.data));
                    }
                })
                .catch(err => {
                    console.error(`${err} 💥💥💥`);
                });
            break;
        case 'attributes':
            const confirmResult = confirm('This action cannot be undone. Are you sure!');
            if (confirmResult === true) {
                getJSON(e.target.href, 'admin ajax call failed!')
                    .then(data => {
                        alert('cleared!');
                    })
                    .catch(err => {
                        console.error(`${err} 💥💥💥`);
                    });
            }
            break;
        default:
            break;
    }

};
links.forEach((link) => {
    link.addEventListener('click', clickLinkCallback);
});