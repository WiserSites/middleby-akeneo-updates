<?php

/**
 * Class MBEK.
 *
 * Represents a plugin class that handles plugin initialization, database updates, and other necessary tasks.
 */
class MBEK {

	/**
	 * Initiated - Boolean true or false.
	 *
	 * @var bool
	 */
	private static $initiated = false;

	/**
	 * Initializes the plugin if it hasn't been initiated before.
	 *
	 * This method is called during the initialization of the plugin. It checks if the plugin has been
	 * initiated before and if not, it calls the `init_hooks` method to set up the necessary hooks and actions.
	 *
	 * @return void
	 */
	public static function init() {

		if ( ! self::$initiated ) {
			self::init_hooks();
		}
	}

	/**
	 * Initializes the hooks for the plugin.
	 *
	 * This method is called to set up the necessary hooks when the plugin is initiated.
	 * It sets the 'initiated' flag to true and calls the 'update_db_check' method.
	 *
	 * @return void
	 */
	private static function init_hooks() {
		self::$initiated = true;
		self::update_db_check();

		if ( isset( $_REQUEST['export_settings'] )
			&& is_user_logged_in()
			&& ! is_admin()
			&& ( current_user_can( 'editor' ) || current_user_can( 'administrator' ) )
		) {
			require_once MBEK_PLUGIN_DIR . 'lib/class.mbek-export.php';
			MBEK_EXPORT::check_export_action();
		}
	}

	/**
	 * Checks if the database needs to be updated and performs necessary actions if required.
	 *
	 * This method is called internally to check if the current database version matches the expected database version.
	 * If it doesn't match, it executes the necessary steps to update the database.
	 *
	 * @return void
	 */
	private static function update_db_check() {
		$current_db_version = get_option( MBEK_DB_VERSION_OPTION );
		if ( empty( $current_db_version ) || $current_db_version != MBEK_DB_VERSION ) {
			self::create_db();
			self::update_post_field();
		}
	}

	/**
	 * Creates the necessary database tables for the plugin.
	 *
	 * This method is called during the activation of the plugin.
	 * It creates three tables in the WordPress database: [prefix]_pim_data, [prefix]_pim_assets, and [prefix]_pim_category.
	 *
	 * @return void
	 * @global wpdb $wpdb WordPress database object.
	 */
	private static function create_db() {
		global $wpdb;
		$charset_collate = $wpdb->get_charset_collate();
		$table_name      = $wpdb->prefix . MBEK_PIM_DATA_TABLE_NAME;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		$sql = "CREATE TABLE $table_name (
			id mediumint(9) NOT NULL AUTO_INCREMENT,
			created datetime NOT NULL,
			updated datetime NOT NULL,
			identifier tinytext NULL,
			uuid varchar(36) NOT NULL UNIQUE,
			model tinytext NOT NULL,
			family tinytext NOT NULL,
			post_type tinytext NOT NULL,
			categories text,
			`groups` text,
			`parent` text,
			data longtext,
			associations text,
			quantified_associations text,
			metadata text,
			PRIMARY KEY  (id)
		) $charset_collate;";
		dbDelta( $sql );

		$table_name = $wpdb->prefix . MBEK_PIM_ASSETS_TABLE_NAME;
		$sql        = "CREATE TABLE $table_name (
			id mediumint(9) NOT NULL AUTO_INCREMENT,
			created datetime NOT NULL,
			updated datetime NOT NULL,
			family tinytext NOT NULL,
			code tinytext NOT NULL,
			data longtext,
			PRIMARY KEY  (id)
		) $charset_collate;";
		dbDelta( $sql );

		$table_name = $wpdb->prefix . MBEK_PIM_CATEGORY_TABLE_NAME;
		$sql        = "CREATE TABLE $table_name (
			id mediumint(9) NOT NULL AUTO_INCREMENT,
			updated datetime NOT NULL,
			code tinytext NOT NULL,
			parent tinytext NOT NULL,
			labels text NOT NULL,
			data longtext,
			PRIMARY KEY  (id)
		) $charset_collate;";
		dbDelta( $sql );

		update_option( MBEK_DB_VERSION_OPTION, MBEK_DB_VERSION );
	}

	/**
	 * Updates the post_type field in a specific database table.
	 *
	 * This method retrieves the post_type option value from the MBEK_OPTIONS
	 * option and updates the post_type field in the specified database table
	 * with the retrieved value. If the post_type option is empty, the post_type
	 * field in the database table will be updated with an empty string.
	 *
	 * @return void
	 * @global WPDB $wpdb The WordPress database object.
	 */
	public static function update_post_field() {
		global $wpdb;
		$table_name = $wpdb->prefix . MBEK_PIM_DATA_TABLE_NAME;
		// If there's an option for post_type (mbek_post_type).
		$options   = get_option( MBEK_OPTIONS );
		$post_type = $options['mbek_post_type'];
		if ( ! empty( $post_type ) ) {
			$wpdb->update(
				$table_name,
				array( 'post_type' => $post_type ),
				array( 'post_type' => '' ),
				array( '%s' ),
				array( '%s' )
			);
		}
	}

	/**
	 * Activates the plugin and creates the necessary database tables.
	 *
	 * This method is called when the plugin is activated using the WordPress admin panel.
	 * It invokes the `create_db()` method of the `MBEK` class to create the required database tables.
	 *
	 * @return void
	 */
	public static function plugin_activation() {
		self::create_db();
	}

	/**
	 * Loads the necessary resources for the plugin.
	 *
	 * This method is responsible for loading any required resources for the plugin to function properly.
	 * It can be used to enqueue scripts and stylesheets, register custom post types or taxonomies, or perform any other necessary setup tasks.
	 *
	 * @return void
	 */
	public static function load_resources() {
	}

	/**
	 * Deactivates the plugin and unschedules a specific cron event.
	 *
	 * This method is called when the plugin is deactivated using the WordPress admin panel.
	 * It retrieves the timestamp of the next scheduled instance of a specific cron event and unschedules it.
	 *
	 * @return void
	 */
	public static function plugin_deactivation() {
		$timestamp = wp_next_scheduled( MBEK_CRON_HOOK );
		wp_unschedule_event( $timestamp, MBEK_CRON_HOOK );
	}
}
