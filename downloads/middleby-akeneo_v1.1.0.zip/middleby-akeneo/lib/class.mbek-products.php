<?php
/**
 * Middleby Akeneo class for Products.
 *
 * PIM Akeneo Intergration class for Products.
 *
 * @package    Akeneo Plugin
 * @subpackage Admin
 * @since      1.0.0
 */
namespace Middleby\Akeneo;

/**
 * Middleby Akeneo class for Products.
 *
 * PIM Akeneo Intergration class for Products.
 *
 * @package    Akeneo Plugin
 * @subpackage Admin
 * @since      1.0.0
 */
#[\AllowDynamicProperties]
class MBEK_Products {
	/**
	 * The variable $post_type stores the name of the post type.
	 *
	 * @var string
	 */
	private $post_type;

	/**
	 * The variable $woo_tabs_data stores an array of data related to Woo tabs.
	 *
	 * @var array
	 */
	public $woo_tabs_data = array();

	/**
	 * @var
	 */
	public $ID;

	/**
	 * The variable $field_keys stores an array of field keys.
	 *
	 * @var array
	 */
	private $field_keys = array();

	/**
	 * The variable $fields stores an array of fields.
	 *
	 * @var array
	 */
	private $fields = array();

	/**
	 * The variable $categories stores an array of categories.
	 *
	 * @var array
	 */
	private $categories = array();

	/**
	 * The variable $brand stores a string representing the brand information.
	 *
	 * @var string
	 */
	private $brand = '';

	/**
	 * The variable $sub_brand stores a string value representing the sub-brand.
	 *
	 * @var string
	 */
	private $sub_brand = '';

	/**
	 * The variable $pim_taxonomies stores an array of taxonomies related to PIM (Product Information Management) system.
	 *
	 * @var array
	 */
	private $pim_taxonomies = array();

	/**
	 * The variable $pim_associations stores an array of data related to PIM associations.
	 *
	 * @var array
	 */
	private $pim_associations = array();

	/**
	 * Constructs a new instance of the class.
	 *
	 * This method is the constructor for the class. It is automatically called
	 * when a new object is created. In this case, it calls the get_mbek_options()
	 * method to retrieve and set the options for the "mbek" plugin.
	 *
	 * @return void
	 */
	public function __construct() {
		$this->get_mbek_options();
	}

	/**
	 * Sets the value of a specified property.
	 *
	 * This method sets the value of the specified property using the provided name
	 * and value. The property is accessed using the arrow operator and assigned the
	 * provided value.
	 *
	 * @param string $name The name of the property to be set.
	 * @param mixed  $value The value to assign to the property.
	 *
	 * @return void
	 */
	public function __set( string $name, mixed $value ): void {
		$this->{$name} = $value;
	}

	/**
	 * Retrieves the categories for the object.
	 *
	 * This method returns the categories property of the object.
	 *
	 * @return array The categories for the object.
	 */
	public function get_categories() {
		return $this->categories;
	}

	/**
	 * Sets the categories for the object.
	 *
	 * This method sets the categories for the object it is called on. The categories
	 * are passed as an array to the $categories parameter.
	 *
	 * @param array $categories An array of category names.
	 *
	 * @return $this
	 */
	public function set_categories( $categories ) {
		$this->categories = $categories;
		return $this;
	}

	/**
	 * Retrieves the brand of the object.
	 *
	 * This method returns the value of the "brand" property of the object.
	 *
	 * @return string The brand of the object
	 */
	public function get_brand() {
		return $this->brand;
	}

	/**
	 * Sets the brand for the object.
	 *
	 * This method sets the brand property of the object to the specified brand value.
	 * It also returns the object itself to allow for method chaining.
	 *
	 * @param string $brand The brand to set.
	 *
	 * @return $this The object instance with the brand set.
	 */
	public function set_brand( $brand ) {
		$this->brand = $brand;
		return $this;
	}

	/**
	 * Retrieves the sub-brand value.
	 *
	 * This method returns the sub-brand value that is stored in the object's "sub_brand" property.
	 *
	 * @return string The sub-brand value.
	 */
	public function get_sub_brand() {
		return $this->sub_brand;
	}

	/**
	 * Sets the sub-brand for the given object.
	 *
	 * This method sets the sub-brand property of the object to the provided
	 * sub-brand value. It returns the updated object instance.
	 *
	 * @param string $sub_brand The sub-brand value to be set.
	 *
	 * @return $this The updated object instance.
	 */
	public function set_sub_brand( $sub_brand ) {
		$this->sub_brand = $sub_brand;
		return $this;
	}

	/**
	 * Retrieves the PIM taxonomies.
	 *
	 * This method returns the PIM taxonomies that are stored in the variable $pim_taxonomies.
	 *
	 * @return array The array of PIM taxonomies.
	 */
	public function get_pim_taxonomies() {
		return $this->pim_taxonomies;
	}

	/**
	 * Sets the PIM taxonomies.
	 *
	 * This method assigns the provided PIM taxonomies to the `$pim_taxonomies` property of the current object.
	 * It then returns the current object, allowing method chaining.
	 *
	 * @param array $pim_taxonomies The PIM taxonomies to be set.
	 *
	 * @return $this The current object.
	 */
	public function set_pim_taxonomies( $pim_taxonomies ) {
		$this->pim_taxonomies = $pim_taxonomies;
		return $this;
	}

	/**
	 * Retrieves the PIM associations.
	 *
	 * This method returns the value of the pim_associations property.
	 *
	 * @return array The PIM associations.
	 */
	public function get_pim_associations() {
		return $this->pim_associations;
	}

	/**
	 * Sets the associations for the product information management (PIM).
	 *
	 * This method allows you to set the associations for the PIM by passing
	 * an array of associations. The associations will be stored in the
	 * `$pim_associations` property of the current object.
	 *
	 * @param array $associations An array of associations for the PIM.
	 *
	 * @return $this The current object for method chaining.
	 */
	public function set_pim_associations( $associations ) {
		$this->pim_associations = $associations;
		return $this;
	}

	/**
	 * Retrieves the ID of the current object.
	 *
	 * This method returns the ID property of the current object.
	 *
	 * @return int The ID of the current object.
	 */
	public function get_ID() {
		return $this->ID;
	}

	/**
	 * Sets the ID of the object.
	 *
	 * This method sets the ID of the object to the provided value.
	 *
	 * @param int $ID The ID to set.
	 *
	 * @return $this The updated object.
	 */
	public function set_ID( $ID ) {
		$this->ID = $ID;

		return $this;
	}

	/**
	 * Sets the WooCommerce tabs data.
	 *
	 * This method sets the WooCommerce tabs data by storing it in the class variable $woo_tabs_data.
	 *
	 * @param array $data The data to be set for the WooCommerce tabs.
	 *
	 * @return $this Returns the current class instance in order to allow method chaining.
	 */
	public function set_woo_tabs_data( $data ) {
		$this->woo_tabs_data = $data;

		return $this;
	}

	/**
	 * Retrieves the data for the WooTabs.
	 *
	 * This method returns the value of the `$woo_tabs_data` property.
	 *
	 * @return mixed The data for the WooTabs.
	 */
	public function get_woo_tabs_data() {
		return $this->woo_tabs_data;
	}

	/**
	 * Retrieves the public variables of the current object.
	 *
	 * This method creates an anonymous inner class with a single method called
	 * get_public_vars. This method uses the get_object_vars() function to
	 * retrieve the public variables of a given object.
	 * The get_public_vars method of the inner class is then invoked with the
	 * current object as the argument, and the result is returned.
	 *
	 * @return array An associative array containing the names of the public variables
	 *               as the keys and their values as the values.
	 */
	public function get_public_vars() {
		$me = new class() {
			function get_public_vars( $obj ) {
				return get_object_vars( $obj );
			}
		};

		return $me->get_public_vars( $this );
	}

	/**
	 * Initializes the class and sets up necessary variables.
	 *
	 * This method sets the class's fields by calling the get_public_vars() method twice:
	 * once to retrieve the public variables of the class itself, and secondly to retrieve
	 * the public variables of the retrieved public variables. The resulting fields are
	 * stored in the class's "fields" property.
	 *
	 * @return object Returns the instance of the class for method chaining.
	 */
	public function init() {
		$this->fields = $this->get_public_vars( $this->get_public_vars() );

		return $this;
	}

	/**
	 * Saves the current object.
	 *
	 * This method saves the object by creating a new database record
	 * if the object does not have an ID, or updating the existing record
	 * if the object already has an ID.
	 *
	 * @return void
	 */
	public function save() {
		global $wpdb;
		$was_created = false;
		$options                     = get_option( MBEK_OPTIONS );
		$mbek_discontinued_published = ( isset( $options['mbek_discontinued_published'] ) )
			? $options['mbek_discontinued_published']
			: false;
		$post_status                 = ( $this->discontinued && ! $mbek_discontinued_published ) ? 'draft' : 'publish';

		if ( ! $this->get_ID() ) {
			// You'll need to update the Model Field Name meta value (add) to this post.
			$post_data_fields = array(
				'post_status' => $post_status,
			);
			// Create new Record for this post_type.
			foreach ( $this->fields as $field_name => $value ) {
				if ( in_array( $field_name, array( 'post_content', 'post_title', 'post_excerpt' ) ) ) {
					switch ( $field_name ) {
						case 'post_content':
							$post_data_fields['post_content'] = $value;
							break;
						case 'post_title':
							$post_data_fields['post_title'] = $value;
							break;
						case 'post_excerpt':
							$post_data_fields['post_excerpt'] = $value;
							break;
					}
				}
			}
			if ( ! empty( $post_data_fields ) ) {
				$post_data_fields['post_type'] = $this->get_post_type();
				$ID                            = wp_insert_post( $post_data_fields );
				if ( $ID ) {
					$this->set_ID( $ID );
					$was_created = true;
					// Log creation with post ID and PIM UUID
					if ( isset( $this->pim_uuid ) ) {
						\MBEK::write_log( 'MBEK pull_products: created post ID=' . $ID . ' uuid=' . $this->pim_uuid );
					} else {
						\MBEK::write_log( 'MBEK pull_products: created post ID=' . $ID );
					}
				}
			}
			if ( ! empty( $this->get_ID() ) ) {
				foreach ( $this->fields as $field_name => $value ) {
					if ( isset( $this->field_keys[ $field_name ]['key'] ) ) {
						$field_key = $this->field_keys[ $field_name ]['key'];
						update_field( $field_key, $value, $this->get_ID() );
					}
				}
			}
		}

		// Update the ACF's. and post fields.
		if ( ! empty( $this->fields ) && $this->get_ID() ) {
			$has_post_fields  = false;
			$post_data_fields = array(
				'post_status' => $post_status,
			);
			foreach ( $this->fields as $field_name => $value ) {
				if ( isset( $this->field_keys[ $field_name ]['key'] ) ) {
					$field_key    = $this->field_keys[ $field_name ]['key'];
					$field_obj    = get_field_object( $field_key );
					$field_labels = array(
						'label' => $field_obj['label'],
						'type'  => $field_obj['type'],
					);

					if ( $field_obj['type'] === 'repeater' ) {
						$repeater_values = array();
						// Delete any rows for this repeater.
						// if ( have_rows( $field_key, $this->get_ID() ) ) {
						// $row_count = 1;
						// while ( have_rows( $field_key, $this->get_ID() ) ) {
						// the_row();
						// delete_row( $field_key, 1, $this->get_ID() );
						// $row_count++;
						// }
						// }
						if ( is_array( $value ) && ! empty( $value ) ) {
							$counter = 1;
							foreach ( $value as $v ) {
								if ( isset( $v['url'] ) ) {
									$new_row_data = array(
										'file_url' => $v['url'],
										'label'    => $v['label'],
									);
								} else {
									$new_row_data = array(
										'file_url' => $v,
									);
								}
								$repeater_values[] = $new_row_data;

								// add_row( $field_key, $new_row_data, $this->get_ID() );
							}
						}
						update_field( $field_key, $repeater_values, $this->get_ID() );
					} else {
						if ( is_array( $value ) ) {
							if ( isset( $value[0]['url'] ) ) {
								$value = $value[0]['url'];
							} else {
								$value = $value[0];
							}
						}
						// var_dump($field_key);
						update_field( $field_key, $value, $this->get_ID() );
					}
				} else {
					// If not found in field_keys then the field maybe for the actual fields.
					if ( in_array( $field_name, array( 'post_content', 'post_title', 'post_excerpt' ) ) ) {
						$has_post_fields = true;

						switch ( $field_name ) {
							case 'post_content':
								$post_data_fields['post_content'] = $value;
								break;
							case 'post_title':
								$post_data_fields['post_title'] = $value;
								break;
							case 'post_excerpt':
								$post_data_fields['post_excerpt'] = $value;
								break;
						}
					}
				}
			}
			if ( $has_post_fields ) {
				$post_data     = get_post( $this->get_ID(), ARRAY_A );
				$new_post_data = array_merge( $post_data, $post_data_fields );
				wp_update_post( $new_post_data );
			}
		}

		// Log update with post ID and PIM UUID (skip if just created and already logged)
		if ( ! $was_created && $this->get_ID() ) {
			if ( isset( $this->pim_uuid ) ) {
				\MBEK::write_log( 'MBEK pull_products: updated post ID=' . $this->get_ID() . ' uuid=' . $this->pim_uuid );
			} else {
				\MBEK::write_log( 'MBEK pull_products: updated post ID=' . $this->get_ID() );
			}
		}

		// Update Brand if brand option is set.
		$pim_brand_taxonomy = get_option( 'options_pim_brand_taxonomy' );
		// Check to see if brand sub option is set.
		$pim_brand_taxonomy_sub_field = get_option( 'options_pim_brand_taxonomy_sub_field' );

		if ( $pim_brand_taxonomy ) {
			if ( $this->get_brand() ) {
				$term = get_term_by( 'name', $this->get_brand(), $pim_brand_taxonomy, ARRAY_A );
				// echo '<pre>brand: '.print_r($term, true).'</pre>';
				$ID          = $this->get_ID();
				$brand_terms = array();
				if ( $ID && isset( $term['term_id'] ) ) {
					$brand_id = $term['term_id'];
					if ( $term['parent'] != 0 ) {
						$brand_id = $term['parent'];
					}
					$brand_terms[] = $brand_id;
				}

				if ( $ID ) {
					// Check to see if brand sub option is set.
					$pim_brand_taxonomy_sub_field = get_option( 'options_pim_brand_taxonomy_sub_field' );
					if ( $pim_brand_taxonomy_sub_field ) {
						$cats = $this->get_categories();
						if ( ! empty( $cats ) ) {
							if ( ! empty( $cats ) ) {
								foreach ( $cats as $cat ) {
									// Find this $cat by the pim_category_code ACF.
									$term_args = array(
										'taxonomy'   => $pim_brand_taxonomy_sub_field,
										'hide_empty' => false,
										'meta_query' => array(
											array(
												'key'   => 'pim_category_code',
												'value' => $cat,
											),
										),
									);
									$terms     = get_terms( $term_args );
									if ( $terms && isset( $terms[0]->term_id ) ) {
										$brand_terms[] = $terms[0]->term_id;
									}
								}
							}
						}
					}
					wp_set_post_terms( $ID, $brand_terms, $pim_brand_taxonomy, false );
				}
			}
		}

		// Update Category if Categories is set.
		$pim_category_taxonomies = get_option( 'options_pim_category_taxonomy' );
		if ( $pim_category_taxonomies ) {
			if ( strpos( $pim_category_taxonomies, ',' ) ) {
				$pim_cat_taxes = explode( ',', $pim_category_taxonomies );
				$pim_cat_taxes = array_map( 'trim', $pim_cat_taxes );
			} else {
				$pim_cat_taxes = array( $pim_category_taxonomies );
			}
			foreach ( $pim_cat_taxes as $pim_category_taxonomy ) {
				$pim_term_ids = array();
				$cats         = $this->get_categories();
				if ( ! empty( $cats ) ) {
					if ( ! empty( $cats ) ) {
						foreach ( $cats as $cat ) {
							// Find this $cat by the pim_category_code ACF.
							$term_args = array(
								'taxonomy'   => $pim_category_taxonomy,
								'hide_empty' => false,
								'meta_query' => array(
									array(
										'key'   => 'pim_category_code',
										'value' => $cat,
									),
								),
							);
							$terms     = get_terms( $term_args );
							if ( $terms && isset( $terms[0]->term_id ) ) {
								$pim_term_ids[] = $terms[0]->term_id;
							}
						}
						$ID = $this->get_ID();
						if ( $ID ) { // && ! empty( $pim_term_ids )
							wp_set_post_terms( $ID, $pim_term_ids, $pim_category_taxonomy, false );
						}
					}
				}
			}
		}

		// Get $pim_taxonomies from PIM Category Options.
		$pim_taxonomies = array();
		while ( have_rows( 'pim_taxonomy', 'option' ) ) {
			the_row();
			$pim_taxonomies[] = array(
				'name'      => get_sub_field( 'pim_taxonomy_name' ),
				'pim_field' => get_sub_field( 'pim_field_name' ),
			);
		}
		if ( ! empty( $pim_taxonomies ) ) {
			$pim_term_ids = array();
			foreach ( $pim_taxonomies as $pim_tax ) {
				if ( ! empty( $this->get_pim_taxonomies() ) ) {
					foreach ( $this->get_pim_taxonomies() as $tax_item ) {
						// Find this $cat by the pim_category_code ACF.
						$term_args = array(
							'taxonomy'   => $pim_tax['name'],
							'hide_empty' => false,
							'meta_query' => array(
								array(
									'key'   => 'pim_category_code',
									'value' => $tax_item,
								),
							),
						);
						$terms     = get_terms( $term_args );
						if ( $terms && isset( $terms[0]->term_id ) ) {
							$pim_term_ids[] = $terms[0]->term_id;
						}
					}
				}
				$ID = $this->get_ID();
				if ( $ID && ! empty( $pim_term_ids ) ) {
					wp_set_post_terms( $ID, $pim_term_ids, $pim_tax['name'], false );
				}
			}
		}

		// Get associations.
		$pim_association_field = get_option( 'options_pim_acf_field_for_product_relations' );
		$assoc_ids             = array();
		if ( $pim_association_field ) {
			$associations = $this->get_pim_associations();
			// echo '<pre>'.print_r($associations, true).'</pre>';
			if ( ! empty( $associations ) ) {
				if ( isset( $associations['related_option_or_accessory__one_way_relationship']['products'] ) &&
				! empty( $associations['related_option_or_accessory__one_way_relationship']['products'] ) ) {
					$related_uuids = $associations['related_option_or_accessory__one_way_relationship']['products'];
					// echo '<pre>'.print_r($related_uuids, true).'</pre>';
					foreach ( $related_uuids as $rel_id ) {
						$rel_post_id = $wpdb->get_var(
							$wpdb->prepare(
								'SELECT post_id
								   FROM ' . $wpdb->postmeta . '
								  WHERE meta_value = %s
								    AND meta_key = %s',
								$rel_id,
								'pim_uuid'
							)
						);
						if ( $rel_post_id ) {
							$assoc_ids[] = $rel_post_id;
						}
					}
				}
				if ( isset( $associations['related_cross_sell_product__one_way_relationship']['products'] ) &&
				! empty( $associations['related_cross_sell_product__one_way_relationship']['products'] ) ) {
					$related_uuids = $associations['related_cross_sell_product__one_way_relationship']['products'];
					// echo '<pre>'.print_r($related_uuids, true).'</pre>';
					foreach ( $related_uuids as $rel_id ) {
						$rel_post_id = $wpdb->get_var(
							$wpdb->prepare(
								'SELECT post_id
								   FROM ' . $wpdb->postmeta . '
								  WHERE meta_value = %s
								    AND meta_key = %s',
								$rel_id,
								'pim_uuid'
							)
						);
						if ( $rel_post_id ) {
							$assoc_ids[] = $rel_post_id;
						}
					}
				}
				$related_id_key = $this->get_field_keys( $pim_association_field );
				if ( isset( $related_id_key['key'] ) ) {
					update_field( $related_id_key['key'], $assoc_ids, $this->get_ID() );
				}
			}
		}

		// Update Woo Tab Meta Data.
		$wootab_editor_option   = '';
		$wootab_download_option = '';
		$woo_tab_field_key      = '';
		$post_id                = $this->get_ID();
		$wootabs_data           = $this->get_woo_tabs_data();
		$wootab_options         = get_option( MBEK_WOOTABS );
		if ( $wootabs_data && $post_id ) {
			if ( ! empty( $wootab_options ) ) {
				foreach ( $wootab_options as $woo_key => $woo_option ) {
					$woo_type = get_post_meta( $woo_option['id'], 'product_tab_type' );
					switch ( $woo_type[0] ) {
						case 'editor':
							if ( ! empty( $wootabs_data['editor'] ) ) {
								$wootab_editor_option = 'product_editor_' . $woo_option['id'] . '_tab_content';
							}
							break;
						case 'download':
							if ( ! empty( $wootabs_data['downloads'] ) ) {
								$wootab_download_option = 'product_download_' . $woo_option['id'] . '_tab_posts';
							}
							break;
					}
				}
				if ( $wootab_editor_option ) {
					update_post_meta( $post_id, $wootab_editor_option, $wootabs_data['editor'] );
				}
				if ( $wootab_download_option ) {
					update_post_meta( $post_id, $wootab_download_option, $wootabs_data['downloads'] );
				}
			}
		}

		return $this;
	}

	/**
	 * Finds the post ID based on the given criteria.
	 *
	 * This method looks for a post ID based on the given "pim_model" and/or "pim_uuid" values,
	 * as well as the "mbek_model_field" option value from the "mbek" plugin options.
	 * If a matching post ID is found, it sets the ID of the current instance and returns itself.
	 *
	 * @return $this
	 */
	public function find_post_id() {
		$options            = get_option( MBEK_OPTIONS );
		$model_field_name   = $options['mbek_model_field'];
		$mbek_use_only_uuid = ( isset( $options['mbek_use_only_uuid'] ) ) ? (bool) $options['mbek_use_only_uuid'] : false;

		// See if we can find the ID for related post.
		if ( ( isset( $this->pim_model ) && $this->pim_model ) || ( isset( $this->pim_uuid ) && $this->pim_uuid ) ) {
			if ( isset( $this->pim_model ) && isset( $this->pim_uuid ) ) {
				if ( $mbek_use_only_uuid ) {
					$meta_query = array(
						'relation' => 'OR',
						array(
							'key'     => 'pim_uuid',
							'value'   => trim( $this->pim_uuid ),
							'compare' => '=',
						),
					);
				} else {
					$meta_query = array(
						'relation' => 'OR',
						array(
							'key'     => 'pim_uuid',
							'value'   => trim( $this->pim_uuid ),
							'compare' => '=',
						),
						array(
							'key'     => $model_field_name,
							'value'   => trim( $this->pim_model ),
							'compare' => '=',
						),
						array(
							'key'     => 'pim_model',
							'value'   => trim( $this->pim_model ),
							'compare' => '=',
						),
					);
				}
			} elseif ( isset( $this->pim_model ) && ! isset( $this->pim_uuid ) ) {
				$meta_query = array(
					'relation' => 'OR',
					array(
						'key'     => $model_field_name,
						'value'   => trim( $this->pim_model ),
						'compare' => '=',
					),
					array(
						'key'     => 'pim_model',
						'value'   => trim( $this->pim_model ),
						'compare' => '=',
					),
				);
			} elseif ( ! isset( $this->pim_model ) && isset( $this->pim_uuid ) ) {
				$meta_query = array(
					'relation' => 'OR',
					array(
						'key'     => 'pim_uuid',
						'value'   => trim( $this->pim_uuid ),
						'compare' => '=',
					),
				);
			}
			$search_args = array(
				'post_per_page' => -1,
				'post_type'     => $this->get_post_type(),
				'fields'        => 'ids',
				'meta_query'    => $meta_query,
				'post_status'   => 'any',
			);
			$posts       = get_posts( $search_args );

			if ( is_array( $posts ) && count( $posts ) > 0 && $id = filter_var( $posts[0], FILTER_VALIDATE_INT ) ) {
				$this->set_ID( $posts[0] );
			}
		}

		return $this;
	}

	/**
	 * Create a product.
	 *
	 * This method creates a product by iterating through the fields and
	 * setting the necessary keys and values. It also retrieves wootab options
	 * and sets the data accordingly.
	 *
	 * @param mixed $product The product to be created.
	 *
	 * @return $this The instance of the class with the created product.
	 */
	public function create( $product, $new_fields ) {
		$this->field_keys = $new_fields;

		$wootab_data    = array();
		$wootab_options = get_option( MBEK_WOOTABS );
		$id             = $this->get_ID();
		if ( $id ) {
			if ( ! empty( $wootab_options ) ) {
				foreach ( $wootab_options as $woo_key => $woo_option ) {
					$woo_type   = get_post_meta( $woo_option['id'], 'product_tab_type' );
					$field_name = $woo_option['value'];
					switch ( $woo_type[0] ) {
						case 'editor':
							$wootab_option = 'product_editor_' . $woo_option['id'] . '_tab_content';
							$wootab_editor = get_post_meta( $id, $wootab_option );
							if ( ! empty( $wootab_editor ) ) {
								$wootab_data['editor'] = $wootab_editor;
							}
							if ( isset( $this->fields[ $woo_option['value'] ] ) && $this->fields[ $field_name ] ) {
								$woo_content_var       = $this->fields[ $woo_option['value'] ];
								$woo_content           = ( is_array( $woo_content_var ) ) ? $woo_content_var[0]['url'] : $woo_content_var;
								$wootab_data['editor'] = $woo_content;
							}
							if ( $field_name === 'pim_product_feature_fields-NEW' && ! empty( $product->{$field_name} ) ) {
								$wootab_data['editor'] = $product->{$field_name};
							}
							break;
						case 'download':
							$woo_download_id = 'product_download_' . $woo_option['id'] . '_tab_posts';
							if ( $this->fields[ $woo_option['value'] ] ) {
								// $wootab_data['downloads'][] = array(
								//
								// );
								$woo_link_var               = $this->fields[ $woo_option['value'] ];
								$woo_link                   = ( is_array( $woo_link_var ) ) ? $woo_link_var[0]['url'] : $woo_link_var;
								$wootab_data['downloads'][] = array(
									'file'        => '',
									'link'        => $woo_link,
									'title'       => trim( $woo_option['option'] ),
									'description' => '',
								);
							}
							break;
					}
				}

				// If ID get the old wootab download options.

				if ( $id ) {
					$new_woo_tab = array();
					$wootab = null;// get_post_meta( $id, $wootab_option );
					if ( ! empty( $wootab ) ) {
						// See if the array contains title within the wootabs options.
						foreach ( $wootab_options as $woo_label => $woo_value ) {
							// Only update if there's a value to update from PIM.
							if ( $product->{$woo_value} ) {
								$found    = false;
								$to_match = strtolower( str_replace( ' ', '', $woo_label ) );

								foreach ( $wootab[0] as $w_key => &$woo_tab_element ) {
									$match = strtolower( str_replace( ' ', '', $woo_tab_element['title'] ) );
									if ( $match === $to_match ) {
										$woo_link_var            = $product->{$woo_value};
										$woo_link                = ( is_array( $woo_link_var ) ) ? $woo_link_var[0] : $woo_link_var;
										$woo_tab_element['link'] = $woo_link;
										$found                   = true;
									}
								}
								if ( ! $found ) {
									// If not found then create a new entry for woo tabs.
									$woo_link_var  = $product->{$woo_value};
									$woo_link      = ( is_array( $woo_link_var ) ) ? $woo_link_var[0] : $woo_link_var;
									$new_woo_tab[] = array(
										'file'        => '',
										'link'        => $woo_link,
										'title'       => trim( $woo_label ),
										'description' => '',
									);
								}
							}
						}
						// Check if there's new items.
						if ( ! empty( $new_woo_tab ) ) {
							foreach ( $new_woo_tab as $new_item ) {
								$wootab[0][] = $new_item;
							}
						}
					} else {
						// This is here to get new Woo Tab Data From PIM.
						foreach ( $wootab_options as $woo_label => $woo_value ) {
							// Only update if there's a value to update from PIM.
							if ( isset( $product->{$woo_value['value']} ) && $product->{$woo_value['value']} ) {
								$found    = false;
								$to_match = strtolower( str_replace( ' ', '', $woo_label ) );

								if ( ! $found ) {
									// If not found then create a new entry for woo tabs.
									$woo_link_var  = $product->{$woo_value['value']};
									$woo_link      = ( is_array( $woo_link_var ) ) ? $woo_link_var[0] : $woo_link_var;
									$new_woo_tab[] = array(
										'file'        => '',
										'link'        => $woo_link,
										'title'       => trim( $woo_label ),
										'description' => '',
									);
								}
							}
						}
						// Check if there's new items.
						if ( ! empty( $new_woo_tab ) ) {
							foreach ( $new_woo_tab as $new_item ) {
								$wootab[0][] = $new_item;
							}
						}
					}
					$this->set_woo_tabs_data( $wootab );
				}
			}
			$this->set_woo_tabs_data( $wootab_data );
		}

		return $this;
	}

	/**
	 * Retrieves the field keys for a given field name.
	 *
	 * This method queries the WordPress database to retrieve the field data for the
	 * specified field name. If the field keys have already been fetched and stored
	 * in the class property $field_keys, it returns the stored keys. Otherwise, it
	 * performs a SELECT query to fetch the field data from the "acf-field" posts
	 * table and constructs an associative array containing the relevant field
	 * information.
	 *
	 * @param string $field_name The name of the field.
	 *
	 * @return array The field information as an associative array, or an empty
	 *               array if the field was not found.
	 * @global wpdb $wpdb The WordPress database object.
	 */
	public function get_field_keys( $field_name ) {
		global $wpdb;
		if ( isset( $this->field_keys[ $field_name ] ) ) {
			return $this->field_keys[ $field_name ];
		}
		$query     = 'SELECT * FROM  ' . $wpdb->posts . " WHERE `post_type` = 'acf-field' AND `post_excerpt` = '" . $field_name . "' ";
		$field     = array();
		$acf_field = $wpdb->get_row( $query, ARRAY_A );
		if ( ! empty( $acf_field ) && count( $acf_field ) ) {
			$field_parts = unserialize( $acf_field['post_content'] );
			$field       = array(
				'ID'       => $acf_field['ID'],
				'key'      => $acf_field['post_name'],
				'type'     => $field_parts['type'],
				'taxonomy' => ( ! empty( $field_parts['taxonomy'] ) ? $field_parts['taxonomy'] : null ),
				'choices'  => ( ! empty( $field_parts['choices'] ) ? $field_parts['choices'] : null ),
				'multiple' => ( ! empty( $field_parts['multiple'] ) ? $field_parts['multiple'] : null ),
			);
		}

		return $field;
	}

	/**
	 * Retrieves the options for the "mbek" plugin.
	 *
	 * This method fetches the saved options using the get_option() function
	 * and sets the post type based on the retrieved options.
	 *
	 * @return void
	 */
	public function get_mbek_options() {
		$options = get_option( MBEK_OPTIONS );
		$this->set_post_type( $options['mbek_post_type'] );
	}

	/**
	 * Gets the post type.
	 *
	 * @return string The post type.
	 */
	public function get_post_type() {
		return $this->post_type;
	}

	/**
	 * Sets the post type for the current instance of the class.
	 *
	 * @param string $post_type The post type to be set.
	 *
	 * @return void
	 */
	public function set_post_type( $post_type ) {
		$this->post_type = $post_type;

		return $this;
	}

	/**
	 * Retrieves the ACF (Advanced Custom Fields) fields for a specific product ID.
	 *
	 * @return array|bool Returns an array of ACF fields if successfully retrieved, otherwise false.
	 */
	public function get_acf_fields() {
		$options = get_option( MBEK_OPTIONS );
		if ( $options['mbek_product_id'] && filter_var( $options['mbek_product_id'], FILTER_VALIDATE_INT ) ) {
			return get_field_objects( $options['mbek_product_id'] );
		}

		return false;
	}
}
