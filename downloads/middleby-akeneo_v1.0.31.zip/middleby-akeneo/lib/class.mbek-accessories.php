<?php
/**
 * Middleby Akeneo class for Products.
 *
 * PIM Akeneo Intergration class for Products.
 *
 * @package    Akeneo Plugin
 * @subpackage Admin
 * @since      1.0.0
 */

namespace Middleby\Akeneo;

/**
 * Middleby Akeneo class for Accessories.
 *
 * This class represents a Accessories object in the Middleby Akeneo Plugin for Akeneo integration.
 *
 * @package    Middleby\Akeneo
 */
#[\AllowDynamicProperties]
class MBEK_Accessories {
	/**
	 * @var
	 */
	private $post_type;

	/**
	 * @var
	 */
	public $ID;

	/**
	 * @var array
	 */
	private $field_keys = array();

	/**
	 * @var array
	 */
	private $fields = array();

	/**
	 * Constructs a new instance of the class.
	 *
	 * This constructor method initializes a new instance of the class by calling the `get_mbek_options` method.
	 * The `get_mbek_options` method retrieves the options for the MBEK plugin and performs necessary initialization.
	 *
	 * @return void
	 */
	public function __construct() {
		$this->get_mbek_options();
	}

	/**
	 * Sets the value of a specified property.
	 *
	 * This method sets the value of the specified property using the provided name
	 * and value. The property is accessed using the arrow operator and assigned the
	 * provided value.
	 *
	 * @param string $name The name of the property to be set.
	 * @param mixed  $value The value to assign to the property.
	 *
	 * @return void
	 */
	public function __set( string $name, mixed $value ): void {
		$this->{$name} = $value;
	}

	/**
	 * Retrieves the ID of the current object.
	 *
	 * This method returns the ID value stored in the `$ID` property of the current object.
	 *
	 * @return int The ID of the object.
	 */
	public function get_ID() {
		return $this->ID;
	}

	/**
	 * Sets the ID for the object.
	 *
	 * This method sets the ID for the current object by assigning the provided value
	 * to the `ID` property. It then returns the current object to allow for method chaining.
	 *
	 * @param int $ID The ID to set for the object.
	 *
	 * @return self The current object with the updated ID.
	 */
	public function set_ID( $ID ) {
		$this->ID = $ID;

		return $this;
	}

	/**
	 * Retrieves the public properties of an object.
	 *
	 * This method creates an anonymous class with a public method `get_public_vars`.
	 * The `get_public_vars` method accepts an object as a parameter and returns an array
	 * containing the public properties of the object by calling the `get_object_vars` function.
	 *
	 * @param object $obj The object for which to retrieve public properties.
	 *
	 * @return array The array containing the public properties of the object.
	 */
	public function get_public_vars() {
		$me = new class() {
			function get_public_vars( $obj ) {
				return get_object_vars( $obj );
			}
		};

		return $me->get_public_vars( $this );
	}

	/**
	 * Initializes the object.
	 *
	 * This method initializes the object by setting the `fields` property with the result of calling
	 * the `get_public_vars` method twice. It then returns the object.
	 *
	 * @return self The initialized object.
	 */
	public function init() {
		$this->fields = $this->get_public_vars( $this->get_public_vars() );

		return $this;
	}

	/**
	 * Saves the current object.
	 *
	 * This method is responsible for saving the current object by creating or updating the
	 * corresponding post in the WordPress database. If the object does not have an ID set,
	 * a new post will be created. If the object already has an ID set, the existing post will
	 * be updated.
	 *
	 * @return $this The current object.
	 */
	public function save() {
		global $wpdb;
		if ( ! $this->get_ID() ) {
			// You'll need to update the Model Field Name meta value (add) to this post.
			$post_data_fields = array(
				'post_status' => 'publish',
			);
			// Create new Record for this post_type.
			foreach ( $this->fields as $field_name => $value ) {
				if ( in_array( $field_name, array( 'post_content', 'post_title', 'post_excerpt' ) ) ) {
					switch ( $field_name ) {
						case 'post_content':
							$post_data_fields['post_content'] = $value;
							break;
						case 'post_title':
							$post_data_fields['post_title'] = $value;
							break;
						case 'post_excerpt':
							$post_data_fields['post_excerpt'] = $value;
							break;
					}
				}
			}
			if ( ! empty( $post_data_fields ) ) {
				$post_data_fields['post_type'] = $this->get_post_type();
				$ID                            = wp_insert_post( $post_data_fields );
				if ( $ID ) {
					$this->set_ID( $ID );
				}
			}
			if ( ! empty( $this->get_ID() ) ) {
				foreach ( $this->fields as $field_name => $value ) {
					if ( isset( $this->field_keys[ $field_name ]['key'] ) ) {
						$field_key = $this->field_keys[ $field_name ]['key'];
						update_field( $field_key, $value, $this->get_ID() );
					}
				}
			}
		}

		// Update the ACF's. and post fields.
		if ( ! empty( $this->fields ) && $this->get_ID() ) {
			$has_post_fields  = false;
			$post_data_fields = array();
			foreach ( $this->fields as $field_name => $value ) {
				if ( isset( $this->field_keys[ $field_name ]['key'] ) ) {
					$field_key    = $this->field_keys[ $field_name ]['key'];
					$field_obj    = get_field_object( $field_key );
					$field_labels = array(
						'label' => $field_obj['label'],
						'type'  => $field_obj['type'],
					);

					if ( $field_obj['type'] === 'repeater' ) {
						$repeater_values = array();
						// Delete any rows for this repeater.
						// if ( have_rows( $field_key, $this->get_ID() ) ) {
						// $row_count = 1;
						// while ( have_rows( $field_key, $this->get_ID() ) ) {
						// the_row();
						// delete_row( $field_key, 1, $this->get_ID() );
						// $row_count ++;
						// }
						// }
						if ( is_array( $value ) && ! empty( $value ) ) {
							$counter = 1;
							foreach ( $value as $v ) {
								if ( isset( $v['url'] ) ) {
									$new_row_data = array(
										'file_url' => $v['url'],
										'label'    => $v['label'],
									);
								} else {
									$new_row_data = array(
										'file_url' => $v,
									);
								}
								$repeater_values[] = $new_row_data;

								// add_row( $field_key, $new_row_data, $this->get_ID() );
							}
						}
						update_field( $field_key, $repeater_values, $this->get_ID() );
						// if ( is_array( $value ) && ! empty( $value ) ) {
						// $counter = 1;
						// foreach ( $value as $v ) {
						// $new_row_data = array(
						// 'file_url' => $v,
						// );
						// add_row( $field_key, $new_row_data, $this->get_ID() );
						// }
						// }
					} else {
						if ( is_array( $value ) ) {
							$value = $value[0];
						}
						// var_dump($field_key);
						update_field( $field_key, $value, $this->get_ID() );
					}
				} else {
					// If not found in field_keys then the field maybe for the actual fields.
					if ( in_array( $field_name, array( 'post_content', 'post_title', 'post_excerpt' ) ) ) {
						$has_post_fields = true;

						switch ( $field_name ) {
							case 'post_content':
								$post_data_fields['post_content'] = $value;
								break;
							case 'post_title':
								$post_data_fields['post_title'] = $value;
								break;
							case 'post_excerpt':
								$post_data_fields['post_excerpt'] = $value;
								break;
						}
					}
				}
			}
			if ( $has_post_fields ) {
				$post_data     = get_post( $this->get_ID(), ARRAY_A );
				$new_post_data = array_merge( $post_data, $post_data_fields );
				wp_update_post( $new_post_data );
			}
		}

		return $this;
	}

	/**
	 * Finds the ID of a related post.
	 *
	 * This method searches for a post ID based on the specified model and UUID.
	 * It constructs a meta query using the "pim_model" and "pim_uuid" keys in the class properties.
	 * If both properties are set, it constructs an "OR" relation meta query with both key-value pairs.
	 * If only "pim_model" property is set, it constructs a meta query for "pim_model" key-value pair.
	 * If only "pim_uuid" property is set, it constructs a meta query for "pim_uuid" key-value pair.
	 * Then, it performs a search using `get_posts` function with the constructed meta query, post type,
	 * and returns only the post IDs.
	 * If a post is found, it validates the first post ID as a valid integer and sets it as current ID
	 * using the `set_ID` method.
	 *
	 * @return $this
	 */
	public function find_post_id() {
		// See if we can find the ID for related post.
		if ( ( isset( $this->pim_uuid ) && $this->pim_uuid ) ) {
			$meta_query  = array(
				'relation' => 'OR',
				array(
					'key'     => 'pim_uuid',
					'value'   => trim( $this->pim_uuid ),
					'compare' => '=',
				),
			);
			$search_args = array(
				'post_per_page' => - 1,
				'post_type'     => $this->get_post_type(),
				'fields'        => 'ids',
				'meta_query'    => $meta_query,
			);
			$posts       = get_posts( $search_args );

			if ( is_array( $posts ) && count( $posts ) > 0 && $id = filter_var( $posts[0], FILTER_VALIDATE_INT ) ) {
				$this->set_ID( $posts[0] );
			}
		}

		return $this;
	}

	/**
	 * Creates a new product.
	 *
	 * This method creates a new product by iterating over the fields defined in the object's `fields` property.
	 * For each field, it retrieves the field keys using the `get_field_keys` method and sets the `type` property
	 * with the field's type value.
	 *
	 * @param mixed $product The product data to create.
	 *
	 * @return $this The instance of the object for method chaining.
	 */
	public function create( $product ) {
		// echo '<pre>$product: ' . print_r( $product, true ) . '</pre>';
		foreach ( $this->fields as $field_name => $field_data ) {
			$field_obj = $this->get_field_keys( $field_name );
			if ( $field_obj ) {
				$type                            = $field_obj['type'];
				$this->field_keys[ $field_name ] = $field_obj;
			}
		}

		return $this;
	}

	/**
	 * Retrieves the field keys for a given field name.
	 *
	 * This method queries the WordPress database table for Advanced Custom Fields (`acf-field`)
	 * to find the field with the specified name (`$field_name`). It then retrieves the field
	 * information including the ID, key, type, taxonomy, choices, and multiple status. The field
	 * information is returned as an associative array.
	 *
	 * @param string $field_name The name of the field.
	 *
	 * @return array The field information as an associative array. If the field is not found, an
	 *               empty array is returned.
	 */
	public function get_field_keys( $field_name ) {
		global $wpdb;
		if ( isset( $this->field_keys[ $field_name ] ) ) {
			return $this->field_keys[ $field_name ];
		}
		$query     = 'SELECT * FROM  ' . $wpdb->posts . " WHERE `post_type` = 'acf-field' AND `post_excerpt` = '" . $field_name . "' ";
		$field     = array();
		$acf_field = $wpdb->get_row( $query, ARRAY_A );
		if ( ! empty( $acf_field ) && count( $acf_field ) ) {
			$field_parts = unserialize( $acf_field['post_content'] );
			$field       = array(
				'ID'       => $acf_field['ID'],
				'key'      => $acf_field['post_name'],
				'type'     => $field_parts['type'],
				'taxonomy' => ( ! empty( $field_parts['taxonomy'] ) ? $field_parts['taxonomy'] : null ),
				'choices'  => ( ! empty( $field_parts['choices'] ) ? $field_parts['choices'] : null ),
				'multiple' => ( ! empty( $field_parts['multiple'] ) ? $field_parts['multiple'] : null ),
			);
		}

		return $field;
	}

	/**
	 * Retrieves the options for the MBEK plugin.
	 *
	 * This method retrieves the MBEK plugin options by calling the `get_option` function
	 * with the MBEK_OPTIONS constant. It then sets the post type for the MBEK plugin by calling
	 * the `set_post_type` method with the value of the 'mbek_accessory_post_type' key in the options array.
	 *
	 * @return void
	 */
	public function get_mbek_options() {
		$options = get_option( MBEK_OPTIONS );
		$this->set_post_type( $options['mbek_accessory_post_type'] );
	}

	/**
	 * Retrieves the post type associated with the current instance.
	 *
	 * @return string The post type associated with the current instance.
	 */
	public function get_post_type() {
		return $this->post_type;
	}

	/**
	 * Sets the post type for the current object.
	 *
	 * @param string $post_type The post type to set for the object.
	 *
	 * @return $this
	 */
	public function set_post_type( $post_type ) {
		$this->post_type = $post_type;

		return $this;
	}
}
