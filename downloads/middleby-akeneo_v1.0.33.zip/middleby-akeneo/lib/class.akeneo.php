<?php
/**
 * Middleby Akeneo class.
 *
 * PIM Akeneo Intergration class.
 *
 * @package    Akeneo Plugin
 * @subpackage Admin
 * @since      1.0.0
 */

namespace Middleby\Akeneo;

require_once MBEK_PLUGIN_DIR . '/vendor/autoload.php';
require_once MBEK_PLUGIN_DIR . 'lib/class.mbek-products.php';
require_once MBEK_PLUGIN_DIR . 'lib/class.mbek-accessories.php';

use Akeneo\Pim\ApiClient\AkeneoPimClientBuilder;
use Akeneo\Pim\ApiClient\Exception\UnprocessableEntityHttpException;
use Akeneo\Pim\ApiClient\Search\SearchBuilder;
use MBEK_Admin;
use PHPUnit\Exception;

/**
 * Akeneo Class for querying data from PIM.
 */
class MBEK_Akeneo {

	/**
	 * @var mixed
	 */
	private $options;
	/**
	 * @var
	 */
	private $client;
	/**
	 * @var
	 */
	private $client_url;
	/**
	 * @var
	 */
	private $client_id;
	/**
	 * @var
	 */
	private $client_secret;
	/**
	 * @var
	 */
	private $username;
	/**
	 * @var
	 */
	private $password;
	/**
	 * @var
	 */
	private $default_locale;
	/**
	 * @var
	 */
	private $category_locale;
	/**
	 * @var
	 */
	private $token;
	/**
	 * @var
	 */
	private $refresh_token;
	/**
	 * @var
	 */
	private $timestamp;
	/**
	 * @var
	 */
	private $family;
	/**
	 * @var
	 */
	private $family_group;
	/**
	 * @var
	 */
	private $brand;

	/**
	 * @var array An associative array containing asset families and their respective attributes.
	 * Each key represents an asset family identifier, and the value is an array containing:
	 * - 'label' (string): The display name of the asset family.
	 * - 'family' (string): The internal identifier of the asset family.
	 */
	private $asset_families = array(
		'User_Manuals'                   => array(
			'label'  => 'User Manuals',
			'family' => 'usermanuals',
		),
		'Spec_Sheets'                    => array(
			'label'  => 'Spec Sheets',
			'family' => 'specsheets',
		),
		'Brochure'                       => array(
			'label'  => 'Brochure',
			'family' => 'brochure',
		),
		'Parts_List'                     => array(
			'label'  => 'Parts List',
			'family' => 'partslist',
		),
		'warranty_sheet'                 => array(
			'label'  => 'Warranty Sheets',
			'family' => 'warrantysheet',
		),
		'product_line_drawings'          => array(
			'label'  => 'Product Lined Drawings',
			'family' => 'productlinedrawings',
		),
		'brand_catalog'                  => array(
			'label'  => 'Brand Catalog',
			'family' => 'brandcatalog',
		),
		'product_cad_design_files'       => array(
			'label'  => 'CAD Design Files',
			'family' => 'CAD_Design_Files',
		),
		'priint_automated_spec_sheet_ac' => array(
			'label'  => 'Priint Automated Spec Sheets',
			'family' => 'priintautomatedspecsheets',
		),
		'installation_instructions'      => array(
			'label'  => 'Installations Instructions',
			'family' => 'installations_instructions',
		),
	);

	/**
	 * Constructor method.
	 *
	 * This method initializes the object by calling the "get_mbek_options" method.
	 *
	 * @return void
	 */
	public function __construct() {
		$this->get_mbek_options();
	}

	/**
	 * Get the options.
	 *
	 * This method retrieves the current options of the object.
	 *
	 * @return array The options of the object.
	 */
	public function get_options() {
		return $this->options;
	}

	/**
	 * Set the options for the object.
	 *
	 * This method sets the options for the object to be used during its operation.
	 *
	 * @param array $options The options array containing key-value pairs.
	 *
	 * @return $this The current instance of the object.
	 */
	public function set_options( $options ) {
		$this->options = $options;

		return $this;
	}

	/**
	 * Get the client.
	 *
	 * This method retrieves the client instance that is used for authentication.
	 *
	 * @return Client The client instance.
	 */
	public function get_client() {
		return $this->client;
	}

	/**
	 * Set the client.
	 *
	 * This method sets the client to be used for authentication.
	 *
	 * @param string $client The client string.
	 *
	 * @return $this The current instance of the object.
	 */
	public function set_client( $client ) {
		$this->client = $client;

		return $this;
	}

	/**
	 * Get the client id.
	 *
	 * This method retrieves the client id that is used for authentication.
	 *
	 * @return string The client id string.
	 */
	public function get_client_id() {
		return $this->client_id;
	}

	/**
	 * Set the client ID.
	 *
	 * This method sets the client ID to be used for authentication.
	 *
	 * @param string $client_id The client ID string.
	 *
	 * @return $this The current instance of the object.
	 */
	public function set_client_id( $client_id ) {
		$this->client_id = $client_id;

		return $this;
	}

	/**
	 * Get the client secret.
	 *
	 * This method retrieves the client secret used for authentication.
	 *
	 * @return string The client secret string.
	 */
	public function get_client_secret() {
		return $this->client_secret;
	}

	/**
	 * Set the client secret.
	 *
	 * This method sets the client secret to be used for authentication.
	 *
	 * @param string $client_secret The client secret string.
	 *
	 * @return $this The current instance of the object.
	 */
	public function set_client_secret( $client_secret ) {
		$this->client_secret = $client_secret;

		return $this;
	}

	/**
	 * Get the username.
	 *
	 * This method retrieves the stored username.
	 *
	 * @return string The username.
	 */
	public function get_username() {
		return $this->username;
	}

	/**
	 * Set the username.
	 *
	 * This method sets the username to be used for authentication.
	 *
	 * @param string $username The username string.
	 *
	 * @return $this The current instance of the object.
	 */
	public function set_username( $username ) {
		$this->username = $username;

		return $this;
	}

	/**
	 * Get the password.
	 *
	 * This method retrieves the password associated with the current object.
	 *
	 * @return string The password string.
	 */
	public function get_password() {
		return $this->password;
	}

	/**
	 * Set the password.
	 *
	 * This method sets the password to be used for authentication.
	 *
	 * @param string $password The password string.
	 *
	 * @return $this The current instance of the object.
	 */
	public function set_password( $password ) {
		$this->password = $password;

		return $this;
	}

	/**
	 * Get the default locale.
	 *
	 * This method retrieves the default locale that is currently set.
	 *
	 * @return string The default locale string.
	 */
	public function get_default_locale() {
		return $this->default_locale;
	}

	/**
	 * Set the default locale.
	 *
	 * This method sets the default locale to be used for operations.
	 *
	 * @param string $default_locale The default locale string.
	 *
	 * @return $this The current instance of the object.
	 */
	public function set_default_locale( $default_locale ) {
		$this->default_locale = $default_locale;

		return $this;
	}

	/**
	 * Retrieve the category locale.
	 *
	 * This method returns the category locale if set,
	 * otherwise it defaults to the default locale.
	 *
	 * @return string The category locale or the default locale.
	 */
	public function get_category_locale() {
		return $this->category_locale ? $this->category_locale : $this->default_locale;
	}

	/**
	 * Set the category locale.
	 *
	 * This method assigns the category locale for the current instance.
	 *
	 * @param string $category_locale The category locale to set.
	 *
	 * @return $this The current instance of the object.
	 */
	public function set_category_locale( $category_locale ) {
		$this->category_locale = $category_locale;

		return $this;
	}

	/**
	 * Get the token.
	 *
	 * This method returns the token that is currently stored in the object.
	 *
	 * @return string The current token string.
	 */
	public function get_token() {
		return $this->token;
	}

	/**
	 * Set the token.
	 *
	 * This method sets the token to be used for authentication.
	 *
	 * @param string $token The token string.
	 *
	 * @return $this The current instance of the object.
	 */
	public function set_token( $token ) {
		$this->token = $token;

		return $this;
	}

	/**
	 * Get the refresh token.
	 *
	 * This method retrieves the refresh token that was previously set for authentication.
	 *
	 * @return string The refresh token string.
	 */
	public function get_refresh_token() {
		return $this->refresh_token;
	}

	/**
	 * Set the refresh token.
	 *
	 * This method sets the refresh token to be used for authentication.
	 *
	 * @param string $refresh_token The refresh token string.
	 *
	 * @return $this The current instance of the object.
	 */
	public function set_refresh_token( $refresh_token ) {
		$this->refresh_token = $refresh_token;

		return $this;
	}

	/**
	 * Retrieves the timestamp associated with the current object.
	 *
	 * @return mixed The timestamp value.
	 */
	public function get_timestamp() {
		return $this->timestamp;
	}

	/**
	 * Set the timestamp value.
	 *
	 * @param int $timestamp The timestamp value to be set.
	 *
	 * @return $this Returns the current instance of the object.
	 */
	public function set_timestamp( $timestamp ) {
		$this->timestamp = $timestamp;

		return $this;
	}

	/**
	 * Retrieves the family value.
	 *
	 * @return mixed The family value.
	 */
	public function get_family() {
		return $this->family;
	}

	/**
	 * Set the family of the object.
	 *
	 * @param mixed $family The family value to set.
	 *
	 * @return MBEK_Akeneo The current instance of MBEK_Akeneo.
	 */
	public function set_family( $family ) {
		$this->family = $family;

		return $this;
	}

	/**
	 * Retrieves the brand associated with the MBEK_Akeneo instance.
	 *
	 * @return string The brand value.
	 */
	public function get_brand() {
		return $this->brand;
	}

	/**
	 * Set the brand for the object.
	 *
	 * @param mixed $brand The brand value to set.
	 *
	 * @return $this This object for method chaining.
	 */
	public function set_brand( $brand ) {
		$this->brand = $brand;

		return $this;
	}

	/**
	 * Retrieves the client URL.
	 *
	 * @return string The client URL.
	 */
	public function get_client_url() {
		return $this->client_url;
	}

	/**
	 * Sets the client URL.
	 *
	 * @param string $client_url The URL of the client.
	 *
	 * @return MBEK_Akeneo The current instance of MBEK_Akeneo.
	 */
	public function set_client_url( $client_url ) {
		$this->client_url = $client_url;

		return $this;
	}

	/**
	 * Retrieves the MBEK options.
	 *
	 * This method retrieves the MBEK options from the WordPress database and sets the appropriate properties
	 * of the MBEK_Akeneo object.
	 *
	 * @return void
	 */
	public function get_mbek_options() {
		$defaults = array(
			'mbek_default_locale'         => 'en_US',
			'mbek_category_locale'        => 'en_US',
			'mbek_family'                 => '',
			'mbek_brand'                  => '',
			'mbek_client_refresh_token'   => '',
			'mbek_client_token_timestamp' => '',
			'mbek_client_token'           => '',
		);
		$options  = get_option( MBEK_OPTIONS, $defaults );
		$this->set_client_url( MBEK_CLIENT_URL )
		     ->set_client_id( MBEK_CLIENT_ID )
		     ->set_client_secret( MBEK_CLIENT_SECRET )
		     ->set_default_locale( $options['mbek_default_locale'] )
		     ->set_category_locale( $options['mbek_category_locale'] )
		     ->set_brand( $options['mbek_brand'] )
		     ->set_password( MBEK_CLIENT_PASSWORD )
		     ->set_refresh_token( $options['mbek_client_refresh_token'] )
		     ->set_timestamp( $options['mbek_client_token_timestamp'] )
		     ->set_token( $options['mbek_client_token'] )
		     ->set_username( MBEK_CLIENT_USERNAME );
	}

	/**
	 * Start the Akeneo client.
	 *
	 * @return void
	 */
	public function start_client() {
		$client_url    = $this->get_client_url();
		$client_id     = $this->get_client_id();
		$client_secret = $this->get_client_secret();
		$username      = $this->get_username();
		$password      = $this->get_password();
		$token         = $this->get_token();
		$refresh_token = $this->get_refresh_token();
		// $family        = $this->get_family();

		if ( $client_id && $client_secret && $username && $password && $client_url ) {
			if ( $this->check_expired() ) {
				$this->get_tokens();
			}
			$clientBuilder = new \Akeneo\Pim\ApiClient\AkeneoPimClientBuilder( $client_url );
			$this->set_client( $clientBuilder->buildAuthenticatedByToken( $client_id, $client_secret, $token, $refresh_token ) );
		}
	}

	/**
	 * Check if the token has expired.
	 *
	 * This method checks if the stored token has expired based on the expiration time set in the options.
	 *
	 * @return bool Whether the token has expired or not.
	 */
	public function check_expired() {
		// return true;
		// Check if we have enough creds in options to do a fetch for a token.
		$expired   = false;
		$options   = get_option( MBEK_OPTIONS );
		$timestamp = $options['mbek_client_token_timestamp'];

		// If timestamp then check for expiration based on the token expires in 360 seconds or 1 hour.
		$current_timestamp = time();
		if ( ( $timestamp && ( ( $timestamp + HOUR_IN_SECONDS ) <= $current_timestamp ) ) || ! $timestamp ) {
			$expired = true;
		}

		return $expired;
	}

	/**
	 * Checks if the given date is valid.
	 *
	 * @param string $date The date to be checked in the format dd/mm/yyyy.
	 *
	 * @return bool Returns true if the date is valid, false otherwise.
	 */
	public function check_my_date( $date ) {
		if ( preg_match( '/(\d{2})\/(\d{2})\/(\d{4})$/', $date, $matches ) ) {
			return ( checkdate( (int) $matches[1], (int) $matches[2], (int) $matches[3] ) );
		} else {
			return false;
		}
	}

	/**
	 * Fetches brand asset family from a specified URL.
	 *
	 * @param string $family The asset family to fetch.
	 * @param string $start_date The start date for filtering the assets (optional).
	 * @param string $end_date The end date for filtering the assets (optional).
	 *
	 * @return mixed Returns the response body if the request is successful, or false otherwise.
	 */
	public function fetch_brand_asset_family( $family, $start_date, $end_date ) {
		$url = 'https://middleby-cdn.com/PimBulkFiles.php';
		$url .= '?brand=' . urlencode( $this->get_brand() );
		$url .= '&family=' . urlencode( $family );
		if ( ! empty( $start_date ) && $this->check_my_date( $start_date ) ) {
			$url .= '&start_date=' . urlencode( $start_date );
		}
		if ( ! empty( $end_date ) && $this->check_my_date( $end_date ) ) {
			$url .= '&end_date=' . urlencode( $end_date );
		}
		$args = array(
			'sslverify' => false,
		);

		add_filter(
			'http_request_timeout',
			function ( $timeout, $url = '' ) {
				$start_with = 'https://middleby-cdn.com/PimBulkFiles.php';

				// return is_string($url) && str_starts_with($url, $start_with) // PHP 8
				return is_string( $url ) && strncmp( $url, $start_with, strlen( $start_with ) ) === 0 // PHP 7 or older
					? 60
					: $timeout; // return unchanged url for other requests
			},
			10,
			2
		);
		$request = wp_remote_request( $url, $args );

		$response_code    = wp_remote_retrieve_response_code( $request );
		$response_message = wp_remote_retrieve_response_message( $request );
		$response_body    = wp_remote_retrieve_body( $request );
		switch ( $response_code ) {
			case 400:
				// If error...
				trigger_error( 'Error uploading data!', E_USER_NOTICE );

				return false;
				break;
			case 200:
				// If success...
				$this->update_cron_timestamp( 'assets' );

				return $response_body;
				break;
			default:
				return false;
				break;
		}
	}

	/**
	 * Retrieves the list of brands.
	 *
	 * @return array The list of brands.
	 */
	public function get_brands() {
		$brands = get_option( MBEK_BRANDS );
		if ( $brands ) {
			return $brands;
		}
		$brands = $this->get_brand_attribute_options( 'brand' );
		update_option( MBEK_BRANDS, $brands );

		return $brands;
	}

	/**
	 * Returns the value of a specified field.
	 *
	 * @param mixed $field The field value to retrieve.
	 * @param string $type The type of field. Default is 'pim_catalog_text'.
	 * @param mixed $family The family value. Default is null.
	 *
	 * @return mixed The retrieved field value.
	 */
	public function get_field( $field, $type = 'pim_catalog_text', $family = null ) {
		if ( ! is_array( $field ) ) {
			return $field;
		}
		$default_locale = $this->get_default_locale();
		$return = $field[0];
		if ( $field[0]['locale'] ) {
			$locale_field = array_filter( $field, function ( $elem ) use ( $default_locale ) {
				return $elem['locale'] === $default_locale;
			} );
			$return = ( ! empty( $locale_field ) ) ? array_values( $locale_field )[0] : $field[0];
		}

		if ( isset( $return['data'] ) && is_array( $return['data'] ) ) {
			switch ( $type ) {
				case 'akeneo_reference_entity_collection':
					return $this->fetch_reference_entity_url( $field, $family );
					break;
				case 'pim_catalog_asset_collection':
//					trigger_error( '$field' . print_r( $field, true), E_USER_NOTICE );
					return $this->fetch_media_asset_url( $field, $family );
					break;
				case 'pim_catalog_text':
				case 'pim_catalog_textarea':
					if ( $field[0]['locale'] ) {
						$locale_field = array_filter( $field, function ( $elem ) use ( $default_locale ) {
							return $elem['locale'] === $default_locale;
						} );
						return ( ! empty( $locale_field ) ) ? array_values( $locale_field )[0]['data'] : $field[0]['data'];
					}
					return $return['data'];
					break;
				case 'pim_catalog_multiselect':
				case 'pim_catalog_simpleselect':
					if ( isset( $return['linked_data'] ) ) {
						$pim_values = array_map(
							function ( $elem ) {
								return ( isset( $elem['labels'][ $this->get_default_locale() ] ) ) ? $elem['labels'][ $this->get_default_locale() ] : $elem['labels']['en_US'];
							},
							$return['linked_data']
						);

						return implode( ', ', $pim_values );
					}

					return implode( ', ', $return['data'] );
					break;
				case 'pim_catalog_metric':
					return $return['data']['amount'] . ' ' . $return['data']['unit'];
					break;
				case 'pim_catalog_price_collection':
					switch ( $return['data'][0]['currency'] ) {
						case 'USD':
						default:
							$currency = '$';
							break;
					}

					return $currency . $return['data'][0]['amount'];
					break;
			}
		} elseif ( isset( $return['linked_data'] ) && is_array( $return['linked_data'] ) ) {
			if ( isset( $return['linked_data']['labels'][ $this->get_default_locale() ] ) ) {
				return $return['linked_data']['labels'][ $this->get_default_locale() ];
			} else {
				return $return['data'];
			}
		} elseif ( isset( $field[0]['data'] ) ) {
			return $return['data'];
		} elseif ( is_array( $field ) ) {
			if ( $type === 'categories' ) {
				$categories = array();
				foreach ( $field as $item ) {
					$categories[] = $this->get_category_label( $item );
				}

				return implode( ', ', $categories );
			}

			return implode( ', ', $field );
		} else {
			return $return['data'];
		}
	}

	/**
	 * Retrieves the label of a category based on its code.
	 *
	 * @param string $code The code of the category.
	 *
	 * @return string The label of the category in English.
	 */
	public function get_category_label( $code ) {
		$category = $this->client->getCategoryApi()->get( $code );

		return $category['labels'][ $this->get_category_locale() ];
	}

	/**
	 * Retrieves the categories from the specified source and returns them.
	 * If the categories are already stored in the WordPress options, it returns the stored categories.
	 * Otherwise, it retrieves the categories from the API client and builds a hierarchical tree structure
	 * for the categories. It then flattens the tree into a single-dimensional array and stores it in the
	 * WordPress options for future use.
	 *
	 * @return array The categories
	 */
	public function get_categories() {
		$cats = get_option( MBEK_CATEGORIES );
		if ( $cats ) {
			return $cats;
		}
		$cats       = array();
		$categories = $this->client->getCategoryApi()->all();
		foreach ( $categories as $category ) {
			$cats[ $category['code'] ] = array(
				'parent' => $category['parent'],
				'label'  => $category['labels'][ $this->get_category_locale() ],
				'code'   => $category['code'],
			);
		}

		$cat_heir    = $this->build_tree( $cats, null );
		$cat_flatten = $this->flatten_categories( $cat_heir );
		update_option( MBEK_CATEGORIES, $cat_flatten );

		return $cat_flatten;
	}

	/**
	 * Retrieves the saved brand categories from the database.
	 *
	 * @return array|object|null Database query results as an associative array, an object, or null on failure.
	 * @global wpdb $wpdb WordPress database object.
	 */
	public function get_saved_brand_categories() {
		global $wpdb;

		$table_name = $wpdb->prefix . MBEK_PIM_CATEGORY_TABLE_NAME;

		return $wpdb->get_results(
			"SELECT *
               FROM $table_name
           ORDER BY id",
			ARRAY_A
		);
	}

	/**
	 * Retrieves brand categories based on specified criteria.
	 *
	 * @param string $start_date The start date to filter the categories. (Optional)
	 * @param string $end_date The end date to filter the categories. (Optional)
	 * @param bool $first_run True if it is the first run, false otherwise.
	 *
	 * @return array The brand categories that match the specified criteria.
	 */
	public function get_brand_categories( $start_date, $end_date, $first_run ) {
		global $wpdb;
		$categories    = array();
		$searchBuilder = new SearchBuilder();
		$searchBuilder->addFilter( 'parent', '=', $this->get_brand() . '_Website' );

		if ( ! $first_run ) {
			$date_format = 'c';// 'Y-m-d H:m:s';
			if ( $start_date ) {
				$start = strtotime( $start_date );
			} else {
				$start = strtotime( '-1 day' );
			}
			if ( $end_date ) {
				$end = strtotime( $end_date );
			} else {
				$end = 0;
			}
			if ( $start && $end ) {
				$searchBuilder->addFilter( 'updated', 'BETWEEN', array( date( 'c', $start ), date( 'c', $end ) ) );
			} elseif ( $start && ! $end ) {
				$searchBuilder->addFilter( 'updated', '>', date( $date_format, $start ) );
			}
		} else {
			// Clear category cache table.
			$table_name = $wpdb->prefix . MBEK_PIM_CATEGORY_TABLE_NAME;
			$wpdb->query( "TRUNCATE TABLE $table_name" );
		}

		$searchFilter = $searchBuilder->getFilters();

		$categories        = array();
		$akeneo_categories = $this->client->getCategoryApi()->all(
			100,
			array(
				'search'                   => $searchFilter,
				'with_enriched_attributes' => true,
			)
		);
		foreach ( $akeneo_categories as $category ) {
			$categories[] = $category;
			$this->save_brand_categories( $category );
		}

		return $categories;
	}

	/**
	 * Retrieves the sub-brand categories based on the given start and end dates.
	 *
	 * @param string|null $start_date The start date in 'Y-m-d H:m:s' format. If null, it defaults to the previous day.
	 * @param string|null $end_date The end date in 'Y-m-d H:m:s' format. If null, it defaults to 0.
	 * @param bool $first_run Indicates whether it is the first run or not.
	 *
	 * @return array An array of sub-brand categories.
	 */
	public function get_sub_brand_categories( $start_date, $end_date, $first_run ) {
		$pim_sub_brand_taxonomy_parent = get_option( 'options_pim_sub_brand_taxonomy_parent' );
		$categories                    = array();
		if ( $pim_sub_brand_taxonomy_parent ) {
			$searchBuilder = new SearchBuilder();
			$searchBuilder->addFilter( 'parent', '=', $pim_sub_brand_taxonomy_parent );

			if ( ! $first_run ) {
				$date_format = 'c';// 'Y-m-d H:m:s';
				if ( $start_date ) {
					$start = strtotime( $start_date );
				} else {
					$start = strtotime( '-1 day' );
				}
				if ( $end_date ) {
					$end = strtotime( $end_date );
				} else {
					$end = 0;
				}
				if ( $start && $end ) {
					$searchBuilder->addFilter( 'updated', 'BETWEEN', array( date( 'c', $start ), date( 'c', $end ) ) );
				} elseif ( $start && ! $end ) {
					$searchBuilder->addFilter( 'updated', '>', date( $date_format, $start ) );
				}
			}

			$searchFilter = $searchBuilder->getFilters();

			$akeneo_categories = $this->client->getCategoryApi()->all(
				100,
				array(
					'search'                   => $searchFilter,
					'with_enriched_attributes' => true,
				)
			);
			foreach ( $akeneo_categories as $category ) {
				if ( $category ) {
					$categories[] = $category;
					$this->sync_pim_sub_brand_data( $category );
				}
			}
		}

		return $categories;
	}

	/**
	 * Syncs PIM sub brand data with the given category.
	 *
	 * @param array $category The category data to sync.
	 *
	 * @return void
	 */
	public function sync_pim_sub_brand_data( $category ) {
		$pim_brand_taxonomy = get_option( 'options_pim_brand_taxonomy' );
		$term_id            = false;
		$found_by_code      = false;
		// Find a category match.
		// Look first for pim code.
		$term_args = array(
			'taxonomy'   => $pim_brand_taxonomy,
			'hide_empty' => false,
			'meta_query' => array(
				array(
					'key'   => 'pim_category_code',
					'value' => $category['code'],
				),
			),
		);
		$terms     = get_terms( $term_args );
		if ( $terms && isset( $terms[0]->term_id ) ) {
			$found_by_code = $terms[0]->term_id;
		}
		if ( ! empty( $found_by_code ) ) {
			$term_id = $found_by_code;
		} else {
			// Replace underscore with dash.
			// $search_for = preg_replace( '%_%', '-', $category['code'] );
			//
			// if ( isset( $new_taxs[$search_for] ) ) {
			// $term_id = $new_taxs[ $search_for ]->term_id;
			// }
		}

		$labels = $category['labels'];// unserialize( $pim_category->labels );
		$p_data = $category['values'];// unserialize( $pim_category->data );

		// $title = str_replace( "_", '-', $category['code'] );
		// $slug = sanitize_title( $title );
		// $term = array(
		// 'taxonomy' => $pim_brand_taxonomy,
		// 'cat_name' => $labels['en_US'],
		// 'category_nicename' => $slug,
		// );
		// $term_id = wp_insert_category( $term, true );
		// if ( is_wp_error( $term_id ) ) {
		// Check if error is from existing term.
		// if ( isset( $term_id->error_data['term_exists'] ) ) {
		// $term_id = $term_id->error_data['term_exists'];
		// }
		// }
		if ( $term_id && filter_var( $term_id, FILTER_VALIDATE_INT ) && ! is_wp_error( $term_id ) ) {
			if ( isset( $p_data['website_series_image|c81b39c3-0e9f-4dfd-b645-634a58cbb954']['data']['original_filename'] )
			     && $p_data['website_series_image|c81b39c3-0e9f-4dfd-b645-634a58cbb954']['data']['original_filename']
			) {
				$file_name = $p_data['website_series_image|c81b39c3-0e9f-4dfd-b645-634a58cbb954']['data']['original_filename'];
				if ( strpos( $file_name, '&' ) ) {
					$file_name = str_replace( '&', '--', $file_name );
				}
			} else {
				$file_name = '';
			}
			$file_asset_url = ( $file_name )
				? 'https://middleby-cdn.com/categories/' . $this->get_brand() . '/' . $file_name
				: '';

			// update_field( 'field_64ca9a2853ccf', $category['code'], $pim_brand_taxonomy . '_'.$term_id );
			if ( isset( $p_data['website_series_name|176f5672-6950-49e3-8b87-a685a01a63cd']['data'] ) ) {
				update_field( 'field_64ca9acb6ae8a', $p_data['website_series_name|176f5672-6950-49e3-8b87-a685a01a63cd']['data'], $pim_brand_taxonomy . '_' . $term_id );
			}
			if ( isset( $p_data['website_series_description|4b482060-f242-4be1-93ba-075bc5277840']['data'] ) ) {
				update_field( 'field_64ca9ae76ae8b', $p_data['website_series_description|4b482060-f242-4be1-93ba-075bc5277840']['data'], $pim_brand_taxonomy . '_' . $term_id );
			}
			if ( isset( $p_data['website_product_series_features_and_benefits|3c6be35b-99d8-4777-92a3-2755c097c457']['data'] ) ) {
				update_field( 'field_654a8564f0652', $p_data['website_product_series_features_and_benefits|3c6be35b-99d8-4777-92a3-2755c097c457']['data'], $pim_brand_taxonomy . '_' . $term_id );
			}
			if ( isset( $file_asset_url ) ) {
				update_field( 'field_64ca9b15c15c2', $file_asset_url, $pim_brand_taxonomy . '_' . $term_id );
			}
		}
	}

	/**
	 * Retrieves the ice types from Akeneo based on the given start date, end date, and first run flag.
	 *
	 * @param string $start_date The start date for filtering the updated ice types. Optional.
	 * @param string $end_date The end date for filtering the updated ice types. Optional.
	 * @param bool $first_run Flag that indicates whether it is the first run. Optional.
	 *
	 * @return array The retrieved ice types from Akeneo.
	 */
	public function get_icetypes( $start_date, $end_date, $first_run ) {
		$categories       = array();
		$searchBuilder    = new SearchBuilder(); // icetro_website_ice_type
		$main_parent_name = strtolower( $this->get_brand() ) . '_website_ice_type';
		$searchBuilder->addFilter( 'parent', '=', $main_parent_name );
		$pim_ice_type_taxonomy = get_option( 'options_pim_ice_type_taxonomy' );
		// trigger_error( '$pim_ice_type_taxonomy: ' . $pim_ice_type_taxonomy, E_USER_NOTICE );
		if ( ! $pim_ice_type_taxonomy ) {
			return $categories;
		}

		if ( ! $first_run ) {
			$date_format = 'c';// 'Y-m-d H:m:s';
			if ( $start_date ) {
				$start = strtotime( $start_date );
			} else {
				$start = strtotime( '-1 day' );
			}
			if ( $end_date ) {
				$end = strtotime( $end_date );
			} else {
				$end = 0;
			}
			if ( $start && $end ) {
				$searchBuilder->addFilter( 'updated', 'BETWEEN', array( date( 'c', $start ), date( 'c', $end ) ) );
			} elseif ( $start && ! $end ) {
				$searchBuilder->addFilter( 'updated', '>', date( $date_format, $start ) );
			}
		}

		$searchFilter = $searchBuilder->getFilters();

		$categories        = array();
		$akeneo_categories = $this->client->getCategoryApi()->all(
			100,
			array(
				'search'                   => $searchFilter,
				'with_enriched_attributes' => true,
			)
		);
		foreach ( $akeneo_categories as $pim_category ) {
			$categories[] = $pim_category;
			$labels       = $pim_category['labels'];
			// Find this $pim_category by the pim_category_code ACF.
			// $term_args = array(
			// 'taxonomy'   => $pim_ice_type_taxonomy,
			// 'hide_empty' => false,
			// 'meta_query' => array(
			// array(
			// 'key' => 'pim_category_code',
			// 'value' => $pim_category['code'],
			// ),
			// ),
			// );
			// echo '<pre>$term_args: ' . print_r( $term_args, true ) . '</pre>';
			// $terms = get_terms( $term_args );

			$title = str_replace( '_', '-', $pim_category['code'] );
			$slug  = sanitize_title( $title );
			$term  = array(
				'taxonomy'          => $pim_ice_type_taxonomy,
				'cat_name'          => $labels[ $this->get_category_locale() ],
				'category_nicename' => $slug,
			);

			if ( $pim_category['parent'] != $main_parent_name ) {
				$parent_name = str_replace( '_', '-', $pim_category['parent'] );
				$parent_slug = sanitize_title( $parent_name );
				$parent      = get_term_by(
					'slug',
					$parent_slug,
					$pim_ice_type_taxonomy
				);
				if ( isset( $parent->term_id ) ) {
					$term['category_parent'] = $parent->term_id;
				}
			}
			$term_id = wp_insert_category( $term, true );
			if ( is_wp_error( $term_id ) ) {
				// Check if error is from existing term.
				if ( isset( $term_id->error_data['term_exists'] ) ) {
					$term_id = $term_id->error_data['term_exists'];
				}
			}
			if ( $term_id && filter_var( $term_id, FILTER_VALIDATE_INT ) && ! is_wp_error( $term_id ) ) {
				$file_asset_url = isset( $p_data['website_series_image|c81b39c3-0e9f-4dfd-b645-634a58cbb954']['data']['original_filename'] )
					? 'https://middleby-cdn.com/categories/' . $this->get_brand() . '/' . $p_data['website_series_image|c81b39c3-0e9f-4dfd-b645-634a58cbb954']['data']['original_filename']
					: '';

				update_field( 'field_64ca9a2853ccf', $pim_category['code'], $pim_ice_type_taxonomy . '_' . $term_id );
				if ( isset( $p_data['website_series_name|176f5672-6950-49e3-8b87-a685a01a63cd']['data'] ) ) {
					update_field( 'field_64ca9acb6ae8a', $p_data['website_series_name|176f5672-6950-49e3-8b87-a685a01a63cd']['data'], $pim_ice_type_taxonomy . '_' . $term_id );
				}
				if ( isset( $p_data['website_series_description|4b482060-f242-4be1-93ba-075bc5277840']['data'] ) ) {
					update_field( 'field_64ca9ae76ae8b', $p_data['website_series_description|4b482060-f242-4be1-93ba-075bc5277840']['data'], $pim_ice_type_taxonomy . '_' . $term_id );
				}
				if ( isset( $file_asset_url ) ) {
					update_field( 'field_64ca9b15c15c2', $file_asset_url, $pim_ice_type_taxonomy . '_' . $term_id );
				}
			}
		}

		return $categories;
	}

	/**
	 * Synchronize PIM category data with WordPress.
	 *
	 * @return void
	 */
	public function sync_pim_catgory_data() {
		global $wpdb;
		$new_taxs              = array();
		$pim_category_taxonomy = \get_option( 'options_pim_category_taxonomy' );
		$taxonomies            = \get_terms(
			array(
				'taxonomy'   => $pim_category_taxonomy,
				'hide_empty' => false,
			)
		);
		foreach ( $taxonomies as $tax ) {
			$new_taxs[ $tax->slug ] = $tax;
		}
		$table_name = $wpdb->prefix . MBEK_PIM_CATEGORY_TABLE_NAME;
		// Get all of the table data.
		$pim_results        = $wpdb->get_results(
			'SELECT *
 	           FROM ' . $table_name . '
 	       ORDER BY id'
		);
		$pim_category_codes = array();
		if ( ! empty( $pim_results ) ) {
			include_once ABSPATH . '/wp-admin/includes/taxonomy.php';
			foreach ( $pim_results as $pim_category ) {
				$pim_category_codes[] = $pim_category->code;
				$term_id              = false;
				$term                 = array();
				$found_by_code        = false;
				// Find a category match.
				// Look first for pim code.
				$term_args = array(
					'taxonomy'   => $pim_category_taxonomy,
					'hide_empty' => false,
					'meta_query' => array(
						array(
							'key'     => 'pim_category_code',
							'value'   => $pim_category->code,
							'compare' => '=',
						),
					),
				);
				$terms     = \get_terms( $term_args );
				if ( $terms && isset( $terms[0]->term_id ) ) {
					$found_by_code = $terms[0]->term_id;
				}
				if ( $found_by_code ) {
					$term_id = $found_by_code;
				} else {
					// Replace underscore with dash.
					$search_for = \preg_replace( '%_%', '-', $pim_category->code );

					if ( isset( $new_taxs[ $search_for ] ) ) {
						$term_id = $new_taxs[ $search_for ]->term_id;
					}
				}
				$labels = \unserialize( $pim_category->labels );
				$p_data = \unserialize( $pim_category->data );

				$title = \str_replace( '_', '-', $pim_category->code );
				$slug  = \sanitize_title( $title );
				$term  = array(
					'taxonomy'          => $pim_category_taxonomy,
					'cat_name'          => $labels[ $this->get_category_locale() ],
					'category_nicename' => $slug,
				);
				if ( $term_id && \filter_var( $term_id, FILTER_VALIDATE_INT ) ) {
					$term['cat_ID'] = $term_id;
				}

				if ( $pim_category->parent != \strtolower( $this->get_brand() ) . '_website' ) {
					$parent_term_args = array(
						'taxonomy'   => $pim_category_taxonomy,
						'hide_empty' => false,
						'meta_query' => array(
							array(
								'key'   => 'pim_category_code',
								'value' => $pim_category->parent,
							),
						),
					);
					$parent_terms     = \get_terms( $parent_term_args );
					if ( $parent_terms && isset( $parent_terms[0]->term_id ) ) {
						$term['category_parent'] = $parent_terms[0]->term_id;
					}
					$parent_name = \str_replace( '_', '-', $pim_category->parent );
					$parent_slug = \sanitize_title( $parent_name );
					$parent      = \get_term_by(
						'slug',
						$parent_slug,
						$pim_category_taxonomy
					);
					if ( isset( $parent->term_id ) ) {
						$term['category_parent'] = $parent->term_id;
					}
				} else {
					$term['category_parent'] = 0;
				}
				try {
					$options = get_option( MBEK_OPTIONS );
					if ( ! empty( $options['mbek_pim_create_categories'] ) && $options['mbek_pim_create_categories'] ) {
						$term_id = \wp_insert_category( $term, true );
					}
					if ( \is_wp_error( $term_id ) ) {
						// Check if error is from existing term.
						if ( isset( $term_id->error_data['term_exists'] ) ) {
							$term_id = $term_id->error_data['term_exists'];
						}
					}
					if ( $term_id && \filter_var( $term_id, FILTER_VALIDATE_INT ) && ! \is_wp_error( $term_id ) ) {
						if ( isset( $p_data['website_series_image|c81b39c3-0e9f-4dfd-b645-634a58cbb954']['data']['original_filename'] )
						     && $p_data['website_series_image|c81b39c3-0e9f-4dfd-b645-634a58cbb954']['data']['original_filename']
						) {
							$file_name = $p_data['website_series_image|c81b39c3-0e9f-4dfd-b645-634a58cbb954']['data']['original_filename'];
							if ( \strpos( $file_name, '&' ) ) {
								$file_name = \str_replace( '&', '--', $file_name );
							}
						} else {
							$file_name = '';
						}
						$file_asset_url = ( $file_name )
							? 'https://middleby-cdn.com/categories/' . $this->get_brand() . '/' . $pim_category->code . '/' . $file_name
							: '';
						\update_field( 'field_64ca9a2853ccf', $pim_category->code, $pim_category_taxonomy . '_' . $term_id );
						if ( isset( $p_data['website_series_name|176f5672-6950-49e3-8b87-a685a01a63cd']['data'] ) ) {
							\update_field( 'field_64ca9acb6ae8a', $p_data['website_series_name|176f5672-6950-49e3-8b87-a685a01a63cd']['data'], $pim_category_taxonomy . '_' . $term_id );
						}
						if ( isset( $p_data['website_series_description|4b482060-f242-4be1-93ba-075bc5277840']['data'] ) ) {
							\update_field( 'field_64ca9ae76ae8b', $p_data['website_series_description|4b482060-f242-4be1-93ba-075bc5277840']['data'], $pim_category_taxonomy . '_' . $term_id );
						}
						if ( isset( $p_data['website_product_series_features_and_benefits|3c6be35b-99d8-4777-92a3-2755c097c457']['data'] ) ) {
							\update_field( 'field_654a8564f0652', $p_data['website_product_series_features_and_benefits|3c6be35b-99d8-4777-92a3-2755c097c457']['data'], $pim_category_taxonomy . '_' . $term_id );
						}
						if ( isset( $file_asset_url ) ) {
							\update_field( 'field_64ca9b15c15c2', $file_asset_url, $pim_category_taxonomy . '_' . $term_id );
						}
					}
				} catch ( \Exception $e ) {
					$errorMessage = $e->getMessage();
					\trigger_error( 'Exception: ' . $errorMessage, E_USER_NOTICE );
				}
			}
		}
		$options       = get_option( MBEK_OPTIONS );
		$delete_option = $options['mbek_pim_delete_categories'];
		if ( $delete_option == true ) {
			$delete_terms = array();
			if ( ! empty( $new_taxs ) ) {
				foreach ( $new_taxs as $new_tax ) {
					$category_code_from_tax = get_field( 'field_64ca9a2853ccf', $pim_category_taxonomy . '_' . $new_tax->term_id );
					if ( ! in_array( $category_code_from_tax, $pim_category_codes ) ) {
						$delete_terms[] = $new_tax->term_id;
						wp_delete_term( $new_tax->term_id, $pim_category_taxonomy );
					}
				}
//				trigger_error( 'delete_terms: ' . print_r( $delete_terms, true ), E_USER_NOTICE );
			}
		}

	}

	/**
	 * Saves a brand category item to the database.
	 *
	 * @param array $item The brand category item to be saved.
	 */
	public function save_brand_categories( $item ) {
		global $wpdb;
		$table_name = $wpdb->prefix . MBEK_PIM_CATEGORY_TABLE_NAME;
		// Check if a record exist with this code.
		$pim_id          = $wpdb->get_var(
			$wpdb->prepare(
				'SELECT id
					   FROM ' . $table_name . '
					  WHERE code = %s',
				$item['code']
			)
		);
		$pim_data        = array(
			'updated' => $item['updated'],
			'code'    => $item['code'],
			'parent'  => $item['parent'],
			'labels'  => serialize( $item['labels'] ),
			'data'    => serialize( $item['values'] ),
		);
		$pim_data_format = array(
			'%s',
			'%s',
			'%s',
			'%s',
			'%s',
		);
		if ( $pim_id ) {
			$wpdb->update(
				$table_name,
				$pim_data,
				array( 'id' => $pim_id ),
				$pim_data_format,
				array( '%d' )
			);
		} else {
			$wpdb->insert(
				$table_name,
				$pim_data,
				$pim_data_format
			);
		}
	}

	/**
	 * Class Element
	 *
	 * Represents a generic element in a system.
	 */
	public function flatten_categories( $element ) {
		$flatArray = array();
		foreach ( $element as $key => $node ) {
			if ( array_key_exists( 'child', $node ) ) {
				$flatArray = array_merge( $flatArray, $this->flatten_categories( $node['child'] ) );
				unset( $node['child'] );
				$flatArray[ $node['code'] ] = $node['label'];
			} else {
				$flatArray[ $node['code'] ] = $node['label'];
			}
		}

		return $flatArray;
	}

	/**
	 * Build a hierarchical tree structure.
	 *
	 * This method takes an unsorted array and constructs a nested tree
	 * based on parent-child relationships starting from a specified node.
	 *
	 * @param array $unsorted The unsorted array containing nodes with parent-child relationships.
	 * @param mixed $start_node The starting node identifier to build the tree from.
	 *
	 * @return array The hierarchical tree structure starting from the specified node.
	 */
	public function build_tree( &$unsorted, $start_node ) {
		$out = array();
		foreach ( $unsorted as $key => $node ) {
			if ( $node['parent'] === $start_node ) {
				$node['child'] = $this->build_tree( $unsorted, $key );
				unset( $unsorted[ $key ] );
				$out[] = $node;
			}
		}

		return $out;
	}

	/**
	 * Returns an array of product categories.
	 *
	 * @return array An array of product categories.
	 */
	public function get_product_categories() {
		// Builder for Search.
		// $searchBuilder = new SearchBuilder();
		$searchBuilder = $this->setup_search_builder(
			array(
				'use_dates' => false,
			)
		);
		// $searchBuilder->addFilter( 'enabled', '=', true )
		// ->addFilter( 'is_primary', '=', true );
		// if ( $this->get_brand() ) {
		// $searchBuilder->addFilter( 'brand', 'IN', [ $this->get_brand() ], [
		// 'locale' => $this->get_default_locale(),
		// 'scope'  => 'default'
		// ] );
		// }
		$categories   = array();
		$searchFilter = $searchBuilder->getFilters();
		$firstPage    = $this->client->getProductUuidApi()->all( 100, array( 'search' => $searchFilter ) );
		foreach ( $firstPage as $item ) {
			if ( ! empty( $item['categories'] ) ) {
				foreach ( $item['categories'] as $cat ) {
					$categories[ $cat ] = $cat;
				}
			}
		}
		echo $this->i_print( $categories, '$categories' );
	}

	/**
	 * Retrieves a product by its code.
	 *
	 * @param mixed $code The product code.
	 *
	 * @return void
	 */
	public function get_product( $code ) {
		// Builder for Search.
		$searchBuilder = new SearchBuilder();
		$options       = get_option( MBEK_OPTIONS );
		if ( ! empty( $options['mbek_pim_enabled'] ) && $options['mbek_pim_enabled'] ) {
			$searchBuilder->addFilter( 'enabled', '=', true );
		}
		$searchBuilder->addFilter( 'uuid', '=', $code );
		$products     = array();
		$searchFilter = $searchBuilder->getFilters();
		$firstPage    = $this->client->getProductUuidApi()->all( 100, array( 'search' => $searchFilter ) );
		foreach ( $firstPage as $item ) {
			$products[] = $item;
		}
		echo $this->i_print( $products, '$products' );
	}

	/**
	 * Retrieves products by model.
	 *
	 * @param string $model The model of the product.
	 *
	 * @return array An array containing the products found.
	 */
	public function get_product_by_model( $model ) {
		$searchBuilder = new SearchBuilder();
		$searchBuilder->addFilter(
			'model',
			'=',
			$model,
			array(
				'locale' => $this->get_default_locale(),
				'scope'  => 'default',
			)
		);
		if ( isset( $settings['enabled'] ) && $settings['enabled'] ) {
			$searchBuilder->addFilter( 'enabled', '=', true );
		}
		if ( isset( $settings['is_primary'] ) && $settings['is_primary'] ) {
			$searchBuilder->addFilter( 'is_primary', '=', true );
		}
		$products     = array();
		$searchFilter = $searchBuilder->getFilters();
		$firstPage    = $this->client->getProductUuidApi()->all( 100, array( 'search' => $searchFilter ) );
		$products     = $new_products = array();

		$counter = 0;
		foreach ( $firstPage as $item ) {
			echo $this->i_print( $item, '$item' );
			$product = $this->create_product( $item );

			$products[]     = $product;
			$new_products[] = $this->transform_product( $product );
			++ $counter;
		}
		echo $this->i_print( $new_products, '$new_products' );
	}

	/**
	 * Updates the `updated` date for entries in the `pim_data` table that match the provided codes.
	 *
	 * @param array $codes An array of codes to update the `updated` date for.
	 *
	 * @return void
	 */
	public function update_date_for_pim_cache( $codes ) {
		global $wpdb;
		if ( ! isset( $codes ) || empty( $codes ) ) {
			return;
			// wp_die( 'Error no $codes given!' );
		}
		$table_name = $wpdb->prefix . MBEK_PIM_DATA_TABLE_NAME;

		// Split the $codes into chunkes of 20.
		$chunky_codes = array_chunk( $codes, 20 );
		$pim_codes    = array();
		foreach ( $chunky_codes as $chunked ) {
			$regex_expression = implode( '|', $chunked );
			$today            = date( 'Y-m-d H:i:s', time() );
			// set the updated_date for entries in pim_data table that match.
			$wpdb->query(
				$wpdb->prepare(
					"UPDATE $table_name
				  	    SET `updated` = %s
			          WHERE data REGEXP %s",
					$today,
					$regex_expression
				)
			);
		}
	}

	/**
	 * Synchronize PIM data by asset code.
	 *
	 * This method retrieves data from the PIM data table that matches the given asset code,
	 * and performs updates on the corresponding records.
	 *
	 * @param string $code The asset code to sync.
	 *
	 * @return void
	 */
	public function sync_pim_by_asset( $code ) {
		global $wpdb;
		if ( ! isset( $code ) ) {
			wp_die( 'Error no $code given!' );
		}
		$table_name  = $wpdb->prefix . MBEK_PIM_DATA_TABLE_NAME;
		$results     = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT uuid
			   FROM $table_name
			  WHERE data LIKE %s",
				'%' . $wpdb->esc_like( $code ) . '%'
			),
			ARRAY_A
		);
		$ret_results = array();
		if ( ! empty( $results ) ) {
			echo '<pre>' . print_r( $results, true ) . '</pre>';
			foreach ( $results as $row ) {
				if ( isset( $row['uuid'] ) ) {
					$ret_results[] = $this->update_from_pim_table( 0, false, $row['uuid'] );
				}
			}
		}
		// echo '<pre>' . print_r( $ret_results, true ) . '</pre>';
	}

	/**
	 * Retrieves a product from the PIM table based on its UUID.
	 *
	 * @param string uuid The product UUID.
	 *
	 * @return array The product information.
	 */
	public function get_product_by_uuid( $uuid ) {
		echo 'called get_product_by_uuid';
		$ret = $this->update_from_pim_table( 0, false, $uuid );
		echo '<pre>' . print_r( $ret, true ) . '</pre>';
	}

	/**
	 * Get accessory by UUID.
	 *
	 * This method retrieves an accessory based on the provided UUID.
	 * It calls the update_accessories_from_pim_table method to update the accessories
	 * from the PIM table and outputs the result.
	 *
	 * @param string $uuid The UUID of the accessory.
	 *
	 * @return void
	 */
	public function get_accessory_by_uuid( $uuid ) {
		echo 'called get_accessory_by_uuid';
		$ret = $this->update_accessories_from_pim_table( 0, false, $uuid );
		echo '<pre>' . print_r( $ret, true ) . '</pre>';
	}

	/**
	 * Retrieves all families and their total count for a specific post type.
	 *
	 * @return array              An associative array where the keys are the family names and the values are the total count for each family.
	 * @global wpdb $wpdb The WordPress database object.
	 */
	public function get_all_families() {
		global $wpdb;
		$families = array();

		$options   = get_option( MBEK_OPTIONS );
		$post_type = $options['mbek_post_type'];

		$table_name = $wpdb->prefix . MBEK_PIM_DATA_TABLE_NAME;
		$results    = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT family, COUNT(family) AS total
                   FROM $table_name
                  WHERE post_type = %s
               GROUP BY family
               ORDER BY family",
				$post_type
			),
			ARRAY_A
		);
		if ( ! empty( $results ) ) {
			foreach ( $results as $row ) {
				$families[ $row['family'] ] = $row['total'];
			}
		}

		update_option( MBEK_FAMILIES, $families );

		return $families;
	}

	/**
	 * Retrieves all PIM data from the database.
	 *
	 * @return mixed[] An array of PIM data.
	 * @global wpdb $wpdb WordPress database object.
	 */
	public function get_all_pim_data() {
		global $wpdb;
		$table_name = $wpdb->prefix . MBEK_PIM_DATA_TABLE_NAME;
		$results    = $wpdb->get_results(
			"SELECT *
			   FROM $table_name
		   ORDER BY id"
		);

		return $results;
	}

	/**
	 * Retrieve all PIM assets for a specified family.
	 *
	 * This method fetches all PIM assets associated with a given family
	 * from the database table and returns the results.
	 *
	 * @param string $family The family identifier to filter the PIM assets.
	 *
	 * @return array An array of results containing the PIM assets for the specified family.
	 */
	public function get_all_pim_assets_for_family( $family ) {
		global $wpdb;
		$table_name = $wpdb->prefix . MBEK_PIM_ASSETS_TABLE_NAME;
		$results    = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT *
				   FROM $table_name
				  WHERE family = %s
				ORDER BY id",
				$family
			)
		);

		return $results;
	}

	/**
	 * Clear the PIM asset table.
	 *
	 * This method truncates the PIM asset table, effectively removing all its data.
	 *
	 * @return void
	 */
	public function clear_pim_asset_table() {
		global $wpdb;
		$table_name = $wpdb->prefix . MBEK_PIM_ASSETS_TABLE_NAME;
		$wpdb->query( 'TRUNCATE TABLE ' . $table_name );
	}

	/**
	 * Save PIM asset data into the database.
	 *
	 * @param array $item The PIM asset data to save.
	 * @param string $family The family of the PIM asset.
	 *
	 * @return void
	 */
	public function save_pim_asset_data( $item, $family ) {
		global $wpdb;
		$table_name = $wpdb->prefix . MBEK_PIM_ASSETS_TABLE_NAME;
		// Check if a record exist with this code.
		$pim_id          = $wpdb->get_var(
			$wpdb->prepare(
				'SELECT id
					   FROM ' . $table_name . '
					  WHERE code = %s',
				$item['code']
			)
		);
		$pim_data        = array(
			'created' => $item['created'],
			'updated' => $item['updated'],
			'family'  => $family,
			'code'    => $item['code'],
			'data'    => serialize( $item['values'] ),
		);
		$pim_data_format = array(
			'%s',
			'%s',
			'%s',
			'%s',
			'%s',
		);
		if ( $pim_id ) {
			$wpdb->update(
				$table_name,
				$pim_data,
				array( 'id' => $pim_id ),
				$pim_data_format,
				array( '%d' )
			);
		} else {
			$wpdb->insert(
				$table_name,
				$pim_data,
				$pim_data_format
			);
		}
	}

	/**
	 * Truncates the pim_data table.
	 *
	 * @return void
	 * @global wpdb $wpdb WordPress database abstraction object.
	 */
	public function truncate_pim_data() {
		global $wpdb;
		// Truncate the pim_data table.
		$table_name = $wpdb->prefix . MBEK_PIM_DATA_TABLE_NAME;
		$wpdb->query( "TRUNCATE $table_name" );
		// Also Truncate the pim_assets (cache) table.
		$table_name = $wpdb->prefix . MBEK_PIM_ASSETS_TABLE_NAME;
		$wpdb->query( "TRUNCATE $table_name" );
	}

	/** Refresh the cache data table from PIM.
	 *
	 * Clears the cache table and then re-populates it with data from PIM.
	 *
	 * @return mixed[] An array of PIM data.
	 */
	public function refresh_pim_data_cache_from_pim() {
		$main_products = $this->pim_products_by_brand( '', '', true, false );
		$alt_products  = $this->pim_products_by_alt_brand( '', '', true, false );
		$products      = array_merge( $main_products, $alt_products );
		$this->import_rows_to_pim_data_table( $products );

		return $products;
	}

	/**
	 * Import rows into the PIM data table.
	 *
	 * This method processes an array of rows and inserts them into the PIM data table.
	 * If no post type is provided, it fetches the default post type from the options.
	 * The rows are processed in chunks of 100 to optimize database insert operations.
	 *
	 * @param array $rows An array of rows to be imported into the PIM data table.
	 *                         Each row should contain the necessary fields for insertion.
	 * @param string $post_type Optional. The post type associated with the rows. If not provided, it defaults to the value from the options.
	 *
	 * @return void
	 */
	public function import_rows_to_pim_data_table( $rows, $post_type = '' ) {
		global $wpdb;
		if ( $post_type === '' ) {
			$options   = get_option( MBEK_OPTIONS );
			$post_type = $options['mbek_post_type'];
		}
		$table_name = $wpdb->prefix . MBEK_PIM_DATA_TABLE_NAME;
		$wpdb->query( "TRUNCATE $table_name" );
		// Split the $rows into chunkes of 100.
		$chunked_rows = array_chunk( $rows, 100, true );
		foreach ( $chunked_rows as $chunked ) {
			$counter = 0;
			$query   = "INSERT INTO $table_name (created, updated, uuid, model, family, post_type, categories, groups, data, associations, quantified_associations, metadata) VALUES ";
			foreach ( $chunked as $row ) {
				$counter ++;
				$created                 = $row['created'];
				$updated                 = $row['updated'];
				$uuid                    = $row['uuid'];
				$model                   = esc_sql( trim( strtoupper( $row['values']['model'][0]['data'] ) ) );
				$family                  = $row['family'];
				$post_type               = $post_type;
				$categories              = esc_sql( serialize( $row['categories'] ) );
				$groups                  = esc_sql( serialize( $row['groups'] ) );
				$data                    = esc_sql( serialize( $row['values'] ) );
				$associations            = esc_sql( serialize( $row['associations'] ) );
				$quantified_associations = esc_sql( serialize( $row['quantified_associations'] ) );
				$metadata                = esc_sql( serialize( $row['metadata'] ) );

				$query .= sprintf(
					"\n('%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s')",
					$created,
					$updated,
					$uuid,
					$model,
					$family,
					$post_type,
					$categories,
					$groups,
					$data,
					$associations,
					$quantified_associations,
					$metadata
				);
				if ( $counter < count( $chunked ) ) {
					$query .= ', ';
				}
			}
			$wpdb->query( "$query" );
		}

		$this->update_cron_timestamp( 'products' );
	}

	/**
	 * Save PIM data to the database.
	 *
	 * @param array $item The PIM data to be saved.
	 * @param string $post_type Optional. The post type to associate with the PIM data. Defaults to the value stored in the MBEK_OPTIONS option.
	 *
	 * @return void
	 * @global object $wpdb WordPress database access abstraction object.
	 */
	public function save_pim_data( $item, $post_type = '' ) {
		global $wpdb;
		if ( $post_type === '' ) {
			$options   = get_option( MBEK_OPTIONS );
			$post_type = $options['mbek_post_type'];
		}
		if ( isset( $item )
		     && is_array( $item )
		     && isset( $item['values']['model'][0]['data'] )
		     && $item['values']['model'][0]['data']
		) {
			$table_name = $wpdb->prefix . MBEK_PIM_DATA_TABLE_NAME;
			$model      = trim( strtoupper( $item['values']['model'][0]['data'] ) );
			// Check if a record exist with this UUID.
			$pim_id          = $wpdb->get_var(
				$wpdb->prepare(
					'SELECT id
					   FROM ' . $table_name . '
					  WHERE uuid = %s
					    AND post_type = %s',
					$item['uuid'],
					$post_type
				)
			);
			$pim_data        = array(
				'created'                 => $item['created'],
				'updated'                 => $item['updated'],
				'uuid'                    => $item['uuid'],
				'model'                   => $model,
				'family'                  => $item['family'],
				'post_type'               => $post_type,
				'categories'              => serialize( $item['categories'] ),
				'groups'                  => serialize( $item['groups'] ),
				'data'                    => serialize( $item['values'] ),
				'associations'            => serialize( $item['associations'] ),
				'quantified_associations' => serialize( $item['quantified_associations'] ),
				'metadata'                => serialize( $item['metadata'] ),
			);
			$pim_data_format = array(
				'%s', // created.
				'%s', // updated.
				'%s', // uuid.
				'%s', // model.
				'%s', // family.
				'%s', // post_type.
				'%s', // categories.
				'%s', // groups.
				'%s', // data.
				'%s', // associations.
				'%s', // quantified_associations.
				'%s', // metadata.
			);
			if ( $pim_id ) {
				$wpdb->update(
					$table_name,
					$pim_data,
					array( 'id' => $pim_id ),
					$pim_data_format,
					array( '%d' )
				);
			} else {
				$wpdb->insert(
					$table_name,
					$pim_data,
					$pim_data_format
				);
			}
		}
	}

	/**
	 * Get all products from the PIM.
	 *
	 * @return array An array of products.
	 */
	public function get_all_pim() {
		global $wpdb;
		$products      = array();
		$searchBuilder = $this->setup_search_builder(
			array(
				'use_dates' => false,
			)
		);

		$searchFilter = $searchBuilder->getFilters();
		$firstPage    = $this->client->getProductUuidApi()->all( 100, array( 'search' => $searchFilter ) );

		foreach ( $firstPage as $item ) {
			$this->save_pim_data( $item );
			$model              = trim( strtoupper( $item['values']['model'][0]['data'] ) );
			$products[ $model ] = array(
				'uuid'                    => $item['uuid'],
				// 'identifier'              => $item['identifier'],
				'model'                   => $model,
				'created'                 => $item['created'],
				'updated'                 => $item['updated'],
				'associations'            => $item['associations'],
				'quantified_associations' => $item['quantified_associations'],
				'data'                    => $item['values'],
			);
		}

		return $products;
	}

	/**
	 * Get all accessories.
	 *
	 * This method retrieves all accessories based on the specified post type from the options.
	 *
	 * @return array The array of accessories with their corresponding information.
	 */
	public function get_all_accessories( $page = 1 ) {
		$options     = get_option( MBEK_OPTIONS );
		$post_type   = $options['mbek_accessory_post_type'];
		$offset      = 10 * ( $page - 1 );
		$search_args = array(
			'numberposts' => - 1,
			'post_type'   => $post_type,
			'fields'      => 'ids',
		);
		$wp_args     = array(
			'meta_query'    => array(
				'relation' => 'AND',
				array(
					'key'     => 'pim_uuid',
					'value'   => '',
					'compare' => '!=',
				),
			),
			'post_type'     => $post_type,
			'fields'        => 'ids',
			'offset'        => $offset,
			'post_per_page' => 10,
		);
		if ( isset( $_REQUEST['filter'] ) ) {
			// Get any filters from $_REQUEST.
			foreach ( $_REQUEST['filter'] as $filter ) {
				if ( $filter['value'] !== '' ) {
					switch ( $filter['field'] ) {
						case 'uuid':
							$wp_args['meta_query'][] = array(
								'key'     => 'pim_uuid',
								'value'   => $filter['value'],
								'compare' => '=',
							);
							break;
						case 'title':
							$wp_args['s'] = $filter['value'];
							break;
					}
				}
			}
		}
		$query = new \WP_Query( $wp_args );
		$total = $query->found_posts;
		// trigger_error( '$total: ' . $total, E_USER_NOTICE );
		$bp_products = array();
		if ( $query->have_posts() ) {
			while ( $query->have_posts() ) {
				$query->the_post();
				$post_id       = get_the_ID();
				$pim_uuid      = get_field( 'pim_uuid', $post_id ) ?? '';
				$bp_products[] = array(
					'id'       => $post_id,
					'name'     => get_the_title(),
					'pim_uuid' => trim( $pim_uuid ),
				);
			}
		}
		wp_reset_postdata();

		return array(
			'total' => $total,
			'data'  => $bp_products,
		);
		// $posts       = get_posts( $search_args );
		// $accessories = array();
		// if ( $posts && is_array( $posts ) ) {
		// foreach ( $posts as $post ) {
		// $pim_uuid      = get_field( 'pim_uuid', $post ) ?? '';
		// $accessories[] = array(
		// 'id'          => $post,
		// 'name'        => get_the_title( $post ),
		// 'pim_uuid'    => trim( $pim_uuid ),
		// );
		// }
		// }
		// return $accessories;
	}

	/**
	 * Retrieves all products.
	 *
	 * Retrieves all products from the PIM database and filters them based on the provided criteria.
	 *
	 * @param bool $have_pim_data Optional. Whether to filter the products based on the presence of PIM data.
	 *                           Default is false.
	 *
	 * @return array An array of products. Each product is represented as an array with the following keys:
	 *               - id: The ID of the product post in WordPress.
	 *               - name: The name of the product post.
	 *               - model_field: The model number of the product post.
	 *               - pim_model: The PIM model of the product post.
	 *               - model_found: Whether the model number exists in the PIM database.
	 *               - pim_uuid: The PIM UUID of the product post.
	 */
	public function get_all_products( $page = 1 ) {
		$options       = get_option( MBEK_OPTIONS );
		$post_type     = $options['mbek_post_type'];
		$model_field   = $options['mbek_model_field'];
		$use_only_uuid = $options['mbek_use_only_uuid'] ?? false;
		$offset        = 10 * ( $page - 1 );
		if ( ! $use_only_uuid ) {
			$wp_args = array(
				// 'meta_query'    => array(
				// 'relation' => 'AND',
				// array(
				// 'key'     => 'pim_uuid',
				// 'value'   => '',
				// 'compare' => '!='
				// ),
				// ),
				'post_type'     => $post_type,
				'fields'        => 'ids',
				'offset'        => $offset,
				'post_per_page' => 10,
			);
		} else {
			$wp_args = array(
				'meta_query'    => array(
					'relation' => 'AND',
					array(
						'key'     => 'pim_uuid',
						'value'   => '',
						'compare' => '!=',
					),
				),
				'post_type'     => $post_type,
				'fields'        => 'ids',
				'offset'        => $offset,
				'post_per_page' => 10,
			);
		}

		if ( isset( $_REQUEST['filter'] ) ) {
			// Get any filters from $_REQUEST.
			foreach ( $_REQUEST['filter'] as $filter ) {
				if ( $filter['value'] !== '' ) {
					switch ( $filter['field'] ) {
						case 'uuid':
							$wp_args['meta_query'][] = array(
								'key'     => 'pim_uuid',
								'value'   => $filter['value'],
								'compare' => '=',
							);
							break;
						case 'title':
							$wp_args['s'] = $filter['value'];
							break;
					}
				}
			}
		}
		$query = new \WP_Query( $wp_args );
		$total = $query->found_posts;
		// trigger_error( '$total: ' . $total, E_USER_NOTICE );
		$bp_products = array();
		if ( $query->have_posts() ) {
			while ( $query->have_posts() ) {
				$query->the_post();
				$post_id       = get_the_ID();
				$model_number  = ( $model_field == 'post_title' )
					? get_the_title()
					: get_field( $model_field, $post_id ) ?? '';
				$pim_uuid      = get_field( 'pim_uuid', $post_id ) ?? '';
				$bp_products[] = array(
					'id'       => $post_id,
					'name'     => get_the_title(),
					'model'    => trim( $model_number ),
					'pim_uuid' => trim( $pim_uuid ),
				);
			}
		}
		wp_reset_postdata();

		return array(
			'total' => $total,
			'data'  => $bp_products,
		);
	}

	/**
	 * Sets up the search builder with the given configuration.
	 *
	 * @param array $config An array of configuration options for the search builder.
	 *                      Possible keys:
	 *                      - start_date: The start date for filtering the search results. Default is an empty string.
	 *                      - end_date: The end date for filtering the search results. Default is an empty string.
	 *                      - first_run: A boolean indicating whether it is the first run. Default is false.
	 *                      - use_dates: A boolean indicating whether to use the start and end dates for filtering. Default is false.
	 *                      - brand: The brand to filter the search results. Default is null.
	 *                      - is_primary: A boolean indicating whether to filter by primary status. Default is null.
	 *                      - enabled: A boolean indicating whether to filter by enabled status. Default is null.
	 *
	 * @return SearchBuilder The configured search builder instance.
	 */
	public function setup_search_builder( $config = array() ) {
		$defaults = array(
			'start_date' => '',
			'end_date'   => '',
			'first_run'  => false,
			'use_dates'  => false,
			'brand'      => null,
			'is_primary' => null,
			'enabled'    => null,
		);
		$settings = array_merge( $defaults, $config );
		// Builder for Search.
		$searchBuilder = new SearchBuilder();
		$options       = get_option( MBEK_OPTIONS );
		if ( isset( $settings['brand'] ) ) {
			if ( isset( $settings['enabled'] ) && $settings['enabled'] ) {
				$searchBuilder->addFilter( 'enabled', '=', true );
			}
			if ( isset( $settings['is_primary'] ) && $settings['is_primary'] ) {
				$searchBuilder->addFilter( 'is_primary', '=', true );
			}
			if ( $settings['brand'] ) {
				$searchBuilder->addFilter(
					'brand',
					'IN',
					array( $settings['brand'] ),
					array(
						'locale' => 'en_US', // $this->get_default_locale(),
						'scope'  => 'default',
					)
				);
			}
		} else {
			if ( ! empty( $options['mbek_pim_enabled'] ) && $options['mbek_pim_enabled'] ) {
				$searchBuilder->addFilter( 'enabled', '=', true );
			}
			if ( ! empty( $options['mbek_pim_is_primary'] ) && $options['mbek_pim_is_primary'] ) {
				$searchBuilder->addFilter( 'is_primary', '=', true );
			}
			if ( $this->get_brand() ) {
				$searchBuilder->addFilter(
					'brand',
					'IN',
					array( $this->get_brand() ),
					array(
						'locale' => 'en_US', // $this->get_default_locale(),
						'scope'  => 'default',
					)
				);
			}
		}

		if ( $settings['use_dates'] ) {
			$date_format = 'Y-m-d H:m:s';
			if ( $settings['start_date'] ) {
				$start = strtotime( $settings['start_date'] );
			} else {
				$start = 0;
			}
			if ( $settings['end_date'] ) {
				$end = strtotime( $settings['end_date'] );
			} else {
				$end = 0;
			}
			if ( $start && $end ) {
				$searchBuilder->addFilter( 'updated', 'BETWEEN', array( date( 'c', $start ), date( 'c', $end ) ) );
			} elseif ( $start && ! $end ) {
				$searchBuilder->addFilter( 'updated', '>', date( $date_format, $start ) );
			} elseif ( ! $settings['first_run'] ) {
				$searchBuilder->addFilter( 'updated', 'SINCE LAST N DAYS', 1 );
			}
		}

		return $searchBuilder;
	}

	/**
	 * Retrieves the PIM products by alternative brand.
	 *
	 * @param string $start_date The start date for filtering the products.
	 * @param string $end_date The end date for filtering the products.
	 * @param bool $first_run Flag to indicate if it's the first run.
	 *
	 * @return array The array of PIM products by alternative brand.
	 */
	public function pim_products_by_alt_brand( $start_date, $end_date, $first_run = false ) {
		$date_format = 'Y-m-d H:m:s';
		$products    = array();

		$brand_options = get_option( MBEK_ALT_BRANDS );
		if ( ! empty( $brand_options ) ) {
			foreach ( $brand_options as $brand_key => $option ) {
				$searchBuilder = $this->setup_search_builder(
					array(
						'start_date' => $start_date,
						'end_date'   => $end_date,
						'first_run'  => $first_run,
						'use_dates'  => ! $first_run,
						'brand'      => $option['brand'],
						'enabled'    => ( isset( $option['enabled'] ) ) ? $option['enabled'] : false,
						'is_primary' => ( isset( $option['is_primary'] ) ) ? $option['is_primary'] : false,
					)
				);
				$options       = get_option( MBEK_OPTIONS );
				if ( $options['mbek_has_accessories'] ) {
					$searchBuilder->addFilter( 'product_or_accessory', 'IN', array( 'Product' ) );
				}
				$searchFilter = $searchBuilder->getFilters();
				$firstPage    = $this->client->getProductUuidApi()->all(
					100,
					array(
						'search'                 => $searchFilter,
						'with_attribute_options' => true,
					)
				);

				foreach ( $firstPage as $item ) {
					$products[] = $item;
				}
			}
		}

		return $products;
	}

	/**
	 * Retrieves products by alternative brand within a specified date range.
	 *
	 * @param mixed $start_date The start date for filtering the products.
	 * @param mixed $end_date The end date for filtering the products.
	 * @param bool $first_run Determines if it is the first run of the method.
	 *
	 * @return array The array of products matching the alternative brand.
	 */
	public function get_products_by_alt_brand( $start_date, $end_date, $first_run = false ) {
		$products = $this->pim_products_by_alt_brand( $start_date, $end_date, $first_run );
		foreach ( $products as $item ) {
			$this->save_pim_data( $item );
		}
		$this->update_cron_timestamp( 'products' );

		return $products;
	}

	/**
	 * Retrieves products by brand within a specified date range.
	 *
	 * @param string $start_date The start date of the date range in 'Y-m-d H:m:s' format.
	 * @param string $end_date The end date of the date range in 'Y-m-d H:m:s' format.
	 * @param bool $first_run A flag indicating if it is the first run or not. Default is false.
	 *
	 * @return array The array of products retrieved from the PIM by brand within the specified date range.
	 */
	public function pim_products_by_brand( $start_date, $end_date, $first_run = false, $save_to_db = true ) {
		$date_format = 'Y-m-d H:m:s';

		$searchBuilder = $this->setup_search_builder(
			array(
				'start_date' => $start_date,
				'end_date'   => $end_date,
				'first_run'  => $first_run,
				'use_dates'  => ! $first_run,
			)
		);
		$options       = get_option( MBEK_OPTIONS );
		if ( isset( $options['mbek_has_accessories'] ) && $options['mbek_has_accessories'] ) {
			$searchBuilder->addFilter( 'product_or_accessory', 'IN', array( 'Product' ) );
		}
		if ( isset( $options['mbek_categories_restriction'] ) && $options['mbek_categories_restriction'] ) {
			$searchBuilder->addFilter( 'categories', 'IN CHILDREN', array( $options['mbek_categories_restriction'] ) );
		}
		if ( isset( $options['mbek_sync_only_from_website_tree'] ) && $options['mbek_sync_only_from_website_tree'] ) {
			$searchBuilder->addFilter( 'categories', 'IN CHILDREN', array( strtolower( $this->get_brand() . '_Website' ) ) );
		}

		$searchFilter = $searchBuilder->getFilters();
		trigger_error( print_r( $searchFilter, true ), E_USER_NOTICE );
		$firstPage    = $this->client->getProductUuidApi()->all(
			100,
			array(
				'search'                 => $searchFilter,
				'with_attribute_options' => true,
			)
		);

		$products = array();
		foreach ( $firstPage as $item ) {
			if ( $save_to_db ) {
				$this->save_pim_data( $item );
			}
			$products[] = $item;
		}

		return $products;
	}

	/**
	 * Links products to accessories based on the provided options.
	 *
	 * @return array An array of the linked accessories.
	 */
	public function link_products_to_accessories() {
		$options             = get_option( MBEK_OPTIONS );
		$post_type           = $options['mbek_post_type'];
		$accessory_post_type = $options['mbek_accessory_post_type'];
		$accessories         = array();

		if ( ! $accessory_post_type ) {
			return $accessories;
		}

		$total_products = $this->get_pim_association_data( 0, true );
		// trigger_error( 'get_pim_assocation_data: ' . print_r( $total_products, true ), E_USER_NOTICE );

		if ( ! empty( $total_products['products'] ) ) {
			// Check parent to assessories to see if the accessories are saved.
			// If so and the setting for Accessory related field is set
			// Setup the Assocation to these accessories for each product.
			$related_field = $options['mbek_accessory_acf_related_field'];
			if ( $related_field ) {
				foreach ( $total_products['products'] as $product => $prod_data ) {
					$product_id    = $this->get_post_id_from_uuid( $product, $post_type );
					$accessory_ids = array();
					// trigger_error('$product_id: '.$product_id, E_USER_NOTICE);
					foreach ( $prod_data as $pim_uuid ) {
						$accessory_id = $this->get_post_id_from_uuid( $pim_uuid, $accessory_post_type );
						if ( $accessory_id ) {
							$accessory_ids[] = $accessory_id;
							// trigger_error( '$accessory_id: '. print_r( $accessory_id, true ), E_USER_NOTICE );
							update_field( $related_field, $accessory_ids, $product_id );
						}
					}
				}
			}
		}
	}

	/**
	 * Retrieves the PIM accessories.
	 *
	 * @return array An array of PIM accessories.
	 */
	public function pim_accessories() {
		$options             = get_option( MBEK_OPTIONS );
		$post_type           = $options['mbek_post_type'];
		$accessory_post_type = $options['mbek_accessory_post_type'];
		$accessories         = array();

		if ( ! $accessory_post_type ) {
			return $accessories;
		}

		$total_products = $this->get_pim_association_data( 0, true );
		// trigger_error( 'get_pim_assocation_data: ' . print_r( $total_products, true ), E_USER_NOTICE );
		if ( ! empty( $total_products['accessories'] ) ) {
			$partial = array_chunk( $total_products['accessories'], 100 );

			foreach ( $partial as $products ) {
				$searchBuilder = new SearchBuilder();
				$searchBuilder->addFilter( 'enabled', '=', true );
				// $searchBuilder->addFilter( 'is_primary', '=', true );
				$searchBuilder->addFilter( 'product_or_accessory', 'IN', array( 'Accessory' ) );
				$searchBuilder->addFilter( 'uuid', 'IN', array_values( $products ) );
				$searchFilter = $searchBuilder->getFilters();

				// trigger_error('searchFilters: '.print_r($searchFilter, true), E_USER_NOTICE);
				$firstPage = $this->client->getProductUuidApi()->all(
					100,
					array(
						'search'                 => $searchFilter,
						'with_attribute_options' => true,
					)
				);

				foreach ( $firstPage as $item ) {
					$accessories[] = $item;
					$this->save_pim_data( $item, $accessory_post_type );
				}
			}
		}

		return $accessories;
	}

	/**
	 * Retrieves the post ID from the given UUID and post type.
	 *
	 * @param mixed $uuid The UUID value to search for in the "pim_uuid" meta field.
	 * @param string $post_type The post type to search for the UUID.
	 *
	 * @return int|false The post ID if found, otherwise false.
	 */
	public function get_post_id_from_uuid( $uuid, $post_type ) {
		global $wpdb;
		$ret = get_posts(
			array(
				'numberposts' => 1,
				'post_type'   => $post_type,
				'fields'      => 'ids',
				'meta_query'  => array(
					array(
						'key'     => 'pim_uuid',
						'value'   => $uuid,
						'compare' => '=',
					),
				),
			)
		);
		// trigger_error('$ret: '.print_r($ret, true), E_USER_NOTICE);
		if ( isset( $ret[0] ) ) {
			return $ret[0];
		} else {
			return false;
		}
	}

	/**
	 * Retrieves the PIM downloads for a given brand.
	 *
	 * @param string $brand The brand name.
	 *
	 * @return array The array of PIM downloads for the specified brand.
	 */
	public function get_pim_downloads_by_brand( $brand ) {
		global $wpdb;
		$downloads = array();
		$options   = get_option( MBEK_OPTIONS );
		$post_type = $options['mbek_post_type'];
		$term      = get_term_by( 'name', 'Cibo', 'brand', ARRAY_A );
		$posts     = get_posts(
			array(
				'post_type'   => $post_type,
				'numberposts' => - 1,
				'fields'      => 'ids',
				'tax_query'   => array(
					array(
						'taxonomy' => 'brand',
						'field'    => 'id',
						'terms'    => $term['term_id'],
					),
				),
			)
		);
		if ( ! empty( $posts ) ) {
			foreach ( $posts as $post ) {
				$post_downloads = get_field( 'pim_photofeature', $post );
				if ( ! empty( $post_downloads ) ) {
					foreach ( $post_downloads as $p_down ) {
						$downloads[] = $p_down['file_url'];
					}
				}
			}
		}

		return $downloads;
	}

	/**
	 * Retrieves products by brand within a specified date range.
	 *
	 * @param string $start_date The start date for filtering products by brand.
	 * @param string $end_date The end date for filtering products by brand.
	 * @param bool $first_run Optional flag indicating if it is the first run. Default is false.
	 *
	 * @return array The array of retrieved products.
	 */
	public function get_products_by_brand( $start_date, $end_date, $first_run = false ) {
		$products = $this->pim_products_by_brand( $start_date, $end_date, $first_run );
		// Moved the save_pim_data call to inside the pim_products_by_brand method.
//		foreach ( $products as $item ) {
		// $this->save_pim_data( $item );
//		}
		$this->update_cron_timestamp( 'products' );

		return $products;
	}

	/**
	 * Updates assets from PIM table.
	 *
	 * @param array $args The arguments for updating the assets.
	 *                    - 'family'      (string) The family of the assets.
	 *                    - 'code'        (string) The code of the assets.
	 *                    - 'url'         (string) The URL of the assets.
	 *                    - 'label'       (string) The short title of the assets.
	 *                    - 'post_type'   (string) The post type to update/create the assets as.
	 *
	 * @return array The updated assets.
	 */
	public function update_assets_from_pim_table( $args ) {
		global $wpdb;
		sleep( 1 );
		$family      = $args['family'];
		$pim_code    = $args['code'];
		$file_url    = $args['url'];
		$short_title = $args['label'];
		$post_type   = $args['post_type'];
		$table_name  = $wpdb->prefix . MBEK_PIM_ASSETS_TABLE_NAME;
		$total       = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT count(ID) as total
			       FROM $table_name
			      WHERE family = %s",
				$family
			)
		);
		$results     = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT *
			       FROM $table_name
			      WHERE family = %s",
				$family
			)
		);
		$assets      = array();
		if ( ! empty( $results ) ) {
			foreach ( $results as $row ) {
				$item     = array(
					'code'   => $row->code,
					'family' => $row->family,
					'values' => unserialize( $row->data ),
				);
				$assets[] = $item;
			}
		}

		if ( ! empty( $assets ) ) {
			foreach ( $assets as $key => $asset ) {
				$post_id          = $wpdb->get_var(
					$wpdb->prepare(
						"SELECT post_id
                           FROM $wpdb->postmeta
                          WHERE meta_key = %s
                            AND meta_value = %s",
						'pim_code',
						$asset['code'],
					)
				);
				$post_title       = $asset['code'];
				$post_data_fields = array(
					'post_status' => 'publish',
					'post_title'  => $post_title,
					'post_type'   => $post_type,
				);
				if ( $post_id ) {
					$assets[ $key ]['post_id'] = (int) $post_id;
					$post_data_fields['ID']    = (int) $post_id;
					wp_update_post( $post_data_fields );
				} else {
					$post_id                   = wp_insert_post( $post_data_fields );
					$assets[ $key ]['post_id'] = $post_id;
				}
				if ( $post_id ) {
					$file_url_name = $asset['values']['url'][0]['data'];
					update_field( $pim_code, $asset['code'], $post_id );
					if ( ! empty( $asset['values']['label'][0]['data'] ) ) {
						update_field( $short_title, $asset['values']['label'][0]['data'], $post_id );
					}
					update_field( $file_url, $file_url_name, $post_id );
				}
			}
		}

		return $assets;
		// return array(
		// 'total' => (int)$total,
		// 'number' => count($assets),
		// 'data' => $assets,
		// );
	}

	/**
	 * Update the "updated" date for PIM data with the given UUID.
	 *
	 * @param mixed $uuid The UUID of the PIM data to update.
	 *
	 * @return void
	 */
	public function update_date_for_pim_data( $uuid ) {
		global $wpdb;
		$today      = date( 'Y-m-d H:i:s', strtotime( 'today' ) );
		$table_name = $wpdb->prefix . MBEK_PIM_DATA_TABLE_NAME;
		$wpdb->update(
			$table_name,
			array( 'updated' => $today ),
			array( 'uuid' => $uuid ),
			array( '%s' ),
			array( '%s' )
		);
	}

	/**
	 * Updates accessories from the PIM table.
	 *
	 * @param int $start The starting index for pagination. Default is 0.
	 * @param bool $first_run Whether it is the first run or not. Default is false.
	 * @param string $uuid The UUID of the accessory to update. Default is null.
	 *
	 * @return array  An array containing the total number of accessories, the number of new accessories
	 *                updated, and the updated accessory data.
	 */
	public function update_accessories_from_pim_table( $start = 0, $first_run = false, $uuid = null ) {
		global $wpdb;
		$yesterday  = date( 'Y-m-d H:i:s', strtotime( '-12 hours' ) );
		$table_name = $wpdb->prefix . MBEK_PIM_DATA_TABLE_NAME;
		$options    = get_option( MBEK_OPTIONS );
		$paged      = isset( $options['mbek_paged'] ) ? $options['mbek_paged'] : 20;
		$post_type  = $options['mbek_accessory_post_type'];
		if ( $uuid ) {
			$total   = $wpdb->get_var(
				$wpdb->prepare(
					"SELECT count(ID) as total
			      FROM $table_name
			     WHERE uuid = %s",
					$uuid
				)
			);
			$results = $wpdb->get_results(
				$wpdb->prepare(
					"SELECT *
			      FROM $table_name
			     WHERE uuid = %s",
					$uuid
				)
			);
		} elseif ( ! $first_run ) {
			$total   = $wpdb->get_var(
				$wpdb->prepare(
					"SELECT count(ID) as total
			      FROM $table_name
			     WHERE updated >= %s
			       AND post_type = %s",
					$yesterday,
					$post_type
				)
			);
			$results = $wpdb->get_results(
				$wpdb->prepare(
					"SELECT *
			      FROM $table_name
			     WHERE updated >= %s
			       AND post_type = %s
			     LIMIT $paged
			    OFFSET $start",
					$yesterday,
					$post_type
				)
			);
		} else {
			$total   = $wpdb->get_var(
				$wpdb->prepare(
					"SELECT count(ID) as total
			      FROM $table_name
			     WHERE post_type = %s",
					$post_type
				)
			);
			$results = $wpdb->get_results(
				$wpdb->prepare(
					"SELECT *
			       FROM $table_name
			      WHERE post_type = %s
			      LIMIT $paged
			     OFFSET $start",
					$post_type
				)
			);
		}
		// echo '<pre>'.print_r( $results, true ).'</pre>';

		$accessories = array();
		if ( ! empty( $results ) ) {
			foreach ( $results as $row ) {
				$item          = array(
					'uuid'         => $row->uuid,
					'values'       => unserialize( $row->data ),
					'categories'   => unserialize( $row->categories ),
					'associations' => unserialize( $row->associations ),
				);
				$accessories[] = $item;
			}
		}
		// echo '<pre>'.print_r( $accessories, true ).'</pre>';

		$counter         = 0;
		$new_accessories = array();
		if ( ! empty( $accessories ) ) {
			foreach ( $accessories as $item ) {
				$accessory         = $this->create_accessory( $item );
				$new_accessories[] = $this->transform_accessory( $accessory );

			}
		}

		return array(
			'total'  => (int) $total,
			'number' => count( $new_accessories ),
			'data'   => $new_accessories,
		);
	}

	/**
	 * Updates data from the PIM table.
	 *
	 * @param int|0 $start       Optional. The starting offset for fetching the data. Default is 0.
	 * @param bool $first_run Optional. Whether it is the first run or not. Default is false.
	 * @param mixed $uuid Optional. The UUID of the data to update. Default is null.
	 *
	 * @return array {
	 *     Array containing the updated data.
	 *
	 * @type int $total The total count of data records.
	 * @type int $number The number of newly updated products.
	 * @type array $data The updated products.
	 * }
	 */
	public function update_from_pim_table( $start = 0, $first_run = false, $uuid = null ) {
		global $wpdb;
		$yesterday       = date( 'Y-m-d H:i:s', strtotime( '-12 hours' ) );
		$table_name      = $wpdb->prefix . MBEK_PIM_DATA_TABLE_NAME;
		$options         = get_option( MBEK_OPTIONS );
		$paged           = isset( $options['mbek_paged'] ) ? $options['mbek_paged'] : 20;
		$post_type       = $options['mbek_post_type'];
		$has_accessories = isset( $options['mbek_has_accessories'] ) ? $options['mbek_has_accessories'] : false;
		if ( $uuid ) {
			$total   = $wpdb->get_var(
				$wpdb->prepare(
					"SELECT count(ID) as total
			      FROM $table_name
			     WHERE uuid = %s",
					$uuid
				)
			);
			$results = $wpdb->get_results(
				$wpdb->prepare(
					"SELECT *
			      FROM $table_name
			     WHERE uuid = %s",
					$uuid
				)
			);
		} elseif ( ! $first_run ) {
			if ( $has_accessories ) {
				$total   = $wpdb->get_var(
					$wpdb->prepare(
						"SELECT count(ID) as total
			      FROM $table_name
			     WHERE updated >= %s
			       AND post_type = %s",
						$yesterday,
						$post_type
					)
				);
				$results = $wpdb->get_results(
					$wpdb->prepare(
						"SELECT *
			      FROM $table_name
			     WHERE updated >= %s
			       AND post_type = %s
		      ORDER BY ID
			     LIMIT $paged
			    OFFSET $start",
						$yesterday,
						$post_type
					)
				);
			} else {
				$total   = $wpdb->get_var(
					$wpdb->prepare(
						"SELECT count(ID) as total
			      FROM $table_name
			     WHERE updated >= %s",
						$yesterday
					)
				);
				$results = $wpdb->get_results(
					$wpdb->prepare(
						"SELECT *
			      FROM $table_name
			     WHERE updated >= %s
		      ORDER BY ID
			     LIMIT $paged
			    OFFSET $start",
						$yesterday
					)
				);
			}
		} elseif ( $has_accessories ) {
			$total   = $wpdb->get_var(
				$wpdb->prepare(
					"SELECT count(ID) as total
			      FROM $table_name
			     WHERE post_type = %s",
					$post_type
				)
			);
			$results = $wpdb->get_results(
				$wpdb->prepare(
					"SELECT *
			       FROM $table_name
			      WHERE post_type = %s
			   ORDER BY ID
			      LIMIT $paged
			     OFFSET $start",
					$post_type
				)
			);
		} else {
			$total   = $wpdb->get_var(
				"SELECT count(ID) as total
			      FROM $table_name"
			);
			$results = $wpdb->get_results(
				"SELECT *
			       FROM $table_name
	           ORDER BY ID
			      LIMIT $paged
			     OFFSET $start"
			);
		}

		$products = array();
		if ( ! empty( $results ) ) {
			foreach ( $results as $row ) {
				$item = array(
					'uuid'         => $row->uuid,
					'model'        => $row->model,
					'values'       => unserialize( $row->data ),
					'categories'   => unserialize( $row->categories ),
					'associations' => unserialize( $row->associations ),
				);
//				 echo $this->i_print( $item, '$item' );
				$products[] = $item;
			}
		}

		$counter      = 0;
		$new_products = array();
		if ( ! empty( $products ) ) {
			foreach ( $products as $item ) {
//				echo $this->i_print( $item, '$item' );
				$product        = $this->create_product( $item );
				$new_products[] = $product;
//				echo $this->i_print( $product, '$product' );
				$this->transform_product( $product );
			}
		}

		return array(
			'total'  => (int) $total,
			'number' => count( $new_products ),
			'data'   => $new_products,
		);
	}

	/**
	 * Retrieves PIM association data from the database.
	 *
	 * @param int $start The starting index of the results to retrieve. Default is 0.
	 * @param bool $first_run Optional. Indicates if it is the first run or not. Default is false.
	 *
	 * @return array Associative array containing the accessories and products.
	 *               - 'accessories' (array): Array of accessory products.
	 *               - 'products' (array): Array of parent products.
	 */
	public function get_pim_association_data( $start = 0, $first_run = false ) {
		global $wpdb;
		$yesterday  = date( 'Y-m-d H:i:s', strtotime( '-12 hours' ) );
		$paged      = 100;
		$table_name = $wpdb->prefix . MBEK_PIM_DATA_TABLE_NAME;
		$options    = get_option( MBEK_OPTIONS );
		$post_type  = $options['mbek_post_type'];
		if ( ! $first_run ) {
			$total   = $wpdb->get_var(
				$wpdb->prepare(
					"SELECT count(ID) as total
			      FROM $table_name
			     WHERE updated >= %s
			       AND post_type = %s",
					$yesterday,
					$post_type
				)
			);
			$results = $wpdb->get_results(
				$wpdb->prepare(
					"SELECT id, associations
			      FROM $table_name
			     WHERE updated >= %s
			       AND post_type = %s
			     LIMIT $paged
			    OFFSET $start",
					$yesterday,
					$post_type
				)
			);
		} else {
			$results = $wpdb->get_results(
				$wpdb->prepare(
					"SELECT id, uuid, associations
			       FROM $table_name
			      WHERE post_type = %s",
					$post_type
				)
			);
		}

		$accessories = array();
		$parents     = array();
		if ( ! empty( $results ) ) {
			foreach ( $results as $row ) {
				$associations = unserialize( $row->associations );
				if ( ! empty( $associations['related_option_or_accessory__one_way_relationship']['products'] ) ) {
					$parents[ $row->uuid ] = $associations['related_option_or_accessory__one_way_relationship']['products'];
					foreach ( $associations['related_option_or_accessory__one_way_relationship']['products'] as $prod ) {
						$accessories[ $prod ] = $prod;
					}
				}
			}
		}

		return array(
			'accessories' => $accessories,
			'products'    => $parents,
		);
	}

	/**
	 * Retrieves the headers from the product.
	 *
	 * @return array The headers from the product. Each header is represented as an element in the array.
	 * The key represents the attribute code and the value represents the attribute label in English (en_US).
	 */
	public function get_headers_from_product(): array {
		$main_attributes = get_option( MBEK_ATTRIBUTES );
		$headers         = array( 'Identifier', 'Categories' );
		$locale          = 'en_US'; // $this->get_category_locale();

		foreach ( $main_attributes as $attr ) {
			if ( isset( $attr['labels'][ $locale ] ) ) {
				$headers[ $attr['code'] ] = $attr['labels'][ $locale ];
			}
		}

		return $headers;
	}

	/**
	 * Transforms a product object into an MBEK_Products object.
	 *
	 * @param mixed $product The product object to be transformed.
	 *
	 * @return MBEK_Products The transformed product object.
	 */
	public function transform_product( $product ): MBEK_Products {
		// echo '<pre>$product: ' . print_r( $product, true ) . '</pre>';
		$new_product = new MBEK_Products();
		// $new_product->pim_identifier = $product->pim_identifier;
		$new_product->pim_uuid = $product->pim_uuid;
		$new_product->set_brand( $product->brand );
		$new_product->set_categories( $product->categories );
		$new_product->set_pim_associations( $product->associations );
		$new_product->discontinued = $product->product_discontinued;
		// Need to add the Model Field Name option Field to this class.
		$options          = get_option( MBEK_OPTIONS );
		$model_field_name = $options['mbek_model_field'];
		$maps             = get_option( MBEK_ATTRIBUTE_MAPS );
		foreach ( $maps as $map ) {
			if ( $map['value'] && isset( $product->{$map['name']} ) ) {
				$new_product->{$map['value']} = $product->{$map['name']};
			} elseif ( $map['value'] ) {
				$new_product->{$map['value']} = '';
			}
		}
		// Get $pim_taxonomies from PIM Category Options.
		$pim_taxonomies = array();
		while ( have_rows( 'pim_taxonomy', 'option' ) ) {
			the_row();
			$pim_taxonomies[] = array(
				'name'      => get_sub_field( 'pim_taxonomy_name' ),
				'pim_field' => get_sub_field( 'pim_field_name' ),
			);
		}
		if ( ! empty( $pim_taxonomies ) ) {
			foreach ( $pim_taxonomies as $pim_tax ) {
				if ( $product->{$pim_tax['pim_field']} ) {
					$new_product->set_pim_taxonomies( $product->{$pim_tax['pim_field']} );
				}
			}
		}

		$fields = $this->get_acf_field_keys();
		$new_product->find_post_id()->init()->create( $product, $fields )->save();

		return $new_product;
	}

	/**
	 * Get the ACF field keys.
	 *
	 * This method retrieves the ACF field keys from the database and returns them as an array.
	 * The keys will be cached in a static variable to improve performance on subsequent calls.
	 *
	 * @return array An array of ACF field keys. Each key is represented as an associative array with the following properties:
	 *               - ID: The ID of the ACF field.
	 *               - key: The key of the ACF field.
	 *               - type: The type of the ACF field.
	 */
	public function get_acf_field_keys() {
		static $fields = array();
		if ( ! empty( $fields ) ) {
			return $fields;
		}
		$keys    = array();
		$options = get_option( MBEK_OPTIONS );
		if ( $options['mbek_product_id'] && filter_var( $options['mbek_product_id'], FILTER_VALIDATE_INT ) ) {
			$keys = get_field_objects( $options['mbek_product_id'], false, false );
		}
		if ( ! empty( $keys ) ) {
			foreach ( $keys as $field_name => $acf_field ) {
				$fields[ $field_name ] = array(
					'ID'   => $acf_field['ID'],
					'key'  => $acf_field['key'],
					'type' => $acf_field['type'],
				);
			}
		}

		return $fields;
	}

	/**
	 * Transform an accessory object to an instance of MBEK_Accessories.
	 *
	 * @param mixed $accessory The accessory object to transform.
	 *
	 * @return MBEK_Accessories The transformed accessory.
	 */
	public function transform_accessory( $accessory ): MBEK_Accessories {
		// trigger_error( '$accessory: '. print_r( $accessory, true), E_USER_NOTICE );
		$new_accessory = new MBEK_Accessories();
		// $new_accessory->pim_identifier = $accessory->pim_identifier;
		$new_accessory->pim_uuid  = $accessory->pim_uuid;
		$new_accessory->pim_model = $accessory->pim_model;
		// Need to add the Model Field Name option Field to this class.
		$maps = get_option( MBEK_ACCESSORY_MAPS );
		foreach ( $maps as $map ) {
			if ( $map['pim_field'] && isset( $accessory->{$map['wp_acf_field']} ) ) {
				$new_accessory->{$map['wp_acf_field']} = $accessory->{$map['wp_acf_field']};
			} else {
				$new_accessory->{$map['wp_acf_field']} = '';
			}
		}

		$new_accessory->find_post_id()->init()->create( $accessory )->save();

		// trigger_error( 'MBEK_Accessories: '. print_r( $new_accessory, true), E_USER_NOTICE );

		return $new_accessory;
	}

	/**
	 * Creates a product object from the given product data.
	 *
	 * @param array $product The product data.
	 *
	 * @return \stdClass The product object.
	 */
	public function create_product( $product ): \stdClass {
		$product_features = array();
		for ( $i = 1; $i <= 15; $i ++ ) {
			$product_features[ 'product_feature_' . $i ] = '';
		}
		$headers               = $this->get_headers_from_product();
		$new_product           = new \stdClass();
		$new_product->pim_uuid = $product['uuid'];
		// Need to add the Model Field Name option Field to this class.
		$options                          = get_option( MBEK_OPTIONS );
		$model_field_name                 = $options['mbek_model_field'];
		$new_product->{$model_field_name} = ( isset( $prodect['model'] ) ) ? $product['model'] : '';
		$new_product->categories          = $product['categories'];
		$new_product->associations        = $product['associations'];
		$main_attributes                  = get_option( MBEK_ATTRIBUTES );
//		echo $this->i_print( $headers, '$headers' );
		foreach ( $headers as $key => $attr ) {
			if ( isset( $main_attributes[ $key ] ) ) {
				$attr_data = $main_attributes[ $key ];
				// Setup array for the wootab data field. (pim_product_feature_fields-NEW)
				if ( isset( $product_features[ $key ] ) ) {
					$product_features[ $key ] = ( isset( $product['values'][ $key ] ) ) ? $this->get_field( $product['values'][ $key ], $attr_data['type'], $key ) : '';
				}
				$new_product->{$key} = ( isset( $product['values'][ $key ] ) ) ? $this->get_field( $product['values'][ $key ], $attr_data['type'], $key ) : '';
			}
		}
		$new_feature_name                 = 'pim_product_feature_fields-NEW';
		$new_product->{$new_feature_name} = '';
		if ( ! empty( $product_features ) ) {
			$new_product->{$new_feature_name} .= '<ul>';
			foreach ( $product_features as $key => $value ) {
				if ( ! empty( trim( $value ) ) ) {
					$new_product->{$new_feature_name} .= '<li>' . $value . '</li>';
				}
			}
			$new_product->{$new_feature_name} .= '</ul>';
		}
		// Get $pim_taxonomies from PIM Category Options.
		$pim_taxonomies = array();
		while ( have_rows( 'pim_taxonomy', 'option' ) ) {
			the_row();
			$pim_taxonomies[] = array(
				'name'      => get_sub_field( 'pim_taxonomy_name' ),
				'pim_field' => get_sub_field( 'pim_field_name' ),
			);
		}
		if ( ! empty( $pim_taxonomies ) ) {
			foreach ( $pim_taxonomies as $pim_tax ) {
				$taxonomy = ( isset( $product['values'][ $pim_tax['pim_field'] ] ) ) ? $product['values'][ $pim_tax['pim_field'] ] : '';
				if ( ! empty( $taxonomy ) && is_array( $taxonomy ) ) {
					$new_product->{$pim_tax['pim_field']} = array();
					foreach ( $taxonomy as $tax ) {
						$new_product->{$pim_tax['pim_field']} = $tax['data'];
					}
				}
			}
		}

		return $new_product;
	}

	/**
	 * Create an accessory object based on the given product data.
	 *
	 * @param array $product The product data.
	 *
	 * @return \stdClass The created accessory object.
	 */
	public function create_accessory( $product ): \stdClass {
		$headers         = array(
			'product_name' => 'Product Name',
			'model'        => 'Model',
			'PhotoFeature' => 'Photo Feature',
		);
		$accessory_maps  = get_option( MBEK_ACCESSORY_MAPS );
		$main_attributes = get_option( MBEK_ATTRIBUTES );
		$new_product     = new \stdClass();
		// $new_product->pim_identifier = $product['identifier'];
		$new_product->pim_uuid = $product['uuid'];
		// Need to add the Model Field Name option Field to this class.
		$options                          = get_option( MBEK_OPTIONS );
		$model_field_name                 = 'pim_model';
		$new_product->{$model_field_name} = ( isset( $prodect['model'] ) ) ? $product['model'] : '';

		foreach ( $accessory_maps as $accessory_map ) {
			if ( isset( $main_attributes[ $accessory_map['pim_field'] ] ) ) {
				$attr_data = $main_attributes[ $accessory_map['pim_field'] ];
				$new_product->{$accessory_map['wp_acf_field']}
				           = ( isset( $product['values'][ $accessory_map['pim_field'] ] ) )
					? $this->get_field( $product['values'][ $accessory_map['pim_field'] ], $attr_data['type'], $accessory_map['pim_field'] )
					: '';
			}
		}

		return $new_product;
	}

	/**
	 * Retrieves the label of an attribute option based on the attribute and option code.
	 *
	 * @param string $attribute The attribute key.
	 * @param string|array $code The option code or an array of option codes.
	 *
	 * @return string The label of the attribute option, or an empty string if not found.
	 */
	public function get_attribute_option_label( $attribute, $code ) {
		static $main_attributes;
		if ( ! $main_attributes ) {
			$main_attributes = get_option( MBEK_ATTRIBUTES );
		}
		if ( $attribute && isset( $main_attributes[ $attribute ]['options'] ) && $main_attributes[ $attribute ]['options'] ) {
			if ( isset( $code[0]['data'] ) && is_array( $code[0]['data'] ) ) {
				$return = array();
				foreach ( $code[0]['data'] as $dcode ) {
					foreach ( $main_attributes[ $attribute ]['options'] as $opt ) {
						if ( $opt['code'] === $dcode ) {
							$return[] = $opt['labels'][ $this->default_locale ];
						}
					}
				}

				return implode( ', ', $return );
			} else {
				foreach ( $main_attributes[ $attribute ]['options'] as $opt ) {
					if ( isset( $opt['code'] ) && isset( $code[0]['data'] ) && $opt['code'] === $code[0]['data'] ) {
						if ( isset( $opt['labels'][ $this->default_locale ] ) ) {
							return $opt['labels'][ $this->default_locale ];
						}
					}
				}
			}
		}

		return '';
	}

	/**
	 * Fetches the URL of the reference entity media based on the given assets and family.
	 *
	 * @param array $assets The assets containing the data of the reference entity.
	 * @param string $family The family of the reference entity media.
	 *
	 * @return string|array The URL of the reference entity media, or an array of URLs if there are multiple assets.
	 *                      Returns an error message if there is an exception.
	 */
	public function fetch_reference_entity_url( $assets, $family ) {
		$url    = '';
		$medias = array();
		if ( isset( $assets[0]['data'] ) && ! empty( $assets[0]['data'] ) ) {
			foreach ( $assets[0]['data'] as $data ) {
				try {
					switch ( $family ) {
						case 'product_certifications':
							$family    = 'certifications';
							$url_label = 'certification_url';
							break;
						case 'product_series_sub_branding_assets':
							$family    = 'master_sub_brand_logos';
							$url_label = 'logourl_png';

							return $data;
							break;
					}
					$asset    = $this->client->getReferenceEntityRecordApi()->get( $family, $data );
					$url      = $asset['values'][ $url_label ][0]['data'];
					$medias[] = $url;
				} catch ( \Exception $e ) {
					return 'Error!' . $e->getMessage();
				}
			}

			return $medias;
		}
	}

	/**
	 * Fetches the URL of media assets based on the given assets and family.
	 *
	 * @param array $assets The array containing the assets.
	 * @param string $family The family of the assets.
	 *
	 * @return array|string The array of media URLs if assets are found, otherwise an empty string.
	 */
	public function fetch_media_asset_url( $assets, $family ) {
		$url    = '';
		$medias = array();
		if ( $assets[0]['locale'] ) {
			$default_locale = $this->get_default_locale();
			// If we have a locale then get correct media data.
			$locale_asset = array_filter( $assets, function ( $asset ) use ( $default_locale ) {
				return $asset['locale'] === $default_locale;
			} );
			$mediaAsset   = ( ! empty( $locale_asset ) ) ? array_values( $locale_asset )[0] : null;
//			trigger_error( '$mediaAsset: '. print_r( $mediaAsset, true), E_USER_NOTICE );
		} elseif ( isset( $assets[0]['data'] ) && ! empty( $assets[0]['data'] ) ) {
			$mediaAsset = $assets[0];
		}
		if ( isset( $mediaAsset ) && ! empty( $mediaAsset ) ) {
			foreach ( $mediaAsset['data'] as $data ) {
				try {
					$asset_families = $this->get_asset_families();
					if ( ! empty( $asset_families[ $family ] ) ) {
						$family = $asset_families[ $family ]['family'];
					}
					$asset = $this->client->getAssetManagerApi()->get( $family, $data );
					if ( isset( $asset['values']['url'] ) ) {
						$url      = $asset['values']['url'][0]['data'];
						$label    = ( isset( $asset['values']['label'][0]['data'] ) )
							? $asset['values']['label'][0]['data']
							: '';
						$medias[] = array(
							'url'   => $url,
							'label' => $label,
						);
					}
				} catch ( \Exception $e ) {
					return 'Error!' . $e->getMessage();
				}
			}

			return $medias;
		}

		return $url;
	}

	/**
	 * Retrieves the URL of an asset given its code.
	 *
	 * @param string $code The code of the asset.
	 *
	 * @return string|bool The URL of the asset if found, false otherwise.
	 */
	public function get_asset_url( $code ) {
		$posts = get_posts(
			array(
				'numbperposts' => - 1,
				'post_type'    => 'pim_assets',
				'meta_key'     => 'pim_code',
				'meta_value'   => $code,
			)
		);
		if ( $posts ) {
			foreach ( $posts as $post ) {
				$url = get_field( 'pim_media', $post->ID );

				return $url;
			}
		}

		return false;
	}

	/**
	 * Retrieves all attributes from the API.
	 *
	 * @return array The list of attributes.
	 */
	public function get_attributes() {
		$att_array  = array();
		$attributes = $this->client->getAttributeApi()->all( 50 );
		foreach ( $attributes as $attribute ) {
			$att_array[] = $attribute;
		}

		return $att_array;
	}

	/**
	 * Retrieve all enabled locales.
	 *
	 * This method fetches all enabled locales from the Locale API and returns
	 * them as an array. It utilizes a search filter to only include enabled
	 * locales in the results.
	 *
	 * @return array An array of enabled locales.
	 */
	public function get_all_locales() {
		$locales       = array();
		$searchBuilder = new SearchBuilder();
		$searchBuilder->addFilter( 'enabled', '=', true );
		$searchFilter  = $searchBuilder->getFilters();
		$locales_array = $this->client->getLocaleApi()->all( 50, array( 'search' => $searchFilter ) );
		foreach ( $locales_array as $locale ) {
			$locales[] = $locale;
		}

		return $locales;
	}

	/**
	 * Retrieves attributes based on their codes.
	 *
	 * @return array An associative array of attributes, where the key is the attribute code and the value is the attribute data.
	 */
	public function get_attributes_by_codes() {
		$att_array = array();
		// $searchBuilder = new SearchBuilder();
		// $searchBuilder
		// ->addFilter('code', 'IN', $codes);
		// $searchFilters = $searchBuilder->getFilters();
		// echo '<pre>'.print_r($searchFilters, true).'</pre>';
		// $attributes = $this->client->getAttributeApi()->all( 50, [ 'search' => $searchFilters ]  );
		$attributes = $this->client->getAttributeApi()->all( 50 );
		foreach ( $attributes as $attribute ) {
			$att_array[ $attribute['code'] ] = $attribute;
		}

		return $att_array;
	}

	/**
	 * Retrieves all entities of a given reference entity.
	 *
	 * @param string $ref_entity The reference entity name.
	 *
	 * @return array The array of reference entities.
	 */
	public function get_reference_entities( $ref_entity ) {
		$ref      = array();
		$entities = $this->client->getReferenceEntityApi()->all( $ref_entity );
		foreach ( $entities as $entity ) {
			$ref[] = $entity;
		}

		return $entity;
	}

	/**
	 * Saves the attributes of a given family.
	 *
	 * @param string $family The name of the family.
	 *
	 * @return void
	 */
	public function save_attributes( $family ) {
		$data       = array();
		$attributes = $this->api_get_family( $family );
		if ( $attributes ) {
			foreach ( $attributes as $attribute ) {
				$data[] = array(
					'name'  => $attribute,
					'value' => '',
				);
			}
		}
		update_option( MBEK_ATTRIBUTE_MAPS, $data );
	}

	/**
	 * Saves attribute values to the WordPress option.
	 *
	 * @param mixed $values The attribute values to be saved.
	 *
	 * @return void
	 */
	public function save_attribute_values( $values ) {
		update_option( MBEK_ATTRIBUTE_VALUES, $values );
	}

	/**
	 * Retrieves the WordPress options for attribute maps.
	 *
	 * @return mixed The WordPress options for attribute maps.
	 */
	public function get_attribute_wp_options() {
		return get_option( MBEK_ATTRIBUTE_MAPS );
	}

	/**
	 * Retrieves the attribute with the given code.
	 *
	 * @param string $code The code of the attribute to retrieve.
	 *
	 * @return array The attribute information.
	 */
	public function get_attribute( $code ) {
		$attribute = array();
		try {
			$attribute = $this->client->getAttributeApi()->get( $code );
		} catch ( \Exception $e ) {
			trigger_error( 'ERROR: ' . print_r( $e, true ), E_USER_NOTICE );
		}

		return $attribute;
	}

	/**
	 * Retrieves the options for a specific attribute.
	 *
	 * @param string $code The code of the attribute to retrieve options for.
	 *
	 * @return array Returns an array of options for the specified attribute.
	 */
	public function get_attribute_options( $code ) {
		$options = $this->client->getAttributeOptionApi()->all( $code, 50 );

		return $options;
	}

	/**
	 * Retrieves the options for a given brand attribute code.
	 *
	 * @param string $code The code of the brand attribute.
	 *
	 * @return array An array of options for the brand attribute.
	 */
	public function get_brand_attribute_options( $code ) {
		$options           = array();
		$attribute_options = $this->client->getAttributeOptionApi()->all( $code, 50 );
		foreach ( $attribute_options as $attribute_option ) {
			$options[] = $attribute_option;
		}

		return $options;
	}

	/**
	 * Retrieves the header label of an attribute based on its code.
	 *
	 * @param string $code The code of the attribute.
	 *
	 * @return string|false The header label of the attribute if found, otherwise false.
	 */
	public function get_attribute_header( $code ) {
		$attribute = $this->get_attribute( $code );

		return isset( $attribute['labels'][ $this->default_locale ] ) ? $attribute['labels'][ $this->get_default_locale() ] : false;
	}

	/**
	 * Get attributes of a family from the API.
	 *
	 * @param string $family_name The name of the family to retrieve attributes for.
	 *
	 * @return array The attributes of the family.
	 */
	public function api_get_family( $family_name ) {
		$attributes = array();
		$family     = $this->client->getFamilyApi()->get( $family_name );
		if ( $family['attributes'] ) {
			foreach ( $family['attributes'] as $item ) {
				$attributes[] = $item;// $this->client->getAttributeApi()->get( $item );
			}
		}

		return $attributes;
	}

	/**
	 * Retrieve attributes for the given codes.
	 *
	 * This method fetches attributes associated with the provided codes using the API
	 * and returns them as an array.
	 *
	 * @param array $codes An array of codes for which attributes need to be retrieved.
	 *
	 * @return array An array of attributes corresponding to the given codes.
	 */
	public function get_attributes_for_codes( $codes ) {
		$attributes = array();
		// $searchBuilder = new SearchBuilder();
		// $searchBuilder
		// ->addFilter( 'code', 'IN', $codes );
		// $att_pim = $this->client->getAttributeApi()->all( 50, [ 'search' => $searchBuilder ] );
		$att_pim = $this->client->getAttributeApi()->all( 50 );
		foreach ( $att_pim as $att ) {
			$attributes[] = $att;
		}

		return $attributes;
	}

	/**
	 * Retrieves attributes by families.
	 *
	 * @param array $families Array of families to search for attributes.
	 *
	 * @return array Returns an array of unique attributes found in the given families.
	 */
	public function api_get_attributes_by_families( $families ) {
		$attributes    = array();
		$searchBuilder = new SearchBuilder();
		$searchBuilder
			->addFilter( 'code', 'IN', $families );
		$searchFilters = $searchBuilder->getFilters();
		// echo '<pre>$searchFilters: '.print_r($searchFilters, true).'</pre>';
		// $pim_families = $this->client->getFamilyApi()->all( 50, [ 'search' => $searchFilters ] );
		$pim_families = $this->client->getFamilyApi()->all( 50 );
		foreach ( $pim_families as $family ) {
			if ( $family['attributes'] ) {
				foreach ( $family['attributes'] as $item ) {
					$attributes[] = $item;// $this->client->getAttributeApi()->get( $item );
				}
			}
		}

		return array_unique( $attributes );
	}

	/**
	 * Returns all asset families.
	 *
	 * @return array Returns an array of asset families.
	 */
	public function get_all_asset_families() {
		$data           = array();
		$asset_families = $this->client->getAssetFamilyApi()->all();
		foreach ( $asset_families as $asset ) {
			$data[] = $asset;
		}

		return $data;
	}

	/**
	 * Retrieves brand assets based on the provided family.
	 *
	 * @param string $family The family of assets to retrieve.
	 * @param bool $save Whether to save the retrieved assets or not.
	 *
	 * @return array The filtered brand assets matching the provided family.
	 */
	public function get_brand_asset_by_family( $family, $save = true, $first_run = false ) {
		// Builder for Search.
		$searchBuilder = new SearchBuilder();
		if ( ! $first_run ) {
			$searchBuilder->addFilter( 'updated', 'SINCE LAST N DAYS', 1 );
		}
		$searchFilter = $searchBuilder->getFilters();
		$data         = array();
		$results      = $this->client->getAssetManagerApi()->all( $family, array( 'search' => $searchFilter ) );
		if ( ! empty( $results ) ) {
			foreach ( $results as $asset ) {
				$data[] = $asset;
			}
		}
		// trigger_error( '$data: ' . print_r( $data, true ), E_USER_NOTICE );

		$filtered = array_filter(
			$data,
			function ( $var ) {
				$brand_options = get_option( MBEK_ALT_BRANDS );
				$brands        = array(
					$this->get_brand(),
				);
				if ( ! empty( $brand_options ) ) {
					foreach ( $brand_options as $alt_brand ) {
						$brands[] = $alt_brand['brand'];
					}
				}

				return ( preg_match( '%' . implode( '|', $brands ) . '%i', $var['code'] ) );
			}
		);

		if ( ! empty( $filtered ) && $save ) {
			foreach ( $filtered as $item ) {
				$this->save_pim_asset_data( $item, $family );
			}
		}

		return $filtered;
	}

	/**
	 * Print the data with optional name.
	 *
	 * @param mixed $data The data to be printed.
	 * @param string $name (optional) The name to be displayed alongside the printed data.
	 *
	 * @return string The formatted string representation of the data.
	 */
	public function i_print( $data, $name = '' ) {
		return '<pre>' . $name . ': ' . print_r( $data, true ) . '</pre>';
	}

	/**
	 * Retrieves the tokens from the Middleby settings.
	 *
	 * @return void
	 */
	public function get_tokens() {
		$options       = get_option( MBEK_OPTIONS, array() );
		$client_url    = MBEK_CLIENT_URL;
		$client_id     = MBEK_CLIENT_ID;
		$client_secret = MBEK_CLIENT_SECRET;
		$username      = MBEK_CLIENT_USERNAME;
		$password      = MBEK_CLIENT_PASSWORD;

		if ( $client_id && $client_secret && $username && $password && $client_url ) {
			$clientBuilder = new AkeneoPimClientBuilder( $client_url );
			$this->set_client( $clientBuilder->buildAuthenticatedByPassword( $client_id, $client_secret, $username, $password ) );
			$category     = $this->client->getCategoryApi()->get( 'Middleby_Primary_Classification' );
			$new_settings = array(
				'mbek_client_token_timestamp' => time(),
				'mbek_client_token'           => $this->client->getToken(),
				'mbek_client_refresh_token'   => $this->client->getRefreshToken(),
			);
			$options      = array_merge( $options, $new_settings );
			update_option( MBEK_OPTIONS, $options );
		} else {
			wp_die( 'Please setup Middleby Settings' );
		}
	}

	/**
	 * Update the cron timestamp for a given type.
	 *
	 * @param string $type The type of cron timestamp to update. Can be 'products' or 'assets'.
	 *
	 * @return bool True if the cron timestamp was successfully updated, false otherwise.
	 */
	public function update_cron_timestamp( $type ) {
		if ( ! in_array( $type, array( 'products', 'assets' ) ) ) {
			return false;
		}
		$options      = get_option( MBEK_OPTIONS );
		$new_settings = array();
		switch ( $type ) {
			case 'products':
				$new_settings = array(
					'mbek_cron_products_timestamp' => time(),
				);
				break;
			case 'assets':
				$new_settings = array(
					'mbek_cron_assets_timestamp' => time(),
				);
				break;
		}
		$options = array_merge( $options, $new_settings );
		update_option( MBEK_OPTIONS, $options );

		return true;
	}

	/**
	 * Get the asset families.
	 *
	 * This method returns an array of asset families.
	 *
	 * @return array The array of asset families.
	 */
	public function get_asset_families(): array {
		return $this->asset_families;
	}
}
