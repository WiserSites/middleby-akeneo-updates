<?php
/**
 * Main Admin Controller class
 *
 * Controller class for the plugin admin methods, actions and filters.
 *
 * @package    Akeneo Plugin
 * @subpackage Admin
 * @since      1.0.0
 */
require_once MBEK_PLUGIN_DIR . '/lib/class.akeneo.php';

use Middleby\Akeneo\MBEK_Akeneo;

require_once MBEK_PLUGIN_DIR . '/vendor/autoload.php';

/**
 *
 * MBEK_Admin class.
 *
 * This class is responsible for managing the administration functions of the MBEK plugin.
 */
class MBEK_Admin {

	/**
	 * @var bool Boolean if class is initiated.
	 */
	private static $initiated = false;

	/**
	 * Initializes the plugin if not already initiated.
	 *
	 * @return void
	 */
	public static function init() {
		if ( ! self::$initiated ) {
			self::init_hooks();
		}
	}

	/**
	 * Initialize hooks for the MBEK_Admin class.
	 *
	 * @return void
	 */
	private static function init_hooks() {
		self::$initiated = true;
		require_once MBEK_PLUGIN_DIR . 'view/admin/mbek_settings.php';
		add_action( 'admin_menu', array( 'MBEK_Admin', 'init_menus' ), 10, 2 );

		add_action( 'admin_post_save_mbek_attributes', array( 'MBEK_Admin', 'save_mbek_attributes' ) );

		add_action( 'wp_ajax_clear_mbek_attributes', array( 'MBEK_Admin', 'clear_mbek_attributes' ) );

		add_action( 'wp_ajax_pull_products', array( 'MBEK_Admin', 'pull_products' ) );
		add_action( 'wp_ajax_nopriv_pull_products', array( 'MBEK_Admin', 'pull_products' ) );

		add_action( 'wp_ajax_mbek_export_modelnumbers', array( 'MBEK_Admin', 'export_modelnumbers' ) );
		add_action( 'wp_ajax_mbek_data_modelnumbers', array( 'MBEK_Admin', 'data_modelnumbers' ) );
		add_action( 'wp_ajax_mbek_data_accessories', array( 'MBEK_Admin', 'data_accessories' ) );
		add_action( 'wp_ajax_pull_pim_data', array( 'MBEK_Admin', 'pull_pim_data' ) );
		add_action( 'wp_ajax_sync_pim_table', array( 'MBEK_Admin', 'sync_pim_table' ) );

		add_action( 'wp_ajax_pull_brand_categories', array( 'MBEK_Admin', 'pull_brand_categories' ) );
		add_action( 'wp_ajax_nopriv_pull_brand_categories', array( 'MBEK_Admin', 'pull_brand_categories' ) );

		add_action( 'wp_ajax_pull_sub_brand_categories', array( 'MBEK_Admin', 'pull_sub_brand_categories' ) );
		add_action( 'wp_ajax_nopriv_pull_sub_brand_categories', array( 'MBEK_Admin', 'pull_sub_brand_categories' ) );

		add_action( 'wp_ajax_pull_pim_taxonomies', array( 'MBEK_Admin', 'pull_pim_taxonomy_attributes' ) );

		add_action( 'wp_ajax_pull_ice_types', array( 'MBEK_Admin', 'pull_ice_types' ) );

		add_action( 'wp_ajax_pull_accessories', array( 'MBEK_Admin', 'pull_accessories' ) );

		add_action( 'wp_ajax_mbek_product_assets', array( 'MBEK_Admin', 'mbek_product_assets' ) );

		add_action( 'wp_ajax_pull_resources', array( 'MBEK_Admin', 'pull_resources' ) );

		add_action( 'wp_ajax_clear_mbek_cpt', array( 'MBEK_Admin', 'clear_mbek_cpt' ) );
		add_action( 'wp_ajax_clear_mbek_acc_cpt', array( 'MBEK_Admin', 'clear_mbek_acc_cpt' ) );
		add_action( 'wp_ajax_clear_mbek_pim_cache', array( 'MBEK_Admin', 'clear_mbek_pim_cache' ) );
		add_action( 'wp_ajax_delete_cpt_not_in_pim', array( 'MBEK_Admin', 'delete_cpt_not_in_pim' ) );

		// Uploader.
		add_action( 'wp_ajax_mbek_importer', array( 'MBEK_Admin', 'mbek_importer' ) );

		add_action( 'wp_ajax_mbek_json_options', array( 'MBEK_Admin', 'mbek_json_options' ) );
		add_action( 'wp_ajax_mbek_json_attribute_maps', array( 'MBEK_Admin', 'mbek_json_attribute_maps' ) );
		add_action( 'wp_ajax_nopriv_mbek_json_options', array( 'MBEK_Admin', 'mbek_json_options' ) );
		add_action( 'wp_ajax_nopriv_mbek_json_attribute_maps', array( 'MBEK_Admin', 'mbek_json_attribute_maps' ) );
	}

	/**
	 * Importer method used to handle import actions.
	 *
	 * @return void
	 */
	public static function mbek_importer() {
		// return;
		if ( ! ( isset( $_REQUEST['action'] ) && 'mbek_importer' == $_POST['action'] ) ) {
			return;
		}

		$return = array(
			'status' => false,
			'html'   => '<h3> There is ERROR!!! </h3>',
		);
		require_once MBEK_PLUGIN_DIR . 'lib/class.mbek-import.php';
		$file_link = $_POST['import_file'];
		if ( $file_link ) {
			$return = MBEK_IMPORT::run_import_action( $file_link );
		}
		echo json_encode( $return );
		exit;
	}

	/**
	 * Save MBEK attributes.
	 *
	 * @return void
	 */
	public static function save_mbek_attributes() {
		if ( isset( $_POST['mbek_nonce'] ) && wp_verify_nonce( $_POST['mbek_nonce'], 'mbek_nonce' ) ) {
			$attributes = get_option( MBEK_ATTRIBUTES );
			$att_maps   = array();
			foreach ( $attributes as $key => $attribute ) {
				$att_value        = isset( $_REQUEST[ $key ] ) ? filter_var( $_REQUEST[ $key ] ) : '';
				$att_maps[ $key ] = array(
					'name'  => $key,
					'value' => $att_value,
				);
			}
			update_option( MBEK_ATTRIBUTE_MAPS, $att_maps );
			wp_redirect( 'admin.php?page=mbek-api&success=1' );
		} else {
			wp_die( 'no here!' );
		}
	}

	/**
	 * Clear MBEK attributes.
	 *
	 * @return void
	 */
	public static function clear_mbek_attributes() {
		if ( isset( $_GET['mbek_nonce'] ) && wp_verify_nonce( $_GET['mbek_nonce'], 'mbek_nonce' ) ) {
			update_option( MBEK_ATTRIBUTES, array() );
		} else {
			wp_die( 'no here!' );
		}
	}

	/**
	 * Clear custom post types.
	 *
	 * This function clears custom post types based on the provided options.
	 * It checks for the presence of a valid nonce to ensure the request is intentional.
	 *
	 * @return void
	 */
	public static function clear_mbek_cpt() {
		if ( isset( $_GET['mbek_nonce'] ) && wp_verify_nonce( $_GET['mbek_nonce'], 'mbek_nonce' ) ) {
			// trigger_error( 'clear_mbek_cpt', E_USER_NOTICE );
			$options   = get_option( MBEK_OPTIONS );
			$post_type = $options['mbek_post_type'];
			$main_id   = $options['mbek_product_id'];
			$bad_post  = get_posts(
				array(
					'posts_per_page' => - 1,
					'exclude'        => array( $main_id ),
					'post_type'      => $post_type,
					'post_status'    => 'any',
					'fields'         => 'ids',
				)
			);
			foreach ( $bad_post as $b_post ) {
				wp_delete_post( $b_post );
			}
		} else {
			wp_die( 'no here!' );
		}
	}

	public static function clear_mbek_acc_cpt() {
		if ( isset( $_GET['mbek_nonce'] ) && wp_verify_nonce( $_GET['mbek_nonce'], 'mbek_nonce' ) ) {
			// trigger_error( 'clear_mbek_cpt', E_USER_NOTICE );
			$options   = get_option( MBEK_OPTIONS );
			$post_type = $options['mbek_accessory_post_type'];
			$bad_post  = get_posts(
				array(
					'posts_per_page' => - 1,
					'post_type'      => $post_type,
					'post_status'    => 'any',
					'fields'         => 'ids',
				)
			);
			foreach ( $bad_post as $b_post ) {
				wp_delete_post( $b_post );
			}
		} else {
			wp_die( 'no here!' );
		}
	}

	/**
	 * Clear the MBEK PIM cache.
	 *
	 * If the 'mbek_nonce' parameter is set and the provided nonce is valid,
	 * a new instance of MBEK_Akeneo is created, the client is started, and
	 * the PIM data is truncated. Otherwise, a 500 error response is sent.
	 *
	 * @return void
	 */
	public static function clear_mbek_pim_cache() {
		if ( isset( $_GET['mbek_nonce'] ) && wp_verify_nonce( $_GET['mbek_nonce'], 'mbek_nonce' ) ) {
			$akeneo = new MBEK_Akeneo();
			$akeneo->start_client();
			$akeneo->truncate_pim_data();
			// trigger_error( 'clear_mbek_pim_cache', E_USER_NOTICE );
		} else {
			wp_send_json_error( new WP_Error( '001', 'No Go!', 'Something went wrong!' ), 500 );
		}
	}

	/**
	 * Enqueues CSS and JS files for the plugin.
	 *
	 * @return void
	 */
	public static function mbek_css_and_js( $enqueue_uploader = false ) {
		$local_values = array(
			'ajax_url' => admin_url( 'admin-ajax.php' ),
			'nonce'    => wp_create_nonce( 'mbek_nonce' ),
		);
		if ( $enqueue_uploader === true ) {
			wp_enqueue_style( 'mbek_fileupload_style', MBEK_PLUGIN_URL . 'resources/js/jQuery-File-Upload/css/jquery.fileupload.css', array(), MBEK_Version, 'all' );
			wp_enqueue_script( 'jquery.ui.widget-js', MBEK_PLUGIN_URL . 'resources/js/jQuery-File-Upload/js/vendor/jquery.ui.widget.js', array( 'jquery' ), MBEK_Version, true );
			wp_enqueue_script( 'jquery.iframe-transport-js', MBEK_PLUGIN_URL . 'resources/js/jQuery-File-Upload/js/jquery.iframe-transport.js', array( 'jquery' ), MBEK_Version, true );
			wp_enqueue_script( 'jquery.fileupload-js', MBEK_PLUGIN_URL . 'resources/js/jQuery-File-Upload/js/jquery.fileupload.js', array( 'jquery' ), MBEK_Version, true );
			$local_values['import_sure_txt'] = __( 'Are you sure you want to overwrite the current "Settings" ?', MBEK_NAME );

		}
		wp_enqueue_style( 'mbek_bootstrap_style', 'https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css', array(), MBEK_Version, 'all' );
		wp_enqueue_script( 'mbek_bootstrap_js', 'https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js', array(), MBEK_Version, true );
		wp_enqueue_style( 'mbek_admin_style', MBEK_PLUGIN_URL . 'resources/style/admin_style.css', array(), MBEK_Version, 'all' );
		wp_enqueue_script( 'mbek-admin-js', MBEK_PLUGIN_URL . 'resources/js/admin_js.js', array( 'jquery' ), MBEK_Version, true );
		wp_localize_script(
			'mbek-admin-js',
			'mbek_infos',
			$local_values
		);
	}

	/**
	 * Export model numbers.
	 *
	 * This method exports model numbers to a CSV file and downloads it.
	 *
	 * @return void
	 */
	public static function export_modelnumbers() {
		$options     = get_option( MBEK_OPTIONS );
		$model_field = $options['mbek_model_field'];
		$akeneo      = new MBEK_Akeneo();
		$akeneo->start_client();
		$not_found = $akeneo->get_all_products( true );
		$output    = fopen( 'php://output', 'w' );
		header( 'Content-Type:application/csv' );
		header( 'Content-Disposition:attachment;filename=export.csv' );
		fputcsv( $output, array( 'ID', 'Name', 'model', 'PIM Model', 'PIM UUID' ) );
		foreach ( $not_found as $item ) {
			fputcsv(
				$output,
				array(
					$item['id'],
					$item['name'],
					$item[ $model_field ],
					$item['pim_model'],
					$item['pim_uuid'],
				)
			);
		}
		fclose( $output );
		exit;
	}

	/**
	 * Retrieves data for model numbers.
	 *
	 * @return void
	 */
	public static function data_modelnumbers() {
		$options       = get_option( MBEK_OPTIONS );
		$use_only_uuid = $options['mbek_use_only_uuid'] ?? false;
		// $model_field   = $options['mbek_model_field'];
		$akeneo = new MBEK_Akeneo();
		$akeneo->start_client();
		$page    = filter_var( $_REQUEST['page'], FILTER_VALIDATE_INT );
		$results = $akeneo->get_all_products( $page );
		// trigger_error( '$results: ' . print_r( $results, true ), E_USER_NOTICE );
		$data     = $results['data'];
		$total    = $results['total'];
		$products = array();
		foreach ( $data as $item ) {
			// $opt_url  = ( $use_only_uuid )
			// ? get_admin_url() . 'admin.php?page=mbek-modelnumbers&uuid=' . urlencode( $item['pim_uuid'] )
			// : get_admin_url() . 'admin.php?page=mbek-modelnumbers&model=' . urlencode( $item['model'] );
			$products[] = array(
				// 'id'     => '<a target="_blank" href="' . get_admin_url() . 'post.php?post=' . $item['id'] . '&action=edit&classic-editor">' . $item['id'] . '</a>',
									'id' => $item['id'],
				'title'                  => $item['name'],
				'model'                  => $item['model'],
				'uuid'                   => $item['pim_uuid'],
				'option'                 => $item['pim_uuid'],
				'view'                   => get_permalink( $item['id'] ),
			);
		}
		$last_page = ceil( $total / 10 );
		$return    = array(
			'last_page' => $last_page,
			'data'      => array_slice( $products, 0, 10 ),
		);
		echo json_encode( $return );
		exit;
	}

	/**
	 * Get accessories data.
	 *
	 * This method retrieves the accessories data from the server and returns it as JSON.
	 *
	 * @return void
	 */
	public static function data_accessories() {
		$options = get_option( MBEK_OPTIONS );
		$akeneo  = new MBEK_Akeneo();
		$akeneo->start_client();
		$page        = filter_var( $_REQUEST['page'], FILTER_VALIDATE_INT );
		$results     = $akeneo->get_all_accessories();
		$data        = $results['data'];
		$total       = $results['total'];
		$accessories = array();
		foreach ( $data as $item ) {
			$accessories[] = array(
				'id'     => $item['id'],
				'title'  => $item['name'],
				'uuid'   => $item['pim_uuid'],
				'option' => $item['pim_uuid'],
				'view'   => get_permalink( $item['id'] ),
			);
		}
		$last_page = ceil( $total / 10 );
		$return    = array(
			'last_page' => $last_page,
			'data'      => array_slice( $accessories, 0, 10 ),
		);
		echo json_encode( $return );
		exit;
	}

	/**
	 * Get the ACF field type for the feature photo.
	 *
	 * @return string|false The ACF field type if found, false otherwise.
	 */
	public static function get_acf_field_type_for_feature_photo() {
		$options        = get_option( MBEK_OPTIONS );
		$attribute_maps = get_option( MBEK_ATTRIBUTE_MAPS );
		$field_name     = $attribute_maps['PhotoFeature']['value'] ?? false;
		$main_prod_id   = $options['mbek_product_id'] ?? false;
		if ( $field_name && $main_prod_id ) {
			$photo_field_object = get_field_object( $field_name, $main_prod_id, false, false, false );
			if ( isset( $photo_field_object['type'] ) ) {
				return $photo_field_object['type'];
			}
		}

		return false;
	}

	/**
	 * Check missing Photo Features.
	 *
	 * @return void
	 */
	public static function mbek_check_missing_photofeatures() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		global $wpdb;
		self::mbek_css_and_js();
		$photo_feature_object = self::get_acf_field_type_for_feature_photo();
		$options              = get_option( MBEK_OPTIONS );
		$attribute_maps       = get_option( MBEK_ATTRIBUTE_MAPS );
		$post_type            = $options['mbek_post_type'];
		// Find photo feature assigned mapping.
		if ( isset( $attribute_maps['PhotoFeature'] ) ) {
			$query = "SELECT ID,post_title
				        FROM $wpdb->posts
			           WHERE post_type = %s
					     AND ID NOT IN (SELECT post_id FROM $wpdb->postmeta WHERE meta_key = %s)
						 AND ID IN (SELECT post_id FROM $wpdb->postmeta WHERE meta_key = 'pim_uuid')";
			if ( $photo_feature_object ) {
				switch ( $photo_feature_object ) {
					case 'repeater':
						$att_name = $attribute_maps['PhotoFeature']['value'] . '_0_file_url';
						break;
					default:
						$att_name = $attribute_maps['PhotoFeature']['value'];
						break;
				}
			}
			$results = $wpdb->get_results(
				$wpdb->prepare(
					$query,
					$post_type,
					$att_name
				)
			);
		}
		echo '<div id="mbek_akeneo_data" class="wrap">
            <h1>Middleby Akeneo</h1>';
		echo '<div><h3>Check Missing PhotosFeatured</h3></div>';
		if ( ! is_wp_error( $results ) ) {
			echo '<table class="table table-striped caption-top table-bordered border-dark table-hover">';
			echo '<caption>Total posts ' . count( $results ) . '</caption>';
			echo '<thead><tr style="border: 1px solid black;">
			<th scope="col">ID</th>
			<th scope="col">Post Title</th>
			<th scope="col">UUID</th>
		</tr></thead><tbody class="table-group-divider">';
			if ( ! empty( $results ) ) {
				foreach ( $results as $item ) {
					$uuid = get_field( 'pim_uuid', $item->ID );
					$url  = get_admin_url() . 'admin.php?page=mbek-modelnumbers&uuid=' . $uuid;
					echo '<tr>
					<th scope="row">' . $item->ID . '</th>
					<td>' . $item->post_title . '</td>
					<td><a href="' . $url . '" target="_blank">' . $uuid . '</a></td>
				</tr>';
				}
			}
			echo '</tbody></table>';
		} else {
			echo '<div>Error: ' . $results->get_error_message() . '</div>';
		}
		echo '</div>';
	}

	/**
	 * Check Categories method.
	 *
	 * @return void
	 */
	public static function mbek_check_categories() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		self::mbek_css_and_js();
		global $wpdb;
		$pim_category_taxes    = array();
		$pim_category_taxonomy = get_option( 'options_pim_category_taxonomy' );
		$taxonomies            = get_terms(
			array(
				'taxonomy'   => $pim_category_taxonomy,
				'hide_empty' => false,
			)
		);

		$table_name = $wpdb->prefix . MBEK_PIM_CATEGORY_TABLE_NAME;
		// Get all of the table data.
		$pim_results = $wpdb->get_results(
			'SELECT *
 	           FROM ' . $table_name . '
 	       ORDER BY id'
		);
		$cats        = array();
		if ( ! empty( $taxonomies ) ) {
			foreach ( $taxonomies as $item ) {
				$cats[] = get_field( 'pim_category_code', $pim_category_taxonomy . '_' . $item->term_id );
			}
		}
		$pim_categories = array();
		if ( ! empty( $pim_results ) ) {
			foreach ( $pim_results as $pim_category ) {
				$pim_categories[] = $pim_category->code;
			}
		}

		$new_taxs              = array();
		$pim_category_taxonomy = \get_option( 'options_pim_category_taxonomy' );
		$taxonomies            = \get_terms(
			array(
				'taxonomy'   => $pim_category_taxonomy,
				'hide_empty' => false,
			)
		);
		foreach ( $taxonomies as $tax ) {
			$new_taxs[ $tax->slug ] = $tax;
		}
		$delete_terms = array();
		if ( ! empty( $new_taxs ) ) {
			$test_cats = array_filter( $cats );
			foreach ( $new_taxs as $new_tax ) {
				$category_code_from_tax = get_field( 'field_64ca9a2853ccf', $pim_category_taxonomy . '_' . $new_tax->term_id );
				if ( ! in_array( $category_code_from_tax, $test_cats ) ) {
					$delete_terms[] = $new_tax->term_id;
				}
			}
		}

		echo '<div id="mbek_akeneo_data" class="wrap">
            <h1>Middleby Akeneo</h1>';
		echo '<div><h3>Check Categories</h3></div>';
		echo '<div><p>Get info on PIM and WordPress Categories.</p></div>';
		echo '<div>Count of Terms: ' . count( $cats ) . '</div>';
		echo '<div>Count of PIM Categories: ' . count( $pim_categories ) . '</div>';
//		echo '<pre>' . print_r( array_diff( $pim_categories, $cats ), true ) . '</pre>';
//		echo '<pre>$cats' . print_r( $cats, true ) . '</pre>';
//		echo '<pre>$delete_terms' . print_r( $delete_terms, true ) . '</pre>';
		// $akeneo = new MBEK_Akeneo();
		// $akeneo->start_client();
		// echo '<pre>' . print_r( $akeneo->get_family(), true ) . '</pre>';
		if ( ! is_wp_error( $taxonomies ) ) {
			echo '<table class="table table-striped caption-top table-bordered border-dark table-hover">';
//			echo '<caption>Total $taxonomies ' . count( $taxonomies ) . '</caption>';
			echo '<thead><tr style="border: 1px solid black;">
			<th scope="col">Term ID</th>
			<th scope="col">Name</th>
			<th scope="col">Parent</th>
			<th scope="col">PIM Category Code</th>
			<th scope="col">Matched to PIM</th>
			<th>Hide From Display</th>
		</tr></thead><tbody class="table-group-divider">';
			if ( ! empty( $taxonomies ) ) {
				foreach ( $taxonomies as $item ) {
					$pim_field   = get_field( 'pim_category_code', $pim_category_taxonomy . '_' . $item->term_id );
					$is_hidden   = get_field( 'hide_from_display', $pim_category_taxonomy . '_' . $item->term_id );
					$matched_css = in_array( $pim_field, $pim_categories ) ? 'class="table-success"' : 'class="table-danger"';
					$hidden_css  = $is_hidden ? 'class="table-success"' : 'class="table-danger"';
					echo '<tr>
					<th scope="row">' . $item->term_id . '</th>
					<td>' . $item->name . '</td>
					<td>' . $item->parent . '</td>
					<td>' . $pim_field . '</td>
					<td ' . $matched_css . '>' . ( in_array( $pim_field, $pim_categories ) ? 'Yes' : 'No' ) . '</td>
					<td ' . $hidden_css . '>' . ( $is_hidden ? 'Yes' : 'No' ) . '</td>
				</tr>';
				}
			}
			echo '</tbody></table>';
		} else {
			echo '<div>Error: ' . $taxonomies->get_error_message() . '</div>';
		}

		echo '</div>';
	}

	/**
	 * Deletes custom post types that are not in the PIM.
	 *
	 * @return void
	 */
	public static function delete_cpt_not_in_pim() {
		$akeneo = new MBEK_Akeneo();
		$akeneo->start_client();

		$options          = get_option( MBEK_OPTIONS );
		$post_type        = $options['mbek_post_type'];
		$main_id          = $options['mbek_product_id'];
		$use_only_uuid    = $options['mbek_use_only_uuid'] ?? false;
		$pim_data_results = $akeneo->get_all_pim_data();

		if ( ! empty( $pim_data_results ) ) {
			$pim_data  = array_map(
				function ( $item ) {
					return $item->uuid;
				},
				$pim_data_results
			);
			$meta_args = array(
				'relation' => 'AND',
				array(
					'relation' => 'OR',
					array(
						'key'     => 'pim_uuid',
						'value'   => $pim_data,
						'compare' => 'NOT IN',
					),
				),
				array(
					'relation' => 'OR',
					array(
						'key'     => 'is_international',
						'value'   => '1',
						'compare' => '!=',
					),
					array(
						'key'     => 'is_international',
						'compare' => 'NOT EXISTS',
					),
				),
			);
			if ( $use_only_uuid ) {
				$meta_args[0][] = array(
					'key'     => 'pim_uuid',
					'compare' => 'NOT EXISTS',
					'value'   => '',
				);
			}
			$bad_post = get_posts(
				array(
					'posts_per_page' => - 1,
					'exclude'        => array( $main_id ),
					'post_type'      => $post_type,
					'post_status'    => 'any',
					'fields'         => 'ids',
					'meta_query'     => $meta_args,
				)
			);
			$count    = 0;
			foreach ( $bad_post as $b_post ) {
				wp_delete_post( $b_post );
				$count ++;
			}

//			if ( wp_doing_ajax() ) {
//				wp_send_json_success( 'Deleted ' . $count . ' posts.' );
//			}
		}
	}

	/**
	 * Check Accessories and display PIM data if a UUID is provided.
	 * Display a table with accessories data if no UUID is provided.
	 *
	 * @return void
	 */
	public static function mbek_check_accessories() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		self::mbek_css_and_js();
		$akeneo = new MBEK_Akeneo();
		$akeneo->start_client();
		echo '<div id="mbek_akeneo_data" class="wrap">
            <h1>Middleby Akeneo</h1>';
		echo '<div><h3>List Accessories</h3></div>';
		if ( ! empty( $_REQUEST['uuid'] ) ) {
			$uuid    = htmlspecialchars( $_REQUEST['uuid'] );
			$product = $akeneo->get_accessory_by_uuid( $uuid );
			echo '<p>Checking PIM Data for ' . $uuid . '</p>';
		} else {
			wp_enqueue_style( 'mbek-tabulator-css', MBEK_PLUGIN_URL . 'resources/style/tabulator.min.css', array(), MBEK_Version );
			wp_enqueue_script( 'mbek-tablator-js', MBEK_PLUGIN_URL . 'resources/js/tabulator.min.js', array(), MBEK_Version );
			wp_enqueue_script( 'mbek-tjquery-wrapper-js', MBEK_PLUGIN_URL . 'resources/js/jquery_wrapper.js', array(), MBEK_Version );
			wp_enqueue_script( 'mbek-listaccessories-js', MBEK_PLUGIN_URL . 'resources/js/mbek_list_accessories.js', array(), MBEK_Version );
			wp_localize_script(
				'mbek-listaccessories-js',
				'mbek_lp_infos',
				array(
					'ajax_url_for_data' => get_admin_url() . 'admin-ajax.php?action=mbek_data_accessories',
					'edit_url'          => get_admin_url() . 'post.php?post=',
					'uuid_url'          => get_admin_url() . 'admin.php?page=mbek-accessorynumbers&uuid=',
					'model_url'         => get_admin_url() . 'admin.php?page=mbek-modelnumbers&model=',
				)
			);
			// echo '<link href="https://unpkg.com/tabulator-tables@5.6.1/dist/css/tabulator.min.css" rel="stylesheet">
			// <script type="text/javascript" src="https://unpkg.com/tabulator-tables@5.6.1/dist/js/tabulator.min.js"></script>';
			echo '<div class="table-responsive">';
			echo '<div class="row"><div class="col">
		<button id="download-csv" class="btn btn-primary">Download CSV</button>
    	<button id="download-json" class="btn btn-primary">Download JSON</button>
	</div>
</div>';
			echo '<div id="mbek_accessories"></div>';
			// $ajax_url_for_data = get_admin_url() . 'admin-ajax.php?action=mbek_data_accessories';
			// echo '<script>
			// var table = new Tabulator("#mbek_accessories", {
			// ajaxURL: "' . $ajax_url_for_data . '",
			// height: "600px",
			// layout: "fitColumns",
			// placeholder: "No Data Set",
			// columns: [
			// {title: "ID", field: "id", sorter: "number", formatter: "html", width: 100},
			// {title: "Title", field: "title", sorter: "string"},
			// {title: "UUID", field: "uuid", sorter: "string"},
			// {title: "Option", field: "option", formatter: "html", width: 150},
			// {title: "View", field: "view", formatter: "html", width: 100}
			// ]
			// });
			// </script>';
		}

		echo '</div>';
	}

	/**
	 * Check Model Numbers.
	 *
	 * This method checks the model numbers against the PIM data and displays the results in a table format on the admin page.
	 * If a specific model or UUID is specified in the request, it will display the PIM data for that model or UUID.
	 * Otherwise, it will display a table with all the model numbers and their corresponding PIM data.
	 *
	 * @return void
	 */
	public static function mbek_check_model_numbers() {
		self::mbek_css_and_js();
		$options     = get_option( MBEK_OPTIONS );
		$post_type   = $options['mbek_post_type'];
		$model_field = $options['mbek_model_field'];
		$akeneo      = new MBEK_Akeneo();
		$akeneo->start_client();
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		echo '<div id="mbek_akeneo_data" class="wrap">
            <h1>Middleby Akeneo</h1>';
		echo '<div><h3>List Products with Akeneo Data</h3></div>';
		if ( ! empty( $_REQUEST['model'] ) ) {
			$model   = htmlspecialchars( $_REQUEST['model'] );
			$product = $akeneo->get_product_by_model( $model );
			echo '<p>Checking PIM Data for ' . $_REQUEST['model'] . '</p>';
		} elseif ( ! empty( $_REQUEST['uuid'] ) ) {
			$uuid    = htmlspecialchars( $_REQUEST['uuid'] );
			$product = $akeneo->get_product_by_uuid( $uuid );
			echo '<p>Checking PIM Data for ' . $uuid . '</p>';
		} else {
			$use_only_uuid = $options['mbek_use_only_uuid'] ?? false;
			wp_enqueue_style( 'mbek-tabulator-css', MBEK_PLUGIN_URL . 'resources/style/tabulator.min.css', array(), MBEK_Version );
			wp_enqueue_script( 'mbek-tablator-js', MBEK_PLUGIN_URL . 'resources/js/tabulator.min.js', array(), MBEK_Version );
			wp_enqueue_script( 'mbek-tjquery-wrapper-js', MBEK_PLUGIN_URL . 'resources/js/jquery_wrapper.js', array(), MBEK_Version );
			wp_enqueue_script( 'mbek-listproducts-js', MBEK_PLUGIN_URL . 'resources/js/mbek_list_products.js', array(), MBEK_Version );
			wp_localize_script(
				'mbek-listproducts-js',
				'mbek_lp_infos',
				array(
					'ajax_url_for_data' => get_admin_url() . 'admin-ajax.php?action=mbek_data_modelnumbers',
					'edit_url'          => get_admin_url() . 'post.php?post=',
					'uuid_url'          => get_admin_url() . 'admin.php?page=mbek-modelnumbers&uuid=',
					'model_url'         => get_admin_url() . 'admin.php?page=mbek-modelnumbers&model=',
					'use_only_uuid'     => $use_only_uuid,
				)
			);

			// echo '<link href="https://unpkg.com/tabulator-tables@5.6.1/dist/css/tabulator.min.css" rel="stylesheet">
			// <script type="text/javascript" src="https://unpkg.com/tabulator-tables@5.6.1/dist/js/tabulator.min.js"></script>';
			echo '<div class="table-responsive">';
			// echo '<caption>';
			// echo '<a href="' . get_admin_url() . 'admin-ajax.php?action=mbek_export_modelnumbers">Export CSV</a>';
			// echo '</caption>';
			echo '<div class="row"><div class="col">
		<button id="download-csv" class="btn btn-primary">Download CSV</button>
    	<button id="download-json" class="btn btn-primary">Download JSON</button>
	</div>
</div>';
			echo '<div id="mbek_products"></div>';
			// $ajax_url_for_data = get_admin_url() . 'admin-ajax.php?action=mbek_data_modelnumbers';
			// echo '<script type="module">
			// window.onload = function () {
			// import {TabulatorFull as Tabulator} from "tabulator-tables";
			// var table = new Tabulator("#mbek_products", {
			// ajaxURL: mbek_lp_infos.ajax_url_for_data,
			// height: "600px",
			// layout: "fitColumns",
			// placeholder: "No Data Set",
			// pagination: true,
			// paginationMode: "remote",
			// paginationSive: 10,
			// filterMode: "remote",
			// columns: [
			// {title: "ID", field: "id", sorter: "number", formatter: "html", width: 100},
			// {title: "Title", field: "title", sorter: "string", formatter: "html", headerFilter: "input"},
			// {title: "Model", field: "model", sorter: "string", headerFilter: "input"},
			// {title: "UUID", field: "uuid", sorter: "string", headerFilter: "input"},
			// {title: "Option", field: "option", formatter: "html", width: 150},
			// {title: "View", field: "view", formatter: "html", width: 100}
			// ]
			// });
			// }
			// </script>';
		}
		echo '</div>';
	}

	/**
	 * Function for updating metadata in the admin page.
	 *
	 * @return void
	 */
	public static function mbek_meta_updater() {
		self::mbek_css_and_js();
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		echo '<div id="mbek_akeneo_data" class="wrap">
            <h1>Middleby Akeneo</h1>';
		echo '<div>Meta Updater</div>';
		echo '<p><a href="' . get_admin_url() . 'admin.php?page=mbek-yoast&clear_meta_descriptions=1">Clear Yoast Meta Descriptions.</a></p>';
		if ( isset( $_REQUEST['clear_meta_descriptions'] ) && filter_var( $_REQUEST['clear_meta_descriptions'], FILTER_VALIDATE_BOOLEAN ) ) {
			// echo '<pre>' . print_r( $_REQUEST, true ) . '</pre>';
			echo self::clear_yoast_meta_description();
		}
		echo '</div>';
	}

	/**
	 * Clears Yoast Meta Descriptions for products that have pim_marketing_meta_description.
	 *
	 * @return string Returns 'Cleared Yaost Meta Descriptions.' if there are products with pim_marketing_meta_description,
	 *                otherwise returns 'Nothing to Clear'.
	 */
	public static function clear_yoast_meta_description() {
		// Get a list of Products that have pim_marketing_meta_description
		$options     = get_option( MBEK_OPTIONS );
		$post_type   = $options['mbek_post_type'];
		$search_args = array(
			'numberposts' => - 1,
			'post_type'   => $post_type,
			'fields'      => 'ids',
		);
		$posts       = get_posts( $search_args );
		$meta_posts  = array();
		$post_ids    = array();
		if ( $posts ) {
			foreach ( $posts as $post ) {
				$meta_value = get_field( 'pim_marketing_meta_description', $post );
				$meta       = get_field( '_yoast_wpseo_metadesc', $post );
				if ( $meta_value ) {
					$post_ids[]   = $post;
					$meta_posts[] = array(
						'ID'                             => $post,
						'pim_marketing_meta_description' => $meta_value,
						'_yoast_wpseo_metadesc'          => $meta,
					);
					update_post_meta( $post, '_yoast_wpseo_metadesc', '' );
				}
			}

			return 'Cleared Yaost Meta Descriptions.';
		} else {
			return 'Nothing to Clear';
		}
	}

	/**
	 * Dashboard page for Middleby Akeneo.
	 *
	 * @return void
	 * @global object $wpdb The WordPress database object.
	 */
	public static function mbek_dashboard() {
		global $wpdb;
		// Note: could make the date from the option of the PIM product last update.
		// mbek_options:mbek_cron_products_timestamp

		wp_enqueue_script( 'mbek_cron_js', MBEK_PLUGIN_URL . 'resources/js/cron.js', array(), MBEK_Version, false );

		$akeneo = new MBEK_Akeneo();
		$akeneo->start_client();
		self::mbek_css_and_js();
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$actions = array(
			'pull_products'                          => array(
				'label' => 'Get Products',
				'title' => 'Products',
				'descr' => 'This tool will run the main get_products action. This action is run every 12 hours.',
				'type'  => 'products',
			),
			'pull_pim_data&first_run=1'              => array(
				'label' => 'Fetch PIM Data (Initial Run)',
				'title' => 'PIM Data (initial run)',
				'descr' => 'This tool will Fetch an initial PIM Data request. This pulls all PIM products into the pim
				cache table. This needs to run first so families can be set in config/settings.',
				'type'  => 'products',
			),
			// 'mbek_product_assets'          => array(
			// 'label' => 'Check Assets',
			// 'title' => 'Assets',
			// 'descr' => 'This tool will run the check for new assets and update pim data last updated dates',
			// 'type'  => 'products',
			// ),
				'pull_pim_data'                      => array(
					'label' => 'Fetch PIM Data',
					'title' => 'PIM Data',
					'descr' => 'This tool will Re-Fetch all PIM data and process products. If you made recent changes to field
				mappings, then you should run this action.',
					'type'  => 'products',
				),
			'pull_accessories&first_run=1'           => array(
				'label' => 'Fetch PIM Accessory Data',
				'title' => 'PIM Accessory Data',
				'descr' => 'This tool will Re-Fetch all PIM data for accessories.',
				'type'  => 'accessories',
			),
			'pull_brand_categories'                  => array(
				'label' => 'Pull Brand Categories',
				'title' => 'Categories',
				'descr' => 'This tool will Fetch all PIM Categories.',
				'type'  => 'categories',
			),
			'pull_pim_taxonomies'                    => array(
				'label' => 'Pull PIM Taxonomies',
				'title' => 'Taxonomies',
				'descr' => 'This tool will fetch All Taxonomies.',
				'type'  => 'taxonomies',
			),
			'pull_ice_types'                         => array(
				'label' => 'Pull Ice Types',
				'title' => 'Ice Types',
				'descr' => 'This tool will fetch all Ice Types',
				'type'  => 'ice_types',
			),
			'pull_resources&first_run=1&ajax_call=1' => array(
				'label' => 'Pull Resources',
				'title' => 'Resources',
				'descr' => 'This tool will fetch All Resources',
				'type'  => 'resources',
			),
			'clear_mbek_attributes'                  => array(
				'label' => 'Clear Attribute options',
				'title' => 'Attribute options',
				'descr' => 'This tool will clear the option for attributes. Once cleared you can go to Field Mappings.
				It may take a while but it will then load new attributes from PIM.',
				'type'  => 'attributes',
			),
			'clear_mbek_pim_cache'                   => array(
				'label' => 'Clear PIM Data Cache',
				'title' => 'PIM Data cache',
				'descr' => 'This tool will clear all PIM data that is cached.',
				'type'  => 'attributes',
			),
			'clear_mbek_cpt'                         => array(
				'label' => 'Clear Products',
				'title' => 'Products CPT',
				'descr' => 'This tool will clear all CPT assigned as products.',
				'type'  => 'attributes',
			),
			'delete_cpt_not_in_pim'                  => array(
				'label' => 'Delete Products Not in PIM',
				'title' => 'Cleanup Products',
				'descr' => 'This tool will delete all Products that are no longer in the PIM.',
				'type'  => 'attributes',
			),
		);
		$options              = get_option( MBEK_OPTIONS );
		$mbek_has_accessories = ( $options['mbek_has_accessories'] && $options['mbek_accessory_post_type'] ) ?? false;
		if ( $mbek_has_accessories ) {
			$actions['clear_mbek_acc_cpt'] = array(
				'label' => 'Clear Accessories',
				'title' => 'Accessories CPT',
				'descr' => 'This tool will clear all CPT assigned as accessories.',
				'type'  => 'attributes',
			);
		}
		echo '<div id="mbek_akeneo_data" class="wrap">
            <h1>Middleby Akeneo</h1>';
		// echo '<strong>Tools</strong>';
		echo '<div class="container">';
		foreach ( $actions as $action => $info ) {
			echo '<div class="row">
				<div class="col">
		            <strong>' . $info['title'] . '</strong>
		            <p>' . $info['descr'] . '</p>
		        </div>';
			echo '<div class="col">
				<a class="cron_js_link btn btn-outline-primary" type="button"
				data-type="' . $info['type'] . '"
				data-url="' . get_site_url() . '/wp-admin/admin-ajax.php?action=' . $action . '"
				href="' . get_site_url() . '/wp-admin/admin-ajax.php?action=' . $action . '">' . $info['label'] . '</a>
				</div>';
			echo '</div>';
		}
		echo '<div id="tool-results">';
		echo '</div>';
		echo '</div>';
	}

	/**
	 * Initialize menus for the Middleby Akeneo plugin.
	 */
	public static function init_menus() {
		// Check we are allowed administrator privs
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$menu_page = add_menu_page(
			'Middleby',
			'Middleby Akeneo',
			'manage_options',
			'mbek',
			'mbek_options_page_html',
			'dashicons-admin-site-alt3',
			'20.02',
		);
		add_submenu_page(
			'mbek',
			'Middleby Akeneo Settings',
			'Config / Settings',
			'manage_options',
			'mbek',
			'mbek_options_page_html',
		);

		add_submenu_page(
			'mbek',
			'Alt Brands',
			'Alt Brands',
			'manage_options',
			'mbek-brands',
			array( 'MBEK_Admin', 'mbek_akeneo_brands' ),
		);

		add_submenu_page(
			'mbek',
			'Field Mappings',
			'Field Mappings',
			'manage_options',
			'mbek-api',
			array( 'MBEK_Admin', 'mbek_akeneo_field_page' ),
		);
		$options          = get_option( MBEK_OPTIONS );
		$woo_tabs_enabled = ( isset( $options['mbek_woo_tabs_enable'] ) ) ? $options['mbek_woo_tabs_enable'] : false;
		if ( $woo_tabs_enabled ) {
			add_submenu_page(
				'mbek',
				'Woo Tabs Mappings',
				'Woo Tabs Mappings',
				'manage_options',
				'mbek-woo-tabs',
				array( 'MBEK_Admin', 'mbek_akeneo_wootabs' ),
			);
		}
		add_submenu_page(
			'mbek',
			'Assets Mappings',
			'Assets Mappings',
			'manage_options',
			'mbek-assets',
			array( 'MBEK_Admin', 'mbek_akeneo_assets_page' ),
		);
		$mbek_has_accessories = $options['mbek_has_accessories'] ?? false;
		if ( $mbek_has_accessories ) {
			add_submenu_page(
				'mbek',
				'Accessory Mappings',
				'Accessory Mappings',
				'manage_options',
				'mbek-accessory-mappings',
				array( 'MBEK_Admin', 'mbek_accessory_mapping_page' ),
			);
		}

		// Get option for Admin IP's and create an array of the IP's.
		$admin_ips      = ( ! empty( $options['mbek_admin_ips'] ) ) ? $options['mbek_admin_ips'] : array();
		$administrators = array(
			'::1',
			'127.0.0.1',
		);
		if ( $admin_ips ) {
			$admin_ip_array = preg_split( '/[\s,]+/', $admin_ips );
			if ( ! empty( $admin_ip_array ) ) {
				foreach ( $admin_ip_array as $admin_ip ) {
					if ( filter_var( $admin_ip, FILTER_VALIDATE_IP ) ) {
						$administrators[] = $admin_ip;
					}
				}
			}
		}
		if ( in_array( $_SERVER['REMOTE_ADDR'], $administrators ) ) {
			add_submenu_page(
				'mbek',
				'Tools',
				'Tools',
				'manage_options',
				'mbek-admin',
				array( 'MBEK_Admin', 'mbek_dashboard' ),
			);
			add_submenu_page(
				'mbek',
				'List Families',
				'List Families',
				'manage_options',
				'mbek-families',
				array( 'MBEK_Admin', 'mbek_list_families' ),
			);
			add_submenu_page(
				'mbek',
				'Yoast Meta',
				'Yoast Meta',
				'manage_options',
				'mbek-yoast',
				array( 'MBEK_Admin', 'mbek_meta_updater' ),
			);
			add_submenu_page(
				'mbek',
				'List Products',
				'List Products',
				'manage_options',
				'mbek-modelnumbers',
				array( 'MBEK_Admin', 'mbek_check_model_numbers' ),
			);
			if ( $mbek_has_accessories ) {
				add_submenu_page(
					'mbek',
					'List Accessories',
					'List Accessories',
					'manage_options',
					'mbek-accessorynumbers',
					array( 'MBEK_Admin', 'mbek_check_accessories' ),
				);
			}
			$pim_category_taxonomy = get_option( 'options_pim_category_taxonomy' );
			if ( $pim_category_taxonomy ) {
				add_submenu_page(
					'mbek',
					'Check Categories',
					'Check Categories',
					'manage_options',
					'mbek-checkcategories',
					array( 'MBEK_Admin', 'mbek_check_categories' ),
				);
			}

			add_submenu_page(
				'mbek',
				'Check Photos',
				'Check Photos',
				'manage_options',
				'mbek-checkmissingphotos',
				array( 'MBEK_Admin', 'mbek_check_missing_photofeatures' ),
			);

			add_submenu_page(
				'mbek',
				'Import/Export Settings',
				'Import/Export Settings',
				'manage_options',
				'mbek-importexport',
				array( 'MBEK_Admin', 'mbek_import_export' ),
			);
		}
	}

	/**
	 * Admin page for Import/Export settings.
	 *
	 * @return void
	 */
	public static function mbek_import_export() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		self::mbek_css_and_js( true );
		echo '<div id="mbek_akeneo_data" class="wrap i_mbek_wrap">
            <h1>Import / Export Settings</h1>';
		include MBEK_PLUGIN_DIR . 'view/admin/mbek_importexport.php';
		echo '</div>';
	}

	/**
	 * Init Admin Page for Field Mappings.
	 *
	 * @return void
	 */
	public static function mbek_akeneo_field_page() {
		self::mbek_css_and_js();
		require_once MBEK_PLUGIN_DIR . 'view/admin/mbek_mapping.php';
	}

	/**
	 * Admin page for Assets mapping.
	 *
	 * @return void
	 */
	public static function mbek_akeneo_assets_page() {
		self::mbek_css_and_js();
		require_once MBEK_PLUGIN_DIR . 'view/admin/mbek_assets.php';
	}

	/**
	 * Admin page for Accessory mapping.
	 *
	 * @return void
	 */
	public static function mbek_accessory_mapping_page() {
		self::mbek_css_and_js();
		require_once MBEK_PLUGIN_DIR . 'view/admin/mbek_accessories.php';
	}

	/**
	 * Alt brand setup page in Admin.
	 *
	 * @return void
	 */
	public static function mbek_akeneo_brands() {
		self::mbek_css_and_js();
		require_once MBEK_PLUGIN_DIR . 'view/admin/mbek_brands.php';
	}

	/**
	 * WooTabs Admin Screen.
	 *
	 * @return void
	 */
	public static function mbek_akeneo_wootabs() {
		self::mbek_css_and_js();
		require_once MBEK_PLUGIN_DIR . 'view/admin/mbek_wootabs.php';
	}

	/**
	 * AJAX Section.
	 */

	/**
	 * Convert data from PIM for display.
	 *
	 * @param $label
	 * @param $data
	 *
	 * @return mixed|string|void
	 */
	public static function convert_pim_data( $label, $data ) {
		static $main_attributes;
		if ( ! $main_attributes ) {
			$main_attributes = get_option( MBEK_ATTRIBUTES );
		}
		$return = $data[0];
		if ( isset( $main_attributes[ $label ] ) ) {
			// Get pim type.
			$pim_type = $main_attributes[ $label ]['type'];
			switch ( $pim_type ) {
				case 'pim_catalog_asset_collection':
					if ( is_array( $return['data'] ) ) {
						return implode( ', ', $return['data'] );
					} else {
						// $akeneo = new MBEK_Akeneo();
						// $akeneo->start_client();
						//
						// return $akeneo->fetch_media_asset_url( $data, $family );
					}
					// return $this->fetch_media_asset_url( $field, $family );
					break;
				case 'pim_catalog_text':
				case 'pim_catalog_textarea':
					return $return['data'];
					break;
				case 'pim_catalog_multiselect':
				case 'pim_catalog_simpleselect':
					if ( is_array( $return['data'] ) ) {
						return implode( ', ', $return['data'] );
					} else {
						return $return['data'];
					}

					break;
				case 'pim_catalog_metric':
					return $return['data']['amount'] . ' ' . $return['data']['unit'];

					break;
				case 'pim_catalog_price_collection':
					switch ( $return['data'][0]['currency'] ) {
						case 'USD':
						default:
							$currency = '$';
							break;
					}

					return $currency . $return['data'][0]['amount'];
					break;
				case 'pim_catalog_boolean':
					return $return['data'];
					break;

				case 'pim_catalog_table':
					if ( is_array( $return['data'] ) ) {
						return '<pre>' . print_r( $return['data'], true ) . '</pre>';
					}
					break;
			}
		}
	}

	/**
	 * Fetches product assets from Akeneo and updates the cache.
	 *
	 * @return bool Returns true after updating the cache.
	 */
	public static function mbek_product_assets() {
		// $start_timer = time();
		$akeneo = new MBEK_Akeneo();
		$akeneo->start_client();
		$assets   = array();
		$families = array(
			'brochure',
			// 'cad',
							'installations_instructions',
			'partslist',
			'PhotoAlt',
			'PhotoFeature',
			// 'revit',
							'specsheets',
			'usermanuals',
			// 'VideoFeature',
							'warrantysheet',
		// 'printautomatedspecsheets',
		);
		$asset_codes = array();
		foreach ( $families as $family ) {
			$ret = $akeneo->get_brand_asset_by_family( $family, false );
			if ( ! empty( $ret ) ) {
				$assets = array_merge( $assets, $ret );
			}
		}

		if ( ! empty( $assets ) ) {
			foreach ( $assets as $asset ) {
				$asset_codes[] = $asset['code'];
			}
		}
		// trigger_error( 'Asset codes: ' . print_r( $asset_codes, true ), E_USER_NOTICE );

		if ( ! empty( $asset_codes ) ) {
			$akeneo->update_date_for_pim_cache( $asset_codes );
		}

		return true;
	}

	/**
	 * Get all families by fetching all products and getting from all items their families.
	 *
	 * @return void
	 */
	public static function mbek_list_families() {
		$akeneo = new MBEK_Akeneo();
		$akeneo->start_client();
		echo '<div id="mbek_akeneo_data" class="wrap">
            <h1>Middleby Akeneo</h1>';
		$families = $akeneo->get_all_families();
		if ( ! empty( $families ) ) {
			foreach ( $families as $label => $count ) {
				echo '<div>' . $label . ': ' . $count . '</div>';
			}
		}
		echo '</div>';
	}

	/**
	 * Pull PIM API data and save to PIM Data tables.
	 *
	 * @return void
	 */
	public static function pull_pim_data() {
		if ( isset( $_GET['mbek_nonce'] ) && wp_verify_nonce( $_GET['mbek_nonce'], 'mbek_nonce' ) ) {
			$first_run = ( isset( $_REQUEST['first_run'] ) ) ? filter_var( $_REQUEST['first_run'], FILTER_VALIDATE_BOOLEAN ) : 0;
			$akeneo    = new MBEK_Akeneo();
			$akeneo->start_client();

			try {
				if ( $first_run ) {
					// Fetch the products from Akeneo and update the database cache table.
					$products = $akeneo->refresh_pim_data_cache_from_pim();
				} else {
					$main_products = $akeneo->get_products_by_brand( '', '', $first_run );
					$alt_products  = $akeneo->get_products_by_alt_brand( '', '', $first_run );
					$products      = array_merge( $main_products, $alt_products );
				}

				// After getting the main and alt products setup the queue for the cron.
				if ( ! $first_run && false === as_has_scheduled_action( 'mbek_sync_pim_table' ) ) {
					global $wpdb;

					$options         = get_option( MBEK_OPTIONS );
					$per_page        = isset( $options['mbek_paged'] ) && ! empty( $options['mbek_paged'] )
						? (int) $options['mbek_paged']
						: 20;
					$post_type       = $options['mbek_post_type'];
					$has_accessories = isset( $options['mbek_has_accessories'] ) ? $options['mbek_has_accessories'] : false;
					$table_name      = $wpdb->prefix . MBEK_PIM_DATA_TABLE_NAME;
					if ( $has_accessories ) {
						$total = $wpdb->get_var(
							$wpdb->prepare(
								"SELECT count(ID) as total
				                 FROM $table_name
				                WHERE post_type = %s",
								$post_type
							)
						);
					} else {
						$total = $wpdb->get_var(
							"SELECT count(ID) as total
				                     FROM $table_name"
						);
					}

					if ( $total > 0 ) {
						$paged = ceil( $total / $per_page );
						for ( $i = 0; $i < $paged; $i++ ) {
							$start = $i * $per_page;
							as_schedule_single_action(
								strtotime( 'now' ),
								'mbek_sync_pim_table',
								array(
									'start'     => $start,
									'first_run' => true,
								),
								'mbek_pim',
								false
							);
						}
					}
				}
				wp_send_json_success( $products, 200 );
			} catch ( \Akeneo\Pim\ApiClient\Exception\UnauthorizedHttpException $e ) {
				$errorMessage = $e->getMessage();
				wp_send_json_error( new WP_Error( '001', 'No data!' . $errorMessage, 'Something went wrong!' ), 500 );
			} catch ( \Akeneo\Pim\Exception\HttpException $e ) {
				// do your stuff with the exception
				$requestBody  = $e->getRequest()->getBody();
				$responseBody = $e->getResponse()->getBody();
				$httpCode     = $e->getCode();
				$errorMessage = $e->getMessage();
				wp_send_json_error( new WP_Error( '001', 'No data!' . $errorMessage, 'Something went wrong!' ), 500 );
			}
		} else {
			wp_die( 'no here!' );
		}
	}

	/**
	 * Pulls PIM taxonomy attributes from the PIM Category Options and updates the corresponding terms in WordPress.
	 *
	 * @return void
	 */
	public static function pull_pim_taxonomy_attributes() {
		if ( isset( $_GET['mbek_nonce'] ) && wp_verify_nonce( $_GET['mbek_nonce'], 'mbek_nonce' ) ) {
			$akeneo = new MBEK_Akeneo();
			$akeneo->start_client();

			// Get $pim_taxonomies from PIM Category Options.
			$pim_taxonomies = array();
			while ( have_rows( 'pim_taxonomy', 'option' ) ) {
				the_row();
				$taxonomy_name  = get_sub_field( 'pim_taxonomy_name' );
				$pim_field_name = get_sub_field( 'pim_field_name' );

				$attribute_options = $akeneo->get_brand_attribute_options( $pim_field_name );

				if ( ! empty( $attribute_options ) ) {
					foreach ( $attribute_options as $attribute_option ) {
						$title   = str_replace( '_', '-', $attribute_option['code'] );
						$slug    = sanitize_title( $title );
						$term    = array(
							'taxonomy'          => $taxonomy_name,
							'cat_name'          => $attribute_option['labels'][ $akeneo->get_category_locale() ],
							'category_nicename' => $slug,
						);
						$term_id = wp_insert_category( $term, true );
						if ( is_wp_error( $term_id ) ) {
							// Check if error is from existing term.
							if ( isset( $term_id->error_data['term_exists'] ) ) {
								$term_id = $term_id->error_data['term_exists'];
							}
						}
						if ( $term_id && ! is_wp_error( $term_id ) ) {
							$file_asset_url = isset( $attribute_option['website_series_image|c81b39c3-0e9f-4dfd-b645-634a58cbb954']['data']['original_filename'] )
								? 'https://middleby-cdn.com/categories/' . $akeneo->get_brand() . '/' . $attribute_option['website_series_image|c81b39c3-0e9f-4dfd-b645-634a58cbb954']['data']['original_filename']
								: '';

							update_field( 'field_64ca9a2853ccf', $attribute_option['code'], $taxonomy_name . '_' . $term_id );
							if ( isset( $attribute_option['website_series_name|176f5672-6950-49e3-8b87-a685a01a63cd']['data'] ) ) {
								update_field( 'field_64ca9acb6ae8a', $attribute_option['website_series_name|176f5672-6950-49e3-8b87-a685a01a63cd']['data'], $taxonomy_name . '_' . $term_id );
							}
							if ( isset( $attribute_option['website_series_description|4b482060-f242-4be1-93ba-075bc5277840']['data'] ) ) {
								update_field( 'field_64ca9ae76ae8b', $attribute_option['website_series_description|4b482060-f242-4be1-93ba-075bc5277840']['data'], $taxonomy_name . '_' . $term_id );
							}
							if ( isset( $file_asset_url ) ) {
								update_field( 'field_64ca9b15c15c2', $file_asset_url, $taxonomy_name . '_' . $term_id );
							}
						}
						$pim_taxonomies[] = $term;
					}
				}
			}

			wp_send_json_success( $pim_taxonomies, 200 );
		} else {
			wp_die( 'no here!' );
		}
	}

	/**
	 * Pulls brand categories from Akeneo and sync
	 * the data with WordPress.
	 *
	 * @return void
	 */
	public static function pull_brand_categories() {
		$first_run  = true;// ( isset( $_REQUEST['first_run'] ) ) ? filter_var( $_REQUEST['first_run'], FILTER_VALIDATE_BOOLEAN ) : 0;
		$start_date = ( isset( $_REQUEST['start_date'] ) ) ? filter_var( $_REQUEST['start_date'], FILTER_SANITIZE_STRING ) : '';
		$end_date   = ( isset( $_REQUEST['end_date'] ) ) ? filter_var( $_REQUEST['end_date'], FILTER_SANITIZE_STRING ) : '';

		try {
			$akeneo = new MBEK_Akeneo();
			$akeneo->start_client();
//			$first_run  = true;
			$categories = $akeneo->get_brand_categories( $start_date, $end_date, $first_run );
			$akeneo->sync_pim_catgory_data();
			wp_send_json_success( $categories, 200 );
		} catch ( \Akeneo\Pim\ApiClient\Exception\UnauthorizedHttpException $e ) {
			$errorMessage = $e->getMessage();
			wp_send_json_error( new WP_Error( '001', 'No data!', 'Something went wrong!' ), 500 );
		} catch ( \Akeneo\Pim\Exception\HttpException $e ) {
			// do your stuff with the exception
			$requestBody  = $e->getRequest()->getBody();
			$responseBody = $e->getResponse()->getBody();
			$httpCode     = $e->getCode();
			$errorMessage = $e->getMessage();
			wp_send_json_error( new WP_Error( '001', 'No data!', 'Something went wrong!' ), 500 );
		}
	}

	/**
	 * Pull the sub-brand categories from Akeneo.
	 *
	 * @return bool true if the categories were successfully pulled, false otherwise.
	 */
	public static function pull_sub_brand_categories() {
		$first_run  = ( isset( $_REQUEST['first_run'] ) ) ? filter_var( $_REQUEST['first_run'], FILTER_VALIDATE_BOOLEAN ) : 0;
		$start_date = ( isset( $_REQUEST['start_date'] ) ) ? filter_var( $_REQUEST['start_date'], FILTER_SANITIZE_STRING ) : '';
		$end_date   = ( isset( $_REQUEST['end_date'] ) ) ? filter_var( $_REQUEST['end_date'], FILTER_SANITIZE_STRING ) : '';

		try {
			$akeneo = new MBEK_Akeneo();
			$akeneo->start_client();
			$categories = $akeneo->get_sub_brand_categories( $start_date, $end_date, $first_run );
			// trigger_error( '$categories: ' . print_r($categories, true), E_USER_NOTICE );
			// wp_send_json_success( $categories, 200 );
		} catch ( \Akeneo\Pim\ApiClient\Exception\UnauthorizedHttpException $e ) {
			$errorMessage = $e->getMessage();
			// wp_send_json_error( new WP_Error( '001', 'No data!', 'Something went wrong!' ), 500 );
		} catch ( \Akeneo\Pim\Exception\HttpException $e ) {
			// do your stuff with the exception
			$requestBody  = $e->getRequest()->getBody();
			$responseBody = $e->getResponse()->getBody();
			$httpCode     = $e->getCode();
			$errorMessage = $e->getMessage();
			// wp_send_json_error( new WP_Error( '001', 'No data!', 'Something went wrong!' ), 500 );
		}

		return true;
	}

	/**
	 * Pulls the ICE types from Akeneo API and sends a JSON response.
	 *
	 * @return void
	 */
	public static function pull_ice_types() {
		if ( isset( $_GET['mbek_nonce'] ) && wp_verify_nonce( $_GET['mbek_nonce'], 'mbek_nonce' ) ) {
			$first_run  = ( isset( $_REQUEST['first_run'] ) ) ? filter_var( $_REQUEST['first_run'], FILTER_VALIDATE_BOOLEAN ) : 0;
			$start_date = ( isset( $_REQUEST['start_date'] ) ) ? filter_var( $_REQUEST['start_date'], FILTER_SANITIZE_STRING ) : '';
			$end_date   = ( isset( $_REQUEST['end_date'] ) ) ? filter_var( $_REQUEST['end_date'], FILTER_SANITIZE_STRING ) : '';

			$akeneo = new MBEK_Akeneo();
			$akeneo->start_client();
			$first_run = true;
			try {
				$ice_types = $akeneo->get_icetypes( $start_date, $end_date, $first_run );
				wp_send_json_success( $ice_types, 200 );
			} catch ( \Akeneo\Pim\ApiClient\Exception\UnauthorizedHttpException $e ) {
				$errorMessage = $e->getMessage();
				wp_send_json_error( new WP_Error( '001', 'No data!', 'Something went wrong!' ), 500 );
			} catch ( \Akeneo\Pim\Exception\HttpException $e ) {
				// do your stuff with the exception
				$requestBody  = $e->getRequest()->getBody();
				$responseBody = $e->getResponse()->getBody();
				$httpCode     = $e->getCode();
				$errorMessage = $e->getMessage();
				wp_send_json_error( new WP_Error( '001', 'No data!', 'Something went wrong!' ), 500 );
			}
		} else {
			wp_die( 'no here!' );
		}
	}

	/**
	 * Setup scheduled actions for syncing data from Akeneo.
	 *
	 * @return bool True if successful, otherwise False.
	 */
	public static function mbek_setup_schedules() {
		global $wpdb;
		$options         = get_option( MBEK_OPTIONS );
		$has_accessories = isset( $options['mbek_has_accessories'] ) ? $options['mbek_has_accessories'] : false;
		$per_page        = isset( $options['mbek_paged'] ) && ! empty( $options['mbek_paged'] )
			? (int) $options['mbek_paged']
			: 20;
		$post_type       = $options['mbek_post_type'];

		if ( ! $post_type ) {
			return true;
		}

		// Setup scheduled action for pulling Brand data from PIM.
		// Only if the categories are turned on.
		$pim_categories = ( isset( $options['mbek_pim_categories'] ) ) ? $options['mbek_pim_categories'] : false;
		if ( $pim_categories ) {
			if ( false === as_has_scheduled_action( 'mbek_pull_sub_brand_categories' ) ) {
				as_schedule_single_action( time(), 'mbek_pull_sub_brand_categories', array(), 'mbek_pim', false );
			}
		}

		// After getting the main and alt products setup the queue for the cron.
		$yesterday = date( 'Y-m-d H:i:s', strtotime( '-12 hours' ) );

		$table_name = $wpdb->prefix . MBEK_PIM_DATA_TABLE_NAME;
		if ( $has_accessories ) {
			$total = $wpdb->get_var(
				$wpdb->prepare(
					"SELECT count(ID) as total
				       FROM $table_name
				      WHERE updated >= %s
				        AND post_type = %s",
					$yesterday,
					$post_type
				)
			);
		} else {
			$total = $wpdb->get_var(
				$wpdb->prepare(
					"SELECT count(ID) as total
				       FROM $table_name
				      WHERE updated >= %s",
					$yesterday
				)
			);
		}
		if ( $total > 0 ) {
			$paged = ceil( $total / $per_page );
			for ( $i = 0; $i < $paged; $i++ ) {
				$start = $i * $per_page;
				if ( false === as_has_scheduled_action( 'mbek_sync_pim_table', array( 'start' => $start ), 'mbek_pim' ) ) {
					as_schedule_single_action( time(), 'mbek_sync_pim_table', array( 'start' => $start ), 'mbek_pim', false );
				}
			}
		}

		// Setup scheduled action for pulling accessories.
		// Only if the accessory flag is turned on.
		if ( $has_accessories ) {
			if ( false === as_has_scheduled_action( 'mbek_pull_accessories', array(), 'mbek_pim' ) ) {
				as_schedule_single_action( time(), 'mbek_pull_accessories', array(), 'mbek_pim', false );
			}
		}

		// Setup scheduled action for pulling brand category data from PIM.
		// Only if the categories are turned on.
		if ( $pim_categories ) {
			if ( false === as_has_scheduled_action( 'mbek_sync_brand_categories', array(), 'mbek_pim' ) ) {
				 as_schedule_single_action( time(), 'mbek_sync_brand_categories', array(), 'mbek_pim', false );
			}
		}

		if ( false === as_has_scheduled_action( 'mbek_pull_resources', array(), 'mbek_pim' ) ) {
			as_schedule_single_action( time(), 'mbek_pull_resources', array(), 'mbek_pim', false );
		}

		return true;
	}

	/**
	 * Pull products from Akeneo.
	 *
	 * @return void
	 */
	public static function pull_products() {
//		$first_run  = ( isset( $_REQUEST['first_run'] ) ) ? filter_var( $_REQUEST['first_run'], FILTER_VALIDATE_BOOLEAN ) : 0;
//		$start_date = ( isset( $_REQUEST['start_date'] ) ) ? filter_var( $_REQUEST['start_date'], FILTER_SANITIZE_STRING ) : '';
//		$end_date   = ( isset( $_REQUEST['end_date'] ) ) ? filter_var( $_REQUEST['end_date'], FILTER_SANITIZE_STRING ) : '';

		try {
			$akeneo = new MBEK_Akeneo();
			$akeneo->start_client();

			$options   = get_option( MBEK_OPTIONS );
			$post_type = $options['mbek_post_type'];

			$mbek_enable_delete = ( isset( $options['mbek_enable_delete'] ) ) ? (bool) $options['mbek_enable_delete'] : false;

			// Fetch the products from Akeneo and update the database cache table.
			$products = $akeneo->refresh_pim_data_cache_from_pim();

			if ( ! $post_type ) {
				wp_send_json_success( $products, 200 );
			}

			// Remove cpt not in pim_data table.
			if ( $mbek_enable_delete ) {
				self::delete_cpt_not_in_pim();
			}

			// Also sync products if they have updated assets.
			if ( false === as_has_scheduled_action( 'mbek_product_assets', array(), 'mbek_pim' ) ) {
				as_schedule_single_action( time(), 'mbek_product_assets', array(), 'mbek_pim', false );
			}

			// Setup the action that will create all the other ones.
			if ( false === as_has_scheduled_action( 'mbek_setup_schedules', array(), 'mbek_pim' ) ) {
				as_schedule_single_action( time(), 'mbek_setup_schedules', array(), 'mbek_pim', false );
			}

			wp_send_json_success( $products, 200 );
		} catch ( \Akeneo\Pim\ApiClient\Exception\UnauthorizedHttpException $e ) {
			$errorMessage = $e->getMessage();
			wp_send_json_error( new WP_Error( '001', 'No data!', 'Something went wrong!' ), 500 );
			trigger_error( 'Error UnauthorizedHttpException: No Data!', E_USER_NOTICE );
		} catch ( \Akeneo\Pim\Exception\HttpException $e ) {
			// do your stuff with the exception
			$requestBody  = $e->getRequest()->getBody();
			$responseBody = $e->getResponse()->getBody();
			$httpCode     = $e->getCode();
			$errorMessage = $e->getMessage();
			wp_send_json_error( new WP_Error( '001', 'No data!', 'Something went wrong!' ), 500 );
			trigger_error( 'Error HttpException: No Data!', E_USER_NOTICE );
		}
	}

	/**
	 * Pull accessories from Akeneo.
	 *
	 * This method retrieves accessories from Akeneo and sets up cron jobs if necessary.
	 *
	 * @return bool True if the accessories were pulled successfully, false otherwise.
	 */
	public static function pull_accessories() {
		$first_run  = ( isset( $_REQUEST['first_run'] ) ) ? \filter_var( $_REQUEST['first_run'], FILTER_VALIDATE_BOOLEAN ) : 0;
		$start_date = ( isset( $_REQUEST['start_date'] ) ) ? \filter_var( $_REQUEST['start_date'], FILTER_SANITIZE_STRING ) : '';
		$end_date   = ( isset( $_REQUEST['end_date'] ) ) ? \filter_var( $_REQUEST['end_date'], FILTER_SANITIZE_STRING ) : '';

		try {
			$akeneo = new MBEK_Akeneo();
			$akeneo->start_client();

			$options   = \get_option( MBEK_OPTIONS );
			$per_page  = isset( $options['mbek_paged'] ) && ! empty( $options['mbek_paged'] )
				? (int) $options['mbek_paged']
				: 20;
			$post_type = $options['mbek_accessory_post_type'];
			if ( empty( $post_type ) ) {
				return false;
			}
			$accessories = $akeneo->pim_accessories();
			// After getting the main and alt products setup the queue for the cron.
			if ( false === \as_has_scheduled_action( 'mbek_sync_pim_associaties_table' ) ) {
				global $wpdb;
				$yesterday = \date( 'Y-m-d H:i:s', \strtotime( '-12 hours' ) );

				$table_name = $wpdb->prefix . MBEK_PIM_DATA_TABLE_NAME;
				// $total      = $wpdb->get_var(
				// $wpdb->prepare(
				// "SELECT count(ID) as total
				// FROM $table_name
				// WHERE updated >= %s
				// AND post_type = %s",
				// $yesterday,
				// $post_type
				// )
				// );
				$total = $wpdb->get_var(
					$wpdb->prepare(
						"SELECT count(ID) as total
					       FROM $table_name
					      WHERE post_type = %s",
						$post_type
					)
				);
				if ( $total > 0 ) {
					$paged = ceil( $total / $per_page );
					for ( $i = 0; $i < $paged; $i++ ) {
						$start = $i * $per_page;

						\as_schedule_single_action(
							\strtotime( 'now' ),
							'mbek_sync_pim_associaties_table',
							array(
								'start'     => $start,
								'first_run' => $first_run,
							),
							'mbek_pim',
							false
						);
					}
					\as_schedule_single_action( \strtotime( 'now' ), 'mbek_link_pim_accessories', array(), 'mbek_pim', false );
				}
			}
			if ( $first_run ) {
				\wp_send_json_success( $accessories, 200 );
			}
		} catch ( \Akeneo\Pim\ApiClient\Exception\UnauthorizedHttpException $e ) {
			$errorMessage = $e->getMessage();
			\trigger_error( 'UnauthorizedHttpException: ' . $errorMessage, E_USER_NOTICE );
			// wp_send_json_error( new WP_Error( '001', 'No data!', 'Something went wrong!' ), 500 );
		} catch ( \Akeneo\Pim\Exception\HttpException $e ) {
			// do your stuff with the exception
			$requestBody  = $e->getRequest()->getBody();
			$responseBody = $e->getResponse()->getBody();
			$httpCode     = $e->getCode();
			$errorMessage = $e->getMessage();
			\trigger_error( 'HttpException: ' . $errorMessage, E_USER_NOTICE );
			// wp_send_json_error( new WP_Error( '001', 'No data!', 'Something went wrong!' ), 500 );
		}

		return true;
	}

	/**
	 * Synchronizes brand categories from Akeneo to the PIM.
	 *
	 * @return bool Indicates whether the synchronization was successful.
	 */
	public static function sync_brand_categories() {
		$first_run  = true; //( isset( $_REQUEST['first_run'] ) ) ? filter_var( $_REQUEST['first_run'], FILTER_VALIDATE_BOOLEAN ) : 0;
		$start_date = ( isset( $_REQUEST['start_date'] ) ) ? filter_var( $_REQUEST['start_date'], FILTER_SANITIZE_STRING ) : '';
		$end_date   = ( isset( $_REQUEST['end_date'] ) ) ? filter_var( $_REQUEST['end_date'], FILTER_SANITIZE_STRING ) : '';

		try {
			$akeneo = new MBEK_Akeneo();
			$akeneo->start_client();
			// Fetch PIM Categories - Save to pim_categories table.
			$akeneo->get_brand_categories( $start_date, $end_date, $first_run );
			// Sync the PIM Categories to the WP taxonomy.
			$akeneo->sync_pim_catgory_data();
		} catch ( \Akeneo\Pim\ApiClient\Exception\UnauthorizedHttpException $e ) {
			$errorMessage = $e->getMessage();
			\trigger_error( 'UnauthorizedHttpException: ' . $errorMessage, E_USER_NOTICE );
		} catch ( \Akeneo\Pim\Exception\HttpException $e ) {
			// do your stuff with the exception
			$requestBody  = $e->getRequest()->getBody();
			$responseBody = $e->getResponse()->getBody();
			$httpCode     = $e->getCode();
			$errorMessage = $e->getMessage();
			\trigger_error( 'HttpException: ' . $errorMessage, E_USER_NOTICE );
		} catch ( \Exception $e ) {
			$errorMessage = $e->getMessage();
			\trigger_error( 'Exception: ' . $errorMessage, E_USER_NOTICE );
		}

		return true;
	}

	/**
	 * Deletes custom post type (CPT) assets that are not present in the PIM system.
	 *
	 * This method retrieves all assets for a given family from the PIM system and compares them
	 * with the corresponding WordPress post types. Any assets that are not present in the PIM
	 * system are deleted from WordPress.
	 *
	 * @param array $asset {
	 *     Array containing information about the asset to process.
	 *
	 * @type string $family The family code of the asset in the PIM system.
	 * @type string $post_type The post type to check and delete posts from.
	 * }
	 *
	 * @return void
	 */
	public static function delete_asset_cpt_not_in_pim( $asset ) {
		$akeneo           = new MBEK_Akeneo();
		$pim_data_results = $akeneo->get_all_pim_assets_for_family( $asset['family'] );
		if ( ! empty( $pim_data_results ) ) {
			$pim_data = array_map(
				function ( $item ) {
					return $item->code;
				},
				$pim_data_results
			);
			$bad_post = get_posts(
				array(
					'posts_per_page' => - 1,
					'post_type'      => $asset['post_type'],
					'post_status'    => 'publish',
					'fields'         => 'ids',
					'meta_query'     => array(
						'relation' => 'AND',
						array(
							'key'     => 'pim_code',
							'value'   => $pim_data,
							'compare' => 'NOT IN',
						),
						array(
							'relation' => 'OR',
							array(
								'key'     => 'is_international',
								'value'   => '1',
								'compare' => '!=',
							),
							array(
								'key'     => 'is_international',
								'compare' => 'NOT EXISTS',
							),
						),
					),
				)
			);

		} else {
			$bad_post = get_posts(
				array(
					'posts_per_page' => - 1,
					'post_type'      => $asset['post_type'],
					'post_status'    => 'publish',
					'fields'         => 'ids',
					'meta_query'     => array(
						array(
							'relation' => 'OR',
							array(
								'key'     => 'is_international',
								'value'   => '1',
								'compare' => '!=',
							),
							array(
								'key'     => 'is_international',
								'compare' => 'NOT EXISTS',
							),
						),
					),
				)
			);
		}
		foreach ( $bad_post as $b_post ) {
			wp_delete_post( $b_post );
		}
	}

	/**
	 * Pulls resources from external services and updates the local system.
	 *
	 * This method interacts with an external Akeneo API to retrieve and process
	 * asset data. It clears the existing PIM asset table, retrieves and updates
	 * assets based on the mapped families, and handles data synchronization
	 * between the API and the local system. Any assets not found in the API are
	 * deleted from the system. The method also supports handling AJAX calls
	 * to return processed data in JSON format.
	 *
	 * @return bool True on successful execution and asset synchronization.
	 */
	public static function pull_resources() {
		$ajax_call = ( isset( $_REQUEST['ajax_call'] ) ) ? filter_var( $_REQUEST['ajax_call'], FILTER_VALIDATE_BOOLEAN ) : 0;
		$first_run = true; // ( isset( $_REQUEST['first_run'] ) ) ? filter_var( $_REQUEST['first_run'], FILTER_VALIDATE_BOOLEAN ) : 0;

		try {
			$assets_maps = get_option( MBEK_ASSETS_MAPS );
			$akeneo      = new MBEK_Akeneo();
			$akeneo->start_client();
			$akeneo->clear_pim_asset_table();
			$rows = array();
			if ( ! empty( $assets_maps ) ) {
				foreach ( $assets_maps as $map ) {
					$ret1 = $akeneo->get_brand_asset_by_family( $map['family'], true, $first_run );
					if ( ! empty( $ret1 ) ) {
						$rows = \array_merge( $rows, $ret1 );
					}
					$ret2 = $akeneo->update_assets_from_pim_table( $map );
					if ( ! empty( $ret2 ) ) {
						$rows = array_merge( $rows, $ret2 );
					}
					self::delete_asset_cpt_not_in_pim( $map );
				}
				if ( $ajax_call ) {
					\wp_send_json_success( $rows, 200 );
				}
			}
		} catch ( \Akeneo\Pim\ApiClient\Exception\UnauthorizedHttpException $e ) {
			$errorMessage = $e->getMessage();
			trigger_error( 'Error UnauthorizedHttpException: No Data!' . $errorMessage, E_USER_NOTICE );
			// \wp_send_json_error( new WP_Error( '001', 'No data!', 'Something went wrong!' ), 500 );
		} catch ( \Akeneo\Pim\Exception\HttpException $e ) {
			// do your stuff with the exception
			$requestBody  = $e->getRequest()->getBody();
			$responseBody = $e->getResponse()->getBody();
			$httpCode     = $e->getCode();
			$errorMessage = $e->getMessage();
			trigger_error( 'Error HttpException: No Data!' . $errorMessage, E_USER_NOTICE );
			// \wp_send_json_error( new WP_Error( '001', 'No data!', 'Something went wrong!' ), 500 );
		}

		return true;
	}

	/**
	 * Sync the PIM table data with product CPT.
	 *
	 * @param $start
	 * @param $first_run
	 *
	 * @return true
	 */
	public static function sync_pim_table( $start = 0, $first_run = false ) {
		try {
			$akeneo = new MBEK_Akeneo();
			$akeneo->start_client();
			$res = $akeneo->update_from_pim_table( $start, $first_run );
		} catch ( \Akeneo\Pim\ApiClient\Exception\UnauthorizedHttpException $e ) {
			$errorMessage = $e->getMessage();
		} catch ( \Akeneo\Pim\Exception\HttpException $e ) {
			// do your stuff with the exception
			$requestBody  = $e->getRequest()->getBody();
			$responseBody = $e->getResponse()->getBody();
			$httpCode     = $e->getCode();
			$errorMessage = $e->getMessage();
		}

		return true;
	}

	/**
	 * Sync PIM Accessories.
	 *
	 * @param int  $start The starting point for syncing accessories.
	 * @param bool $first_run Whether it is the first run of syncing accessories.
	 *
	 * @return void
	 */
	public static function sync_pim_accessories( $start = 0, $first_run = false ) {
		try {
			$akeneo = new MBEK_Akeneo();
			$akeneo->start_client();
			$res = $akeneo->update_accessories_from_pim_table( $start, $first_run );

			// trigger_error('$res:' . print_r( $res, true ), E_USER_NOTICE);
		} catch ( \Akeneo\Pim\ApiClient\Exception\UnauthorizedHttpException $e ) {
			$errorMessage = $e->getMessage();
		} catch ( \Akeneo\Pim\Exception\HttpException $e ) {
			// do your stuff with the exception
			$requestBody  = $e->getRequest()->getBody();
			$responseBody = $e->getResponse()->getBody();
			$httpCode     = $e->getCode();
			$errorMessage = $e->getMessage();
		}

		return true;
	}

	/**
	 * Link accessories method.
	 *
	 * @return bool Returns true if the linking process is successful, otherwise false.
	 */
	public static function link_accessories() {
		try {
			$akeneo = new MBEK_Akeneo();
			$akeneo->start_client();
			$res = $akeneo->link_products_to_accessories();
			// trigger_error('$res:' . print_r( $res, true ), E_USER_NOTICE);
		} catch ( \Akeneo\Pim\ApiClient\Exception\UnauthorizedHttpException $e ) {
			$errorMessage = $e->getMessage();
		} catch ( \Akeneo\Pim\Exception\HttpException $e ) {
			// do your stuff with the exception
			$requestBody  = $e->getRequest()->getBody();
			$responseBody = $e->getResponse()->getBody();
			$httpCode     = $e->getCode();
			$errorMessage = $e->getMessage();
		}

		return true;
	}

	/**
	 * Retrieves the JSON options for MBEK plugin.
	 *
	 * This method retrieves the MBEK options stored in the database using the MBEK_OPTIONS key.
	 * The options are then returned as a JSON response with a success status code.
	 *
	 * @return void
	 */
	public static function mbek_json_options() {
		$mbek_options = get_option( MBEK_OPTIONS );
		wp_send_json_success( $mbek_options, 200 );
	}

	/**
	 * Retrieves the JSON attribute maps from the option and returns them as a JSON response.
	 *
	 * @return void
	 */
	public static function mbek_json_attribute_maps() {
		$mbek_attribute_maps     = get_option( MBEK_ATTRIBUTE_MAPS );
		$filtered_array_mappings = array_filter( $mbek_attribute_maps, fn( $map ) => ! empty( $map['value'] ) );
		wp_send_json_success( $filtered_array_mappings, 200 );
	}
}
