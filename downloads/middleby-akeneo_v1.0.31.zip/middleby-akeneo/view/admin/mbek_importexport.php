<div class="container-lg">
    <div class="postbox i_mbek_div">
		<div class="mb-3">
			<a
                target="_blank"
                href="<?php echo site_url( '?export_settings=1' );?>"
                class="btn btn-primary">Export Settings for Akeneo Plugin</a>
		</div>
    </div>
    <div class="postbox i_mbek_div">
        <h3> <?php _e( 'Import/Update Settings', 'mbek' ); ?> </h3>
        <div class="main_options_div importer_div_wrapper">
            <div class="import_types_inputs_div">
                <h5 style="font-weight: bold; margin: 20px auto 30px;"> <?php
                    _e( 'Update ( This will update settings with the json that you are uploading. )', 'mbek' ); ?> </h5>
                <div class="import_type_input_div">
                    <input type="hidden" name="import_type" id="import_type_update" value="update" checked="checked">
                    <label for="import_type_update" style="display: none;">Update</label>
                </div>
            </div>

            <!-- The fileinput-button span is used to style the file input field as button -->
            <span class="btn btn-success fileinput-button">
                <i class="glyphicon glyphicon-plus"></i>
                <span>Select files...</span>
                <!-- The file input field used as target for the file upload widget -->
                <input id="fileupload" data-action="settings" type="file" name="files[]" accept=".json">
            </span>

            <!-- The global progress bar -->
            <div id="progress" class="progress">
                <div class="progress-bar progress-bar-success"></div>
            </div>

            <!-- The container for the uploaded files -->
            <div id="files" class="files"></div>
        </div>
    </div>
</div>
