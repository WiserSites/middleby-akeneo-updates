<?php
/**
 * Plugin Name:      Middleby Akeneo
 * Plugin URI:       wisersites.com
 * Description:      PIM Integration from Akeneo.
 * Version:          1.0.34.1
 * Requires PHP:     8.3
 * Author:           Wiser Sites
 * Author URI:       https://wisersites.com
 * Text Domain:      middleby-akeneo
 * Requires Plugins: advanced-custom-fields-pro
 */
if ( ! defined( 'MBEK_Version' ) ) {
	define( 'MBEK_Version', '1.0.34.1' );
}
if ( ! defined( 'MBEK_CLIENT_URL' ) ) {
	define( 'MBEK_CLIENT_URL', 'https://middleby-production.cloud.akeneo.com' );
}
// define( 'MBEK_CLIENT_URL', 'https://middleby-sandbox.cloud.akeneo.com' );
if ( ! defined( 'MBEK_CLIENT_ID' ) ) {
	define( 'MBEK_CLIENT_ID', '3_2ygmnxee9c2scc4g0wk0w4s4gk4wocs8wskcg84socwsc00s4k' );
}
if ( ! defined( 'MBEK_CLIENT_SECRET' ) ) {
	define( 'MBEK_CLIENT_SECRET', '12uwzc932gu84so0gs0gw0c0ows0o0kww40gowsowcs0o48c04' );
}
if ( ! defined( 'MBEK_CLIENT_USERNAME' ) ) {
	define( 'MBEK_CLIENT_USERNAME', 'wisersites_6090' );
}
if ( ! defined( 'MBEK_CLIENT_PASSWORD' ) ) {
	define( 'MBEK_CLIENT_PASSWORD', '78b6f83d3' );
}
if ( ! defined( 'MBEK_PLUGIN_URL' ) ) {
	define( 'MBEK_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
}
if ( ! defined( 'MBEK_PLUGIN_DIR' ) ) {
	define( 'MBEK_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
}
if ( ! defined( 'MBEK_PROTECTION_H' ) ) {
	define( 'MBEK_PROTECTION_H', plugin_basename( __FILE__ ) );
}
if ( ! defined( 'MBEK_NAME' ) ) {
	define( 'MBEK_NAME', 'middleby-akeneo' );
}
if ( ! defined( 'MBEK_OPTIONS' ) ) {
	define( 'MBEK_OPTIONS', 'mbek_options' );
}
if ( ! defined( 'MBEK_BRANDS' ) ) {
	define( 'MBEK_BRANDS', 'mbek_brands' );
}
if ( ! defined( 'MBEK_ASSETS_MAPS' ) ) {
	define( 'MBEK_ASSETS_MAPS', 'mbek_assets_maps' );
}
if ( ! defined( 'MBEK_CATEGORIES' ) ) {
	define( 'MBEK_CATEGORIES', 'mbek_categories' );
}
if ( ! defined( 'MBEK_WOOTABS' ) ) {
	define( 'MBEK_WOOTABS', 'mbek_wootabs' );
}
if ( ! defined( 'MBEK_WOOTAB_FIELD_ID' ) ) {
	define( 'MBEK_WOOTAB_FIELD_ID', 'mbek_wootab_field_id' );
}
if ( ! defined( 'MBEK_ALT_BRANDS' ) ) {
	define( 'MBEK_ALT_BRANDS', 'mbek_alt_brands' );
}
if ( ! defined( 'MBEK_CRON_HOOK' ) ) {
	define( 'MBEK_CRON_HOOK', 'mbek_cron_hook' );
}
if ( ! defined( 'MBEK_ATTRIBUTES' ) ) {
	define( 'MBEK_ATTRIBUTES', 'mbek_attributes' );
}
if ( ! defined( 'MBEK_ATTRIBUTE_MAPS' ) ) {
	define( 'MBEK_ATTRIBUTE_MAPS', 'mbek_attribute_maps' );
}
if ( ! defined( 'MBEK_ATTRIBUTE_VALUES' ) ) {
	define( 'MBEK_ATTRIBUTE_VALUES', 'mbek_attribute_values' );
}
if ( ! defined( 'MBEK_ACCESSORY_MAPS' ) ) {
	define( 'MBEK_ACCESSORY_MAPS', 'mbek_accessory_maps' );
}
if ( ! defined( 'MBEK_ASSETS_PREFIX' ) ) {
	define( 'MBEK_ASSETS_PREFIX', 'mbek_assets_' );
}
if ( ! defined( 'MBEK_FAMILIES' ) ) {
	define( 'MBEK_FAMILIES', 'mbek_families' );
}
if ( ! defined( 'MBEK_DB_VERSION_OPTION' ) ) {
	define( 'MBEK_DB_VERSION_OPTION', 'mbek_db_version' );
}
if ( ! defined( 'MBEK_DB_VERSION' ) ) {
	define( 'MBEK_DB_VERSION', '1.0.4' );
}
if ( ! defined( 'MBEK_PIM_DATA_TABLE_NAME' ) ) {
	define( 'MBEK_PIM_DATA_TABLE_NAME', 'pim_data' );
}
if ( ! defined( 'MBEK_PIM_ASSETS_TABLE_NAME' ) ) {
	define( 'MBEK_PIM_ASSETS_TABLE_NAME', 'pim_assets' );
}
if ( ! defined( 'MBEK_PIM_CATEGORY_TABLE_NAME' ) ) {
	define( 'MBEK_PIM_CATEGORY_TABLE_NAME', 'pim_categories' );
}

// Load action scheduler.
$action_scheduler = require_once __DIR__ . '/vendor/woocommerce/action-scheduler/action-scheduler.php';

require_once MBEK_PLUGIN_DIR . 'lib/class.mbek.php';
require_once MBEK_PLUGIN_DIR . 'lib/adv_cf_pim_category.php';
require_once MBEK_PLUGIN_DIR . 'lib/adv_cf_pim_filters.php';

register_activation_hook( __FILE__, array( 'MBEK', 'plugin_activation' ) );
register_deactivation_hook( __FILE__, array( 'MBEK', 'plugin_deactivation' ) );

add_action( 'init', array( 'MBEK', 'init' ) );

if ( is_admin() ) {
	require_once MBEK_PLUGIN_DIR . 'lib/class.mbek-admin.php';
	require_once MBEK_PLUGIN_DIR . 'lib/class.mbek-post-type-columns.php';
	add_action( 'init', array( 'MBEK_Admin', 'init' ) );
	add_action( 'init', array( 'MBEK_Post_Type_Columns', 'init' ) );
}

/**
 * Setup admin styles for marking items uneditable.
 *
 * @return void
 */
function wpse_admin_styles() {
    if ( current_user_can( 'edit_posts' ) ) {
        $screen           = get_current_screen();
        $options          = get_option( MBEK_OPTIONS );
        $mbek_lock_fields = isset( $options['mbek_lock_fields'] ) && $options['mbek_lock_fields'] ? true : false;
        if ( ! empty( $options ) && ! empty( $options['mbek_post_type'] ) ) {
            if ( $screen->post_type === $options['mbek_post_type']
                 && ! $screen->taxonomy
                 && $mbek_lock_fields
            ) {
                add_editor_style( MBEK_PLUGIN_URL . 'resources/style/custom-editor-style.css' );
                echo '<style>
					.pim_edit:not(.pim_can_edit) input[type=color],
					.pim_edit:not(.pim_can_edit) input[type=date],
					.pim_edit:not(.pim_can_edit) input[type=datetime-local],
					.pim_edit:not(.pim_can_edit) input[type=datetime],
					.pim_edit:not(.pim_can_edit) input[type=email],
					.pim_edit:not(.pim_can_edit) input[type=month],
					.pim_edit:not(.pim_can_edit) input[type=number],
					.pim_edit:not(.pim_can_edit) input[type=password],
					.pim_edit:not(.pim_can_edit) input[type=search],
					.pim_edit:not(.pim_can_edit) input[type=tel],
					.pim_edit:not(.pim_can_edit) input[type=text],
					.pim_edit:not(.pim_can_edit) input[type=time],
					.pim_edit:not(.pim_can_edit) input[type=url],
					.pim_edit:not(.pim_can_edit) input[type=week],
					.pim_edit:not(.pim_can_edit) select,
					.pim_edit:not(.pim_can_edit) textarea,
					.wp-editor-area:not(.pim_can_edit)
					 {
						background-color: #d63639 !important;
						color: white !important;
					}
				</style>
				<script>
				jQuery(function($){
					const PostTitle = $("#titlewrap");
					PostTitle.addClass("pim_edit");

                    $(".pim_edit").each(function(){
                        $(this).find("input").prop("disabled", true);
                        $(this).find("textarea").prop("disabled", true);
                    });
                    
                    $(".is_international input[type=checkbox]").change(function(){
                        if( $(this).is(":checked") ){
                            $(".pim_edit").addClass("pim_can_edit").find("input, textarea").prop("disabled", false);
                            $(".wp-editor-area").addClass("pim_can_edit");
                        } else {
                            $(".pim_edit").removeClass("pim_can_edit").find("input, textarea").prop("disabled", true);
                            $(".wp-editor-area").removeClass("pim_can_edit");
                        }
                    }).change();
				});
				</script>
			';
            }
        }
    }
}

add_action( 'admin_head', 'wpse_admin_styles' );
add_action( 'admin_notices', 'independence_notice' );

/**
 * Add Admin notices for PIM field being non editable.
 *
 * @return void
 */
function independence_notice() {
    global $pagenow;
    $admin_pages = array( 'post.php' );
    $screen      = get_current_screen();
    $options     = get_option( MBEK_OPTIONS );
    if ( ! empty( $options ) ) {
        if ( in_array( $pagenow, $admin_pages ) && $screen->post_type === $options['mbek_post_type'] ) {
            ?>
            <div class="notice notice-info is-dismissible">
                <p>PIM updated fields are <strong style="color: #d63639;">Red</strong> in Background. These will be
                    updated
                    by PIM API everynight. Updates done here are temporary.</p>
            </div>
            <?php
        }
    }
}

/**
 * Akeneo Plugin functioin to generate the URL for a custom image size.
 *
 * @param $image_url Asset server url.
 * @param $width     Desired image width maximium.
 * @param $height    Desired image height maximum.
 *
 * @return string
 */
function mbek_get_resized_image_url( $image_url, $width, $height ) {
    $options         = get_option( MBEK_OPTIONS );
    $url_parts       = parse_url( $image_url );
    $pim_photo_url   = substr( $url_parts['path'], 1 );
    $pim_photo_parts = explode( '/', $pim_photo_url );
    $post_image      = 'https://middleby-cdn.com/' . $pim_photo_parts[0] . '/' . $options['mbek_brand'] . '/' . $width . '/' . $height . '/' . $pim_photo_parts[1];

    return $post_image;
}

/**
 * Akeneo Plugin functioin to generate the URL for a custom image size.
 *
 * @param $image_url Asset server url.
 * @param $width     Desired image width maximium.
 * @param $height    Desired image height maximum.
 *
 * @return string
 */
function mbek_get_category_resized_image_url( $image_url, $width, $height ) {
    $options         = get_option( MBEK_OPTIONS );
    $url_parts       = parse_url( $image_url );
    $pim_photo_url   = substr( $url_parts['path'], 1 );
    $pim_photo_parts = explode( '/', $pim_photo_url );
    $photo           = isset( $pim_photo_parts[3] ) ? $pim_photo_parts[3] : $pim_photo_parts[2];
    if ( isset( $pim_photo_parts[3] ) ) {
        $post_image = 'https://middleby-cdn.com/' . $pim_photo_parts[0] . '/' . $options['mbek_brand'] . '/' . $pim_photo_parts[2] . '/' . $width . '/' . $height . '/' . $photo;
    } else {
        $post_image = 'https://middleby-cdn.com/' . $pim_photo_parts[0] . '/' . $options['mbek_brand'] . '/' . $width . '/' . $height . '/' . $photo;
    }

    return $post_image;
}

/**
 * Format the output of the PIM UNITS that have .0000 or .5000 (extra zeros).
 *
 * Also removes the Label from returned value.
 *
 * @param $value Raw PIM Value.
 * @param $label Label used in PIM (CENTIMETER, KILOWATT etc.).
 *
 * @return string
 */
function mbek_format_unit_value( $value, $label = '' ) {
    if ( empty( $value ) ) {
        return $value;
    }
    $formated_value = $value;
    $matches        = array();
    if ( $label != '' ) {
        preg_match( '%([0-9]*)\.([0-9]{4}) ' . $label . '%', $value, $matches );
    } else {
        preg_match( '%([0-9]*)\.([0-9]{4})%', $value, $matches );
    }
    if ( ! empty( $matches ) ) {
        if ( $matches[2] === '0000' ) {
            return number_format( $matches[1], 0, ',' );
        } else {
            $number = (float) "$matches[1].$matches[2]";

            return number_format( $number, 2, '.', ',' );
        }
    }

    return $formated_value;
}

/**
 * Callback to replace the Woocommerce image with asset server.
 *
 * @return void
 */
function replacing_template_loop_product_thumbnail() {

    remove_action( 'woocommerce_before_shop_loop_item_title', 'woocommerce_template_loop_product_thumbnail', 10 );

    function wc_template_loop_product_replaced_thumb() {
        $shop_image = get_field( 'pim_photofeature' );
        if ( $shop_image ) {
            $post_image = $post_image = mbek_get_resized_image_url( $shop_image, '324', '324' );
            echo '<img alt="" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" src="' . $post_image . '">';
        } else {
            echo woocommerce_get_product_thumbnail();
        }
    }

    add_action( 'woocommerce_before_shop_loop_item_title', 'wc_template_loop_product_replaced_thumb', 10 );
}

add_action( 'woocommerce_init', 'replacing_template_loop_product_thumbnail' );

require_once MBEK_PLUGIN_DIR . 'lib/plugin-update-checker/plugin-update-checker.php';
$MyUpdateChecker = PucFactory::buildUpdateChecker(
        'https://raw.githubusercontent.com/WiserSites/middleby-akeneo-updates/refs/heads/main/info.json',
        __FILE__,
        'middleby-akeneo-updates'
);
// Action Hooks that are called from the Action Schedular.
// mbek_sync_pim_table: Fetch pim_data (products) and sync with CPT for Products.
add_action(
        'mbek_sync_pim_table',
        function ( $start = 0, $first_run = false ) {
            require_once MBEK_PLUGIN_DIR . 'lib/class.mbek-admin.php';
            MBEK_Admin::sync_pim_table( $start, $first_run );
        },
        10,
        2
);
// mbek_sync_pim_associaties_table: Fetch pim_data (accessories) and sync with CPT for Accessories.
add_action(
        'mbek_sync_pim_associaties_table',
        function ( $start = 0, $first_run = false ) {
            require_once MBEK_PLUGIN_DIR . 'lib/class.mbek-admin.php';
            MBEK_Admin::sync_pim_accessories( $start, $first_run );
        },
        10,
        2
);
// mbek_link_pim_accessories: Fetch all products with associations and assign the terms for accessories.
add_action(
        'mbek_link_pim_accessories',
        function () {
            require_once MBEK_PLUGIN_DIR . 'lib/class.mbek-admin.php';
            MBEK_Admin::link_accessories();
        },
        10,
        0
);
// mbek_sync_brand_categories: Fetch Categories and sync with terms.
add_action(
        'mbek_sync_brand_categories',
        function () {
            require_once MBEK_PLUGIN_DIR . 'lib/class.mbek-admin.php';
            MBEK_Admin::sync_brand_categories();
        },
        10,
        0
);
// mbek_pull_accessories: Pull Accessories from PIM and sets up the schedules for sync.
add_action(
        'mbek_pull_accessories',
        function () {
            require_once MBEK_PLUGIN_DIR . 'lib/class.mbek-admin.php';
            MBEK_Admin::pull_accessories();
        },
        10,
        0
);
// mbek_product_assets: Fetches any updated assets and sets the updated_date for each product effected.
add_action(
        'mbek_product_assets',
        function () {
            require_once MBEK_PLUGIN_DIR . 'lib/class.mbek-admin.php';
            MBEK_Admin::mbek_product_assets();
        },
        10,
        0
);
// mbek_setup_schedules: Setup the Action Scheduler with proper items.
add_action(
        'mbek_setup_schedules',
        function () {
            require_once MBEK_PLUGIN_DIR . 'lib/class.mbek-admin.php';
            MBEK_Admin::mbek_setup_schedules();
        },
        10,
        0
);
// mbek_pull_sub_brand_categories: Fetch the categories from PIM.
add_action(
        'mbek_pull_sub_brand_categories',
        function () {
            require_once MBEK_PLUGIN_DIR . 'lib/class.mbek-admin.php';
            MBEK_Admin::pull_sub_brand_categories();
        },
        10,
        0
);
add_action(
        'mbek_pull_resources',
        function () {
            require_once MBEK_PLUGIN_DIR . 'lib/class.mbek-admin.php';
            MBEK_Admin::pull_resources();
        },
        10,
        0
);
// wp_mail_smtp_tasks_admin_hide.
add_filter( 'wp_mail_smtp_tasks_admin_hide_as_menu', '__return_false' );

function mbek_clean_acf_content( $content ) {
    if ( empty( $content ) ) {
        return $content;
    }

    $doc = new DOMDocument();
    @$doc->loadHTML( mb_convert_encoding( $content, 'HTML-ENTITIES', 'UTF-8' ), LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD );

    $nodesWithStyle = $doc->getElementsByTagName( '*' );
    foreach ( $nodesWithStyle as $node ) {
        $node->removeAttribute( 'style' );
    }

    $spanTags = $doc->getElementsByTagName( 'span' );
    for ( $i = $spanTags->length - 1; $i >= 0; $i -- ) {
        $spanTag  = $spanTags->item( $i );
        $fragment = $doc->createDocumentFragment();
        while ( $spanTag->childNodes->length > 0 ) {
            $fragment->appendChild( $spanTag->childNodes->item( 0 ) );
        }
        $spanTag->parentNode->replaceChild( $fragment, $spanTag );
    }

    $ulTags = $doc->getElementsByTagName( 'ul' );
    foreach ( $ulTags as $ulTag ) {
        $ulTag->setAttribute( 'class', 'checks' );
    }

    return $doc->saveHTML();
}

/**
 * Change Action Scheduler default purge to 1 Hour
 */
add_filter(
        'action_scheduler_retention_period',
        function () {
            return HOUR_IN_SECONDS;
        }
);

add_action(
        'admin_init',
        function () {
            if ( get_option( $opt_name = 'se_show_my_plugin_wizard_notice' ) ) {
                delete_option( $opt_name );
                add_action( 'admin_notices', 'se_wizard_notice' );
            }

            return;
        }
);

/**
 * Check if user has completed wizard already
 * if so then return true (don't show notice)
 */
function se_wizard_completed() {
    return false;
}

function se_wizard_notice() {

    if ( se_wizard_completed() ) {
        return;
    } // completed already
    ?>

    <div class="updated notice is-dismissible">
        <p>Welcome to my plugin! You're almost there, but we think this wizard might help you setup the plugin.</p>
        <p><a href="admin.php?page=my_plugin_wizard" class="button button-primary">Run wizard</a> <a
                    href="javascript:window.location.reload()" class="button">dismiss</a></p>
    </div>

    <?php
}

register_activation_hook(
        __FILE__,
        function () {
            update_option( 'se_show_my_plugin_wizard_notice', 1 );
        }
);
