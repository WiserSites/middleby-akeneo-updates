<?php

/**
 * Class MBEK_EXPORT
 *
 * This class handles the export functionality for MBEK data.
 */
class MBEK_EXPORT {
	/**
	 * Checks the export action.
	 *
	 * If the conditions are met, exports data as a JSON file.
	 *
	 * @return void
	 */
	public static function check_export_action() {
		if ( is_user_logged_in() && ! is_admin() && isset( $_REQUEST['export_settings'] ) ) {
			self::exportDataToJson();
		}
	}

	/**
	 * Exports data as a JSON file.
	 *
	 * Retrieves various options from the database and saves them as an array in the $exportData variable.
	 * Then creates a directory for saving the JSON file if it doesn't exist already.
	 * The JSON file is saved using the `file_put_contents` function with the $filePath
	 * and JSON-encoded $exportData as arguments.
	 * Finally, it sends the respective headers and offers the file for download.
	 *
	 * @return void
	 */
	private static function exportDataToJson() {
		$exportData  = array(
			'mbek_options'          => get_option( MBEK_OPTIONS ),
			'mbek_attributes'       => get_option( MBEK_ATTRIBUTES ),
			'mbek_attribute_maps'   => get_option( MBEK_ATTRIBUTE_MAPS ),
			'mbek_brands'           => get_option( MBEK_BRANDS ),
			'mbek_alt_brands'       => get_option( MBEK_ALT_BRANDS ),
			'mbek_assets_maps'      => get_option( MBEK_ASSETS_MAPS ),
			'mbek_attribute_values' => get_option( MBEK_ATTRIBUTE_VALUES ),
			'mbek_families'         => get_option( MBEK_FAMILIES ),
			'mbek_accessory_maps'   => get_option( MBEK_ACCESSORY_MAPS ),
			'mbek_wootabs'          => get_option( MBEK_WOOTABS ),
			'mbek_wootab_field_id'  => get_option( MBEK_WOOTAB_FIELD_ID ),
		);
		$uploadDir   = wp_upload_dir();
		$fileName    = 'MBEK-data.json';
		$folderName  = '/mbek_export_files';
		$fileDirname = $uploadDir['basedir'] . $folderName;
		if ( ! file_exists( $fileDirname ) ) {
			wp_mkdir_p( $fileDirname );
		}
		$filePath = $fileDirname . '/' . $fileName;
		$fileUrl  = $uploadDir['baseurl'] . $folderName . '/' . $fileName;
		file_put_contents( $filePath, json_encode( $exportData ) );

		header( 'Content-Type: application/octet-stream' );
		header( 'Content-Transfer-Encoding: Binary' );
		header( 'Content-disposition: attachment; filename="' . basename( $fileUrl ) . '"' );
		readfile( $fileUrl );
		exit;
	}
}
