<?php
if ( function_exists( 'acf_add_options_page' ) ) {
	acf_add_options_sub_page(
		array(
			'page_title'  => 'PIM Category Options',
			'menu_title'  => 'PIM Category Options',
			'menu_slug'   => 'mbek-category-settings',
			'capability'  => 'manage_options',
			'redirect'    => false,
			'parent_slug' => 'mbek',
		)
	);
}
add_action(
	'acf/include_fields',
	function () {
		if ( ! function_exists( 'acf_add_local_field_group' ) ) {
			return;
		}

		acf_add_local_field_group(
			array(
				'key'                   => 'group_64dce911d8dc4',
				'title'                 => 'PIM Category Options',
				'fields'                => array(
					array(
						'key'               => 'field_64dce912a21b8',
						'label'             => 'PIM Category Taxonomy',
						'name'              => 'pim_category_taxonomy',
						'aria-label'        => '',
						'type'              => 'text',
						'instructions'      => '',
						'required'          => 0,
						'conditional_logic' => 0,
						'wrapper'           => array(
							'width' => '',
							'class' => '',
							'id'    => '',
						),
						'default_value'     => '',
						'maxlength'         => '',
						'placeholder'       => '',
						'prepend'           => '',
						'append'            => '',
					),
					array(
						'key'               => 'field_6512d1e293660',
						'label'             => 'PIM Brand Taxonomy',
						'name'              => 'pim_brand_taxonomy',
						'aria-label'        => '',
						'type'              => 'text',
						'instructions'      => '',
						'required'          => 0,
						'conditional_logic' => 0,
						'wrapper'           => array(
							'width' => '',
							'class' => '',
							'id'    => '',
						),
						'default_value'     => '',
						'maxlength'         => '',
						'placeholder'       => '',
						'prepend'           => '',
						'append'            => '',
					),
					array(
						'key'               => 'field_6520118d65df2',
						'label'             => 'PIM Sub Brand Taxonomy',
						'name'              => 'pim_brand_taxonomy_sub_field',
						'aria-label'        => '',
						'type'              => 'text',
						'instructions'      => '',
						'required'          => 0,
						'conditional_logic' => 0,
						'wrapper'           => array(
							'width' => '',
							'class' => '',
							'id'    => '',
						),
						'default_value'     => '',
						'placeholder'       => '',
					),
					array(
						'key'               => 'field_654a6d7a90adc',
						'label'             => 'PIM Sub Brand Parent Category',
						'name'              => 'pim_sub_brand_taxonomy_parent',
						'aria-label'        => '',
						'type'              => 'text',
						'instructions'      => '',
						'required'          => 0,
						'conditional_logic' => 0,
						'wrapper'           => array(
							'width' => '',
							'class' => '',
							'id'    => '',
						),
						'default_value'     => '',
						'placeholder'       => '',
					),
					array(
						'key'               => 'field_6542832f300b1',
						'label'             => 'PIM ACF Field for Product Relations',
						'name'              => 'pim_acf_field_for_product_relations',
						'aria-label'        => '',
						'type'              => 'text',
						'instructions'      => '',
						'required'          => 0,
						'conditional_logic' => 0,
						'wrapper'           => array(
							'width' => '',
							'class' => '',
							'id'    => '',
						),
						'default_value'     => '',
						'placeholder'       => '',
					),
					array(
						'key'               => 'field_652588553d14f',
						'label'             => 'PIM Taxonomy',
						'name'              => 'pim_taxonomy',
						'aria-label'        => '',
						'type'              => 'repeater',
						'instructions'      => 'These settings are for the pulling attribute options from PIM',
						'required'          => 0,
						'conditional_logic' => 0,
						'wrapper'           => array(
							'width' => '',
							'class' => '',
							'id'    => '',
						),
						'layout'            => 'table',
						'pagination'        => 0,
						'min'               => 0,
						'max'               => 0,
						'collapsed'         => '',
						'button_label'      => 'Add Row',
						'rows_per_page'     => 20,
						'sub_fields'        => array(
							array(
								'key'               => 'field_65258bb4c84ca',
								'label'             => 'Taxonomy Name',
								'name'              => 'pim_taxonomy_name',
								'aria-label'        => '',
								'type'              => 'text',
								'instructions'      => 'Name of the Taxonomy',
								'required'          => 0,
								'conditional_logic' => 0,
								'wrapper'           => array(
									'width' => '',
									'class' => '',
									'id'    => '',
								),
								'default_value'     => '',
								'placeholder'       => '',
								'parent_repeater'   => 'field_652588553d14f',
							),
							array(
								'key'               => 'field_65258c0b09afc',
								'label'             => 'PIM Field Name',
								'name'              => 'pim_field_name',
								'aria-label'        => '',
								'type'              => 'text',
								'instructions'      => 'Name of the PIM Attribute Field',
								'required'          => 0,
								'conditional_logic' => 0,
								'wrapper'           => array(
									'width' => '',
									'class' => '',
									'id'    => '',
								),
								'default_value'     => '',
								'placeholder'       => '',
								'parent_repeater'   => 'field_652588553d14f',
							),
						),
					),
				),
				'location'              => array(
					array(
						array(
							'param'    => 'options_page',
							'operator' => '==',
							'value'    => 'mbek-category-settings',
						),
					),
				),
				'menu_order'            => 0,
				'position'              => 'normal',
				'style'                 => 'default',
				'label_placement'       => 'top',
				'instruction_placement' => 'label',
				'hide_on_screen'        => '',
				'active'                => true,
				'description'           => '',
				'show_in_rest'          => 0,
			)
		);
	}
);

$pim_category_taxonomy = get_option( 'options_pim_category_taxonomy' );

if ( $pim_category_taxonomy ) {
	add_action(
		'acf/init',
		function () use ( $pim_category_taxonomy ) {
			if ( ! function_exists( 'acf_add_local_field_group' ) ) {
				return;
			}

			$pim_brand_taxonomy    = get_option( 'options_pim_brand_taxonomy' );
			$pim_ice_type_taxonomy = get_option( 'options_pim_ice_type_taxonomy' );

			$pim_taxonomies = array();

			while ( have_rows( 'pim_taxonomy', 'option' ) ) {
				the_row();
				$pim_taxonomies[] = array(
					'name'      => get_sub_field( 'pim_taxonomy_name' ),
					'pim_field' => get_sub_field( 'pim_field_name' ),
				);
			}

			if ( $pim_category_taxonomy ) {
				$my_location[][] = array(
					'param'    => 'taxonomy',
					'operator' => '==',
					'value'    => $pim_category_taxonomy,
				);
			}
			if ( $pim_brand_taxonomy ) {
				$my_location[][] = array(
					'param'    => 'taxonomy',
					'operator' => '==',
					'value'    => $pim_brand_taxonomy,
				);
			}
			if ( ! empty( $pim_taxonomies ) ) {
				foreach ( $pim_taxonomies as $pim_tax ) {
					$my_location[][] = array(
						'param'    => 'taxonomy',
						'operator' => '==',
						'value'    => $pim_tax['name'],
					);
				}
			}
			if ( $pim_ice_type_taxonomy ) {
				$my_location[][] = array(
					'param'    => 'taxonomy',
					'operator' => '==',
					'value'    => $pim_ice_type_taxonomy,
				);
			}

			acf_add_local_field_group(
				array(
					'key'                   => 'group_64ca9a277b845',
					'title'                 => 'PIM Category Fields',
					'fields'                => array(
						array(
							'key'               => 'field_64ca9a2853ccf',
							'label'             => 'PIM Category Code',
							'name'              => 'pim_category_code',
							'aria-label'        => '',
							'type'              => 'text',
							'instructions'      => '',
							'required'          => 0,
							'conditional_logic' => 0,
							'wrapper'           => array(
								'width' => '',
								'class' => '',
								'id'    => '',
							),
							'default_value'     => '',
							'maxlength'         => '',
							'placeholder'       => '',
							'prepend'           => '',
							'append'            => '',
						),
						array(
							'key'               => 'field_64ca9acb6ae8a',
							'label'             => 'Website Series Name',
							'name'              => 'pim_website_series_name',
							'aria-label'        => '',
							'type'              => 'text',
							'instructions'      => '',
							'required'          => 0,
							'conditional_logic' => 0,
							'wrapper'           => array(
								'width' => '',
								'class' => '',
								'id'    => '',
							),
							'default_value'     => '',
							'maxlength'         => '',
							'placeholder'       => '',
							'prepend'           => '',
							'append'            => '',
						),
						array(
							'key'               => 'field_64ca9ae76ae8b',
							'label'             => 'Website Series Description',
							'name'              => 'pim_website_series_description',
							'aria-label'        => '',
							'type'              => 'textarea',
							'instructions'      => '',
							'required'          => 0,
							'conditional_logic' => 0,
							'wrapper'           => array(
								'width' => '',
								'class' => '',
								'id'    => '',
							),
							'default_value'     => '',
							'maxlength'         => '',
							'rows'              => '',
							'placeholder'       => '',
							'new_lines'         => '',
						),
						array(
							'key'               => 'field_654a8564f0652',
							'label'             => 'Website Product Series Features and Benefits',
							'name'              => 'pim_website_product_series_features_and_benefits',
							'aria-label'        => '',
							'type'              => 'textarea',
							'instructions'      => '',
							'required'          => 0,
							'conditional_logic' => 0,
							'wrapper'           => array(
								'width' => '',
								'class' => '',
								'id'    => '',
							),
							'default_value'     => '',
							'maxlength'         => '',
							'rows'              => '',
							'placeholder'       => '',
							'new_lines'         => '',
						),
						array(
							'key'               => 'field_64ca9b15c15c2',
							'label'             => 'Website Series Feature Image URL',
							'name'              => 'pim_website_series_feature_image_url',
							'aria-label'        => '',
							'type'              => 'url',
							'instructions'      => '',
							'required'          => 0,
							'conditional_logic' => 0,
							'wrapper'           => array(
								'width' => '',
								'class' => '',
								'id'    => '',
							),
							'default_value'     => '',
							'placeholder'       => '',
						),
					),
					'location'              => $my_location,
					'menu_order'            => 0,
					'position'              => 'normal',
					'style'                 => 'default',
					'label_placement'       => 'top',
					'instruction_placement' => 'label',
					'hide_on_screen'        => '',
					'active'                => true,
					'description'           => '',
					'show_in_rest'          => 0,
				)
			);
		}
	);
}
