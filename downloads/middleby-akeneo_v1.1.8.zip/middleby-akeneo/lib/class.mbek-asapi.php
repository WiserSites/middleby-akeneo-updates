<?php
add_action('rest_api_init', function () {
	register_rest_route('as-api/v1', '/failed-tasks', array(
		'methods' => 'GET',
		'callback' => 'get_as_failed_tasks',
		'permission_callback' => '__return_true'
	));
});

function get_as_failed_tasks() {
	// Get instance of the logger and store.
	$store  = ActionScheduler_Store::instance();
	$logger = ActionScheduler_Logger::instance();

	// Query for the 20 most recent failed tasks
	$query_args = array(
		'group'        => 'mbek_pim',
		'status'       => ActionScheduler_Store::STATUS_FAILED,
		'per_page'     => 1,
		'date'         => '4 hours ago',
		'date_compare' => '>=',
		'order'        => 'DESC',
	);

	$actions = as_get_scheduled_actions($query_args);
	$response = [];

	foreach ($actions as $id => $action) {
		// Use the Store to get the status safely
		$status = $store->get_status($id);

		// 2. Use the logger instance to fetch logs for this specific ID
		$logs = $logger->get_logs($id);

		$response[] = [
			'id'       => $id,
			'hook'     => $action->get_hook(),
			'args'     => $action->get_args(),
			'date'     => $action->get_schedule()->get_date()->format('Y-m-d H:i:s'),
			'log'      => $logs,
			'status'   => $status,
		];
	}

	return new WP_REST_Response($response, 200);
}