<?php
require_once MBEK_PLUGIN_DIR . '/lib/class.akeneo.php';
use Middleby\Akeneo\MBEK_Akeneo;
?>
<div class="wrap">
    <h1>Akeneo Asset Mappings</h1>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <?php
                if ( ! empty( $_REQUEST['save'] ) && $_REQUEST['save'] === 'true' ) {
                    if ( isset( $_REQUEST['mbek_nonce'] ) && wp_verify_nonce( $_REQUEST['mbek_nonce'], 'mbek_nonce' ) ) {
                        $asset_map = $_REQUEST['asset_map'];
                        if ( empty( $asset_map[0]['family'] ) ) {
                            $asset_map = array_slice( $asset_map, 1 );
                        }
                        update_option( MBEK_ASSETS_MAPS, $asset_map );
                        ?>
                        <div class="col-sm-6">
                            <div class="alert alert-success" role="alert">
                                <h4 class="alert-heading">Success!</h4>
                                <hr>
                                <p class="mb-0">Asset Mapping Saved Successfully!</p>
                            </div>
                        </div>
                        <?php
                    }
                }

                $assets_maps = get_option( MBEK_ASSETS_MAPS );
                $sel_options = get_post_types(
	                array(
		                '_builtin' => false,
	                ),
	                'names',
	                'and'
                );
                $akeneo = new MBEK_Akeneo();
                $akeneo->start_client();

                $asset_families = $akeneo->get_asset_families();
//                echo '<pre>'.print_r( $asset_families, true ).'</pre>';
                ?>

                <form method="post" class="row g-3"
                      action="<?php echo esc_url( admin_url( 'admin.php' ) ); ?>?page=mbek-assets">
                    <input type="hidden" name="mbek_nonce" value="<?php echo wp_create_nonce( 'mbek_nonce' ); ?>">
                    <input type="hidden" name="page" value="mbek-assets">
                    <input type="hidden" name="save" value="true">
                    <fieldset>
                        <legend>New Asset Map</legend>
                        <div class="mb-3 row">
                            <div class="col-md-2">
                                <label for="new_family">Asset Family</label>
                                <select class="form-control"
                                        id="new_family"
                                        name="asset_map[0][family]">
                                    <option></option>
		                            <?php
		                            foreach ( $asset_families as $family_key => $family_value ) {
			                            echo '<option value="' . esc_attr( $family_value['family'] ) . '">' . esc_attr( $family_value['label'] ) . '</option>';
		                            }
		                            ?>
                                </select>
                            </div>
                            <div class="col-md-2">
                                <label for="new_post_type">Post Type</label>
                                <select class="form-control"
                                        id="new_post_type"
                                        name="asset_map[0][post_type]">
                                    <option></option>
		                            <?php
		                            foreach ( $sel_options as $opt ) {
			                            echo '<option value="' . esc_attr( $opt ) . '">' . esc_attr( $opt ) . '</option>';
		                            }
		                            ?>
                                </select>
                            </div>
                            <div class="col-md-2">
                                <label for="new_code">code</label>
                                <input type="text" class="form-control" id="new_code" name="asset_map[0][code]" value="" />
                            </div>
                            <div class="col-md-2">
                                <label for="new_url">url</label>
                                <input type="text" class="form-control" id="new_url" name="asset_map[0][url]" value="" />
                            </div>
                            <div class="col-md-2">
                                <label for="new_label">label</label>
                                <input type="text" class="form-control" id="new_label" name="asset_map[0][label]" value="" />
                            </div>
                            <div class="col-md-1">
                                <button type="submit" class="btn btn-primary">Save</button>
                            </div>
                        </div>
                    </fieldset>

                    <fieldset>
                        <legend>Current Asset Maps</legend>
                        <?php
                        if ( ! empty( $assets_maps ) ) {
                            foreach ($assets_maps as $asset_key => $option ) {
                                ?>
                                <div class="mb-3 row mbek-asset-row">
                                    <div class="col-md-1">
                                        <span class="dashicons dashicons-trash mbek-delete-asset-map"></span>
                                    </div>
                                    <div class="col-md-2">
                                        <label for="asset_map">Family</label>
                                        <select class="form-control"
                                                id="new_family"
                                                name="asset_map[<?php echo $asset_key + 1; ?>][family]" required>
                                            <option></option>
		                                    <?php
		                                    foreach ( $asset_families as $family_key => $family_value ) {
			                                    echo '<option value="' . esc_attr( $family_value['family']  ) . '"';
			                                    if ( $option['family'] == $family_value['family'] ) {
				                                    echo ' selected';
			                                    }
			                                    echo '>' . esc_attr( $family_value['label'] ) . '</option>';
		                                    }
		                                    ?>
                                        </select>
                                    </div>
                                    <div class="col-md-2">
                                        <label for="asset_map">Post Type</label>
                                        <select class="form-control"  name="asset_map[<?php echo $asset_key + 1; ?>][post_type]">
                                            <option></option>
		                                    <?php
		                                    foreach ( $sel_options as $opt ) {
			                                    echo '<option value="' . esc_attr( $opt ) . '"';
			                                    if ( $option['post_type'] == $opt ) {
				                                    echo ' selected';
			                                    }
			                                    echo '>' . esc_attr( $opt ) . '</option>';
		                                    }
		                                    ?>
                                        </select>
                                    </div>
                                    <div class="col-md-2">
                                        <label for="asset_map">code</label>
                                        <input type="text" class="form-control" id="new_code" name="asset_map[<?php echo $asset_key + 1; ?>][code]" value="<?php echo $option['code']; ?>" required />
                                    </div>
                                    <div class="col-md-2">
                                        <label for="asset_map">url</label>
                                        <input type="text" class="form-control" id="new_url" name="asset_map[<?php echo $asset_key + 1; ?>][url]" value="<?php echo $option['url']; ?>" required />
                                    </div>
                                    <div class="col-md-2">
                                        <label for="asset_map">label</label>
                                        <input type="text" class="form-control" id="new_label" name="asset_map[<?php echo $asset_key + 1; ?>][label]" value="<?php echo $option['label']; ?>" required />
                                    </div>
                                </div>
                                <?php
                            }
                        }
                        ?>
                    </fieldset>
                    <div class="col-12">
                        <button type="submit" class="btn btn-primary">Save</button>
                    </div>
                </form>

            </div>
        </div>
    </div>
</div>
<script>
    jQuery(function($){
        console.log('hello there steve');
        $('.mbek-delete-asset-map').on('click', function(){
            console.log('clicked me!');
            console.log($(this).parents('.mbek-asset-row'));
            $(this).parents('.mbek-asset-row').remove();
        });
    });
</script>