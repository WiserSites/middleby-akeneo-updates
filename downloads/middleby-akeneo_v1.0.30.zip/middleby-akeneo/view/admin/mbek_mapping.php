<?php
require_once MBEK_PLUGIN_DIR . '/lib/class.akeneo.php';
require_once MBEK_PLUGIN_DIR . '/lib/class.mbek-products.php';

$options   = get_option( MBEK_OPTIONS );
$post_type = $options['mbek_post_type'];

$akeneo = new \Middleby\Akeneo\MBEK_Akeneo();
$akeneo->start_client();
$attributes = array();
//$family     = $akeneo->get_family();
sleep( 1 );
$main_attributes = get_option( MBEK_ATTRIBUTES );
//$main_attributes = array();
if ( ! $main_attributes ) {
//	$multi_families = $options['mbek_family_multi'];
	$atts = $akeneo->get_attributes_for_codes( $attributes );
	foreach ( $atts as $att ) {
		$main_attributes[ $att['code'] ] = $att;
	}
//	if ( ! empty( $multi_families ) ) {
//		$attributes = $akeneo->api_get_attributes_by_families( $multi_families );
//	}

	update_option( MBEK_ATTRIBUTES, $main_attributes );
}
//wp_die('here');
if ( ! empty( $main_attributes ) && is_array( $main_attributes ) ) {
	// Sort $main_attributes.
	ksort( $main_attributes );
}


$fields      = [
	[ 'name' => 'post_title', 'type' => 'Text' ],
	[ 'name' => 'post_content', 'type' => 'Text' ],
	[ 'name' => 'post_excerpt', 'type' => 'Text' ],
	[ 'name' => 'featured_image', 'type' => 'Image' ],
];
$products    = new \Middleby\Akeneo\MBEK_Products();
$test_fields = $products->get_acf_fields();

if ( ! empty( $test_fields ) ) {
	foreach ( $test_fields as $field ) {
		$fields[] = array(
			'name' => $field['name'],
			'type' => $field['type'],
		);
	}

}
// Sort $fields Array.
uasort( $fields, function ( $a, $b ) {
	return strnatcmp( $a['name'], $b['name'] );
} );
$json_pim_fields = array();
foreach ( $fields as $field ) {
	$f_name            = $field['name'];
	$f_type            = $field['type'];
	$json_pim_fields[] = "{ name: '$f_name', type: '$f_type' }";
}
$att_map = get_option( MBEK_ATTRIBUTE_MAPS );
if ( ! is_array( $att_map ) ) {
    $att_map = array();
}
// Get list of attribute maps with a value.
$att_map_with_values = array_filter( $att_map, fn( $n ) => $n['value'] != '' );
?>
<div class="wrap">
    <h1>Akeneo API Mapping</h1>
    <div class="container">
        <div class="col">Total:
			<?php
			echo count( $att_map_with_values );
			?>
        </div>
    </div>
    <div class="container" id="mbek_mapping">
		<?php
		if ( isset( $_REQUEST['success'] ) && $_REQUEST['success'] ) {
			?>
            <div class="col-sm-6">
                <div class="alert alert-success" role="alert">
                    <h4 class="alert-heading">Success!</h4>
                    <hr>
                    <p class="mb-0">Mapping Saved Successfully!</p>
                </div>
            </div>
			<?php
		}
		?>
        <div class="col-12">
            <button id="mbek_add_map" type="button" class="btn btn-primary">Add Mapping</button>
        </div>
        <div id="new_attributes"></div>
        <form method="post" id="mbek_mapp_form"
              action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
            <input type="hidden" name="action" value="save_mbek_attributes"/>
            <input type="hidden" name="mbek_nonce" value="<?php echo wp_create_nonce( 'mbek_nonce' ); ?>"/>

			<?php
			// Need to go through all of the $main_attributes.
			$json_maps = array();
            $counter = 1;
			foreach ( $main_attributes as $attribute_label => $attribute_data ) {
				$label = isset( $attribute_data['labels'][$akeneo->get_default_locale()] )
					? $attribute_data['labels'][$akeneo->get_default_locale()]
					: $attribute_data['reference_data_name'];
				$title = isset( $attribute_data['labels'][$akeneo->get_default_locale()] ) ? $attribute_data['labels'][$akeneo->get_category_locale()] : $attribute_data['reference_data_name'];

				if ( ! isset( $att_map_with_values[ $attribute_label ] ) ) {
					$json_maps[] = "{ name: '$attribute_label' , label: '$label', title: '$title' }";
					continue;
				}
				if ( is_array( $att_map ) && ! empty( $att_map ) ) {
					$arr = array_values( array_filter( $att_map, fn( $n ) => $n['name'] === $attribute_label ) );
				} else {
					$arr = array();
				}
				echo '<div class="row mb-6">';
                echo '<div class="col-sm-1">';
                echo '<span>'.$counter.'</span>';
                echo '</div>';
                echo '<div class="col-sm-5">';
                $counter++;
				echo '<label for="' . $attribute_label . '" class="col-form-label">' . $title . '</label>';
                echo '</div>';
				echo '<div class="col-sm-5">';
				echo '<select id="' . $attribute_label . '" name="' . $attribute_label . '" class="form-select form-select-lg mb-6">';
				echo '<option></option>';
				foreach ( $fields as $field ) {
					echo '<option value="' . $field['name'] . '"';
					if ( isset( $arr ) && ! empty( $arr ) && $field['name'] === $arr[0]['value'] ) {
						echo ' selected';
					}
					echo '>' . $field['name'] . '</option>';
				}
				echo '</select>';
				echo '</div>';
				echo '</div>';
//				echo '<div class="col-md-6">';
//				echo '<button class="btn bt-secondary">Delete</button>';
//				echo '</div>';
			}
			?>

            <div class="col-12">
                <button id="mbek_submitter" type="submit" class="btn btn-primary">Save</button>
            </div>
        </form>
    </div>
    <script>
        jQuery(document).ready(function ($) {
            const mainAttributes = [
				<?php echo implode( ',', $json_maps ); ?>
            ];
            const pimFields = [
				<?php echo implode( ',', $json_pim_fields ); ?>
            ];
            const newAttributes = $('#new_attributes');
            const newAttrBtn = $('#mbek_add_map');
            const getPimAttributeSelect = function () {
                return `<select id="new_att_map_pim" class="form-select form-select-sm">
                    <option value="">- Select PIM From -</option>
                    ${mainAttributes.map(el => `<option value="${el.name}">${el.label}</option>`)}
                </select>`;
            };
            const getPimMappingSelect = function () {
                return `<select id="new_att_map" name="new_att_map" class="form-select form-select-sm">
                    <option value="">- Select ACF To -</option>
                    ${pimFields.map(el => `<option value="${el.name}">${el.name}</option>`)}
                </select>`;
            };
            const getMappingSelect = function (name, selected) {
                return `<select id="${name}" name="${name}" class="form-select form-select-sm">
                    <option value="">- Select -</option>
                    ${pimFields.map(el => `<option value="${el.name}" ${selected === el.name ? 'selected' : ''}>${el.name}</option>`)}
                </select>`;
            };
            const getFullMappHtml = function (pim_field, map_value) {
                return `<div class="col-md-12">
                    <label for="${pim_field}" class="form-label">${pim_field}</label>
                    ${getMappingSelect(pim_field, map_value)}
                </div>`;
            };
            // Functions.
            const addMapHandler = function (e) {
                e.preventDefault();
                const newSelect = `<div class="col-md-12">
                    <label for="new_att_map" class="form-label">New Mapping</label>
                    ${getPimAttributeSelect()}
                    ${getPimMappingSelect()}
                </div>`;
                newAttributes.append(newSelect);
                const addCancelBtn = `<div class="col-md-12">
                    <button class="btn btn-secondary" id="mbek_add_map_cancel">Cancel</button>
                    <button class="btn btn-primary" id="mbek_add_map_save">Add</button>
                </div>`;
                newAttributes.append(addCancelBtn);
                newAttrBtn.hide();
            };
            const resetNewSection = function () {
                newAttributes.html('');
                newAttrBtn.show();
            };
            const addMapSaveHandler = function (e) {
                e.preventDefault();
                // Check that this attribute is not already mapped.
                newPimAttribute = $('#new_att_map_pim').val();
                newPimFieldMap = $('#new_att_map').val();
                if (newPimAttribute && newPimFieldMap) {
                    // loop through all form elements.
                    const form = document.getElementById('mbek_mapp_form');
                    const submitter = document.getElementById('mbek_submitter');
                    const formData = new FormData(form, submitter);
                    for (const [key, value] of formData) {
                        if (newPimFieldMap === value) {
                            alert('You need to select a different ACF To!');
                            return;
                        }
                        if (newPimAttribute === key) {
                            alert('You need to select a different PIM From!');
                            return;
                        }
                        console.log(`${key}: ${value}`);

                    }
                    $('#mbek_mapp_form').prepend(getFullMappHtml(newPimAttribute, newPimFieldMap));
                    resetNewSection();
                } else {
                    alert('You need to select for both\nPIM From\nACF To!');
                }

            };
            const addMapCancelHandler = function (e) {
                e.preventDefault();
                resetNewSection();
            };

            // Event Listeners.
            $('#mbek_mapping').on('click', '#mbek_add_map', addMapHandler);
            $('#mbek_mapping').on('click', '#mbek_add_map_cancel', addMapCancelHandler);
            $('#mbek_mapping').on('click', '#mbek_add_map_save', addMapSaveHandler);

        });
    </script>

</div>