<?php

/**
 * Class MBEK_Post_Type_Columns
 *
 * Adds a custom column to the post list table for the configured post type.
 */
class MBEK_Post_Type_Columns {

	/**
	 * Initiated - Boolean true or false.
	 *
	 * @var bool
	 */
	private static $initiated = false;

	/**
	 * Initializes the class hooks.
	 *
	 * @return void
	 */
	public static function init() {
		if ( ! self::$initiated ) {
			self::init_hooks();
		}
	}

	/**
	 * Sets up the WordPress hooks.
	 *
	 * @return void
	 */
	private static function init_hooks() {
		self::$initiated = true;

		$options   = get_option( MBEK_OPTIONS );
		$post_type = $options['mbek_post_type'] ?? '';

		if ( ! empty( $post_type ) ) {
			add_filter( "manage_{$post_type}_posts_columns", array( __CLASS__, 'add_custom_column' ) );
			add_action( "manage_{$post_type}_posts_custom_column", array( __CLASS__, 'render_custom_column' ), 10, 2 );
			add_filter( "manage_edit-{$post_type}_sortable_columns", array( __CLASS__, 'make_columns_sortable' ) );
		}
	}

	/**
	 * Adds the "PIM Data" and "Modified" columns to the post list table.
	 *
	 * @param array $columns Existing columns.
	 *
	 * @return array Modified columns.
	 */
	public static function add_custom_column( $columns ) {
		$columns['mbek_pim_uuid'] = __( 'PIM Data', 'middleby-akeneo' );
		$columns['mbek_modified'] = __( 'Modified', 'middleby-akeneo' );

		return $columns;
	}

	/**
	 * Makes the custom columns sortable.
	 *
	 * @param array $columns Sortable columns.
	 *
	 * @return array Modified sortable columns.
	 */
	public static function make_columns_sortable( $columns ) {
		$columns['mbek_modified'] = 'modified';

		return $columns;
	}

	/**
	 * Renders the content for the custom columns.
	 *
	 * @param string $column_name The name of the column being rendered.
	 * @param int $post_id The ID of the current post.
	 *
	 * @return void
	 */
	public static function render_custom_column( $column_name, $post_id ) {
		if ( 'mbek_pim_uuid' === $column_name ) {
			$uuid = get_post_meta( $post_id, 'pim_uuid', true );
			if ( $uuid ) {
				$url = admin_url( 'admin.php?page=mbek-modelnumbers&uuid=' . urlencode( $uuid ) );
				echo '<a href="' . esc_url( $url ) . '" target="_blank">' . esc_html__( 'Pull From PIM Data', 'middleby-akeneo' ) . '</a>';
			} else {
				echo '<span class="description">' . esc_html__( 'No UUID', 'middleby-akeneo' ) . '</span>';
			}
		}

		if ( 'mbek_modified' === $column_name ) {
			echo esc_html( get_the_modified_date( 'Y/m/d g:i:s a', $post_id ) );
		}
	}
}
