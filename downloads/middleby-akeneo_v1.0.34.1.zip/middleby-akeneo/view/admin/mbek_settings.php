<?php

use Middleby\Akeneo\MBEK_Akeneo;

require_once MBEK_PLUGIN_DIR . '/lib/class.akeneo.php';
require_once MBEK_PLUGIN_DIR . '/vendor/autoload.php';

/**
 * Initialize the settings for the mbek plugin.
 */
function mbek_settings_init() {
    register_setting( 'mbek', 'mbek_options' );
    // Register a new sections in the "mbek" page.
    add_settings_section(
            'mbek_section_config',
            __( 'Akeneo API Config', 'mbek' ),
            'mbek_section_config_callback',
            'mbek'
    ); // Section mbek_section_config.
    add_settings_section(
            'mbek_section_sync',
            __( 'Sync Products from PIM', 'mbek' ),
            'mbek_section_sync_callback',
            'mbek',
    ); // Section mbek_section_sync.
    add_settings_section(
            'mbek_section_cat_sync',
            __( 'Sync Categories from PIM', 'mbek' ),
            'mbek_section_cat_sync_callback',
            'mbek',
    ); // Section mbek_section_cat_sync.
    add_settings_section(
            'mbek_wootabs',
            __( 'Woo Tabs', 'mbek' ),
            'mbek_section_api_callback',
            'mbek'
    ); // Section mbek_wootabs.
    add_settings_section(
            'mbek_section_api',
            __( 'Akeneo API', 'mbek' ),
            'mbek_section_api_callback',
            'mbek'
    ); // Section mbek_section_api.

    // mbek_section_config.
    add_settings_field(
            'mbek_lock_fields',
            __( 'Lock PIM Fields from being editable', 'mbek' ),
            'mbek_field_checkbox',
            'mbek',
            'mbek_section_config',
            array(
                    'label_for' => 'mbek_lock_fields',
                    'class'     => 'mbek_row',
            )
    ); // mbek_lock_fields.
    add_settings_field(
            'mbek_use_only_uuid',
            __( 'Use Only UUID', 'mbek' ),
            'mbek_field_checkbox',
            'mbek',
            'mbek_section_config',
            array(
                    'label_for' => 'mbek_use_only_uuid',
                    'class'     => 'mbek_row',
            )
    ); // mbek_use_only_uuid.
    add_settings_field(
            'mbek_admin_ips',
            __( 'Admin IP', 'mbek' ),
            'mbek_field_textarea',
            'mbek',
            'mbek_section_config',
            array(
                    'label_for' => 'mbek_admin_ips',
                    'class'     => 'mbek_row',
            )
    ); // mbek_admin_ips.

    // mbek_section_sync.
    add_settings_field(
            'mbek_brand',
            __( 'Brand', 'mbek' ),
            'mbek_field_brand',
            'mbek',
            'mbek_section_sync',
            array(
                    'label_for' => 'mbek_brand',
                    'class'     => 'mbek_row',
            )
    ); // mbek_brand.
    add_settings_field(
            'mbek_default_locale',
            __( 'Default Locale', 'mbek' ),
            'mbek_field_locale',
            'mbek',
            'mbek_section_sync',
            array(
                    'label_for' => 'mbek_default_locale',
                    'class'     => 'mbek_row',
            )
    ); // mbek_default_locale.
    add_settings_field(
            'mbek_pim_enabled',
            __( 'Return Enabled', 'mbek' ),
            'mbek_field_checkbox',
            'mbek',
            'mbek_section_sync',
            array(
                    'label_for' => 'mbek_pim_enabled',
                    'class'     => 'mbek_row',
            )
    ); // mbek_pim_enabled.
    add_settings_field(
            'mbek_pim_is_primary',
            __( 'Return Is Primary', 'mbek' ),
            'mbek_field_checkbox',
            'mbek',
            'mbek_section_sync',
            array(
                    'label_for' => 'mbek_pim_is_primary',
                    'class'     => 'mbek_row',
            )
    ); // mbek_pim_is_primary.
    add_settings_field(
            'mbek_discontinued_published',
            __( 'Discontinued Products Published', 'mbek' ),
            'mbek_field_checkbox',
            'mbek',
            'mbek_section_sync',
            array(
                    'label_for' => 'mbek_discontinued_published',
                    'class'     => 'mbek_row',
            )
    ); // mbek_discontinued_published.
    add_settings_field(
            'mbek_enable_delete',
            __( 'Sync PIM Deleted to CPT', 'mbek' ),
            'mbek_field_checkbox',
            'mbek',
            'mbek_section_sync',
            array(
                    'label_for' => 'mbek_enable_delete',
                    'class'     => 'mbek_row',
            )
    ); // mbek_enable_delete.

    // mbek_section_sync.
    add_settings_field(
            'mbek_product_id',
            __( 'Main Post ID', 'mbek' ),
            'mbek_field_number',
            'mbek',
            'mbek_section_sync',
            array(
                    'label_for' => 'mbek_product_id',
                    'class'     => 'mbek_row',
            )
    ); // mbek_product_id.
    add_settings_field(
            'mbek_paged',
            __( 'Process amount each cron task', 'mbek' ),
            'mbek_field_paged',
            'mbek',
            'mbek_section_sync',
            array(
                    'label_for' => 'mbek_paged',
                    'class'     => 'mbek_row',
            )
    ); // mbek_paged.
    add_settings_field(
            'mbek_post_type',
            __( 'Post Type (products)', 'mbek' ),
            'mbek_field_select',
            'mbek',
            'mbek_section_sync',
            array(
                    'label_for' => 'mbek_post_type',
                    'class'     => 'mbek_row',
            )
    ); // mbek_post_type.
    add_settings_field(
            'mbek_model_field',
            __( 'Model Field Name', 'mbek' ),
            'mbek_field_text',
            'mbek',
            'mbek_section_sync',
            array(
                    'label_for' => 'mbek_model_field',
                    'class'     => 'mbek_row',
            )
    ); // mbek_model_field.
    add_settings_field(
            'mbek_has_accessories',
            __( 'Has Accessories?', 'mbek' ),
            'mbek_field_checkbox',
            'mbek',
            'mbek_section_sync',
            array(
                    'label_for' => 'mbek_has_accessories',
                    'class'     => 'mbek_row',
            )
    ); // mbek_has_accessories.
    add_settings_field(
            'mbek_accessory_post_type',
            __( 'Post Type (accessories)', 'mbek' ),
            'mbek_field_select',
            'mbek',
            'mbek_section_sync',
            array(
                    'label_for' => 'mbek_accessory_post_type',
                    'class'     => 'mbek_row',
            )
    ); // mbek_accessory_post_type.
    add_settings_field(
            'mbek_accessory_acf_related_field',
            __( 'Accessory Related Field ACF', 'mbek' ),
            'mbek_field_text',
            'mbek',
            'mbek_section_sync',
            array(
                    'label_for' => 'mbek_accessory_acf_related_field',
                    'class'     => 'mbek_row',
            )
    ); // mbek_accessory_acf_related_field.

    // mbek_section_cat_sync.
    add_settings_field(
            'mbek_pim_categories',
            __( 'Enable PIM Categories', 'mbek' ),
            'mbek_field_checkbox',
            'mbek',
            'mbek_section_cat_sync',
            array(
                    'label_for' => 'mbek_pim_categories',
                    'class'     => 'mbek_row',
            )
    ); // mbek_pim_categories.
    add_settings_field(
            'mbek_category_locale',
            __( 'Category/Brand Locale', 'mbek' ),
            'mbek_field_locale',
            'mbek',
            'mbek_section_cat_sync',
            array(
                    'label_for' => 'mbek_category_locale',
                    'class'     => 'mbek_row',
            )
    ); // mbek_category_locale.
    add_settings_field(
            'mbek_categories_restriction',
            __( 'Categories Restriction', 'mbek' ),
            'mbek_field_text',
            'mbek',
            'mbek_section_cat_sync',
            array(
                    'label_for' => 'mbek_categories_restriction',
                    'class'     => 'mbek_row',
            )
    ); // mbek_categories_restriction.
    add_settings_field(
            'mbek_pim_create_categories',
            __( 'Sync New Categories from PIM', 'mbek' ),
            'mbek_field_checkbox',
            'mbek',
            'mbek_section_cat_sync',
            array(
                    'label_for' => 'mbek_pim_create_categories',
                    'class'     => 'mbek_row',
            )
    ); // mbek_pim_create_categories.
    add_settings_field(
            'mbek_pim_delete_categories',
            __( 'Sync Deleted Categories from PIM', 'mbek' ),
            'mbek_field_checkbox',
            'mbek',
            'mbek_section_cat_sync',
            array(
                    'label_for' => 'mbek_pim_delete_categories',
                    'class'     => 'mbek_row',
            )
    ); // mbek_pim_delete_categories.
    add_settings_field(
            'mbek_sync_only_from_website_tree',
            __( 'Sync Only Products from Website Categories Tree', 'mbek' ),
            'mbek_field_checkbox',
            'mbek',
            'mbek_section_cat_sync',
            array(
                    'label_for' => 'mbek_sync_only_from_website_tree',
                    'class'     => 'mbek_row',
            )
    ); // mbek_sync_only_from_website_tree.

    // mbek_wootabs.
    add_settings_field(
            'mbek_woo_tabs_enable',
            __( 'Enable Woo Tabs Update', 'mbek' ),
            'mbek_field_checkbox',
            'mbek',
            'mbek_wootabs',
            array(
                    'label_for' => 'mbek_woo_tabs_enable',
                    'class'     => 'mbek_row',
            )
    ); // mbek_woo_tabs_enable.

    // mbek_section_api.
    add_settings_field(
            'mbek_client_token',
            __( 'API Token', 'mbek' ),
            'mbek_field_token',
            'mbek',
            'mbek_section_api',
            array(
                    'label_for' => 'mbek_client_token',
                    'class'     => 'mbek_row',
            )
    ); // mbek_client_token.
    add_settings_field(
            'mbek_client_refresh_token',
            __( 'API Refresh Token', 'mbek' ),
            'mbek_field_token',
            'mbek',
            'mbek_section_api',
            array(
                    'label_for' => 'mbek_client_refresh_token',
                    'class'     => 'mbek_row',
            )
    ); // mbek_client_refresh_token.
    add_settings_field(
            'mbek_client_token_timestamp',
            __( 'API Token Timestamp', 'mbek' ),
            'mbek_field_time',
            'mbek',
            'mbek_section_api',
            array(
                    'label_for' => 'mbek_client_token_timestamp',
                    'class'     => 'mbek_row',
            )
    ); // mbek_client_token_timestamp.
    add_settings_field(
            'mbek_cron_assets_timestamp',
            __( 'PIM Assets Cron Timestamp', 'mbek' ),
            'mbek_field_time_display',
            'mbek',
            'mbek_section_api',
            array(
                    'label_for' => 'mbek_cron_assets_timestamp',
                    'class'     => 'mbek_row',
            )
    ); // mbek_cron_assets_timestamp.
    add_settings_field(
            'mbek_cron_products_timestamp',
            __( 'PIM Product Cron Timestamp', 'mbek' ),
            'mbek_field_time_display',
            'mbek',
            'mbek_section_api',
            array(
                    'label_for' => 'mbek_cron_products_timestamp',
                    'class'     => 'mbek_row',
            )
    ); // mbek_cron_products_timestamp.
}

/**
 * Register our mbek_settings_init to the admin_init action hook.
 */
add_action( 'admin_init', 'mbek_settings_init' );
/**
 * API section callback function.
 *
 * @param array $args The settings array, defining title, id, callback.
 */
function mbek_section_api_callback( $args ) {
    ?>
    <p id="<?php echo esc_attr( $args['id'] ); ?>"><?php esc_html_e( 'Middleby Akeneo API Credentials', 'mbek' ); ?></p>
    <?php
}

/**
 * Callback function for configuration section
 *
 * @param array $args The arguments for the section
 */
function mbek_section_config_callback( $args ) {
    ?>
    <p id="<?php echo esc_attr( $args['id'] ); ?>"><?php esc_html_e( 'Middleby Akeneo API Configuration', 'mbek' ); ?></p>
    <?php
}

function mbek_section_sync_callback( $args ) {
    ?>
    <p id="<?php echo esc_attr( $args['id'] ); ?>"><?php esc_html_e( 'Sync Products From Akeneo PIM to Wordpress', 'mbek' ); ?></p>
    <?php
}

function mbek_section_cat_sync_callback( $args ) {
    ?>
    <p id="<?php echo esc_attr( $args['id'] ); ?>"><?php esc_html_e( 'Sync Categories From Akeneo PIM to Wordpress', 'mbek' ); ?></p>
    <?php
}

/**
 * Text field callback function.
 *
 * WordPress has magic interaction with the following keys: label_for, class.
 * - the "label_for" key value is used for the "for" attribute of the <label>.
 * - the "class" key value is used for the "class" attribute of the <tr> containing the field.
 * Note: you can add custom key value pairs to be used inside your callbacks.
 *
 * @param array $args
 */
function mbek_field_text( $args ) {
    $options = get_option( MBEK_OPTIONS );
    $value   = ( ! empty( $options[ $args['label_for'] ] ) ) ? esc_attr( $options[ $args['label_for'] ] ) : '';
    ?>
    <input
            type="text"
            id="<?php echo esc_attr( $args['label_for'] ); ?>"
            name="mbek_options[<?php echo esc_attr( $args['label_for'] ); ?>]"
            value="<?php echo esc_attr( $value ); ?>"/>
    <?php
}

/**
 * Renders a number input field for the specified option.
 *
 * @param array $args {
 *     An array of arguments for rendering the field.
 *
 * @type string $label_for The option name to display as the input field's label.
 * }
 *
 * @return void
 */
function mbek_field_number( $args ) {
    $options = get_option( MBEK_OPTIONS );
    $value   = ( ! empty( $options[ $args['label_for'] ] ) ) ? esc_attr( $options[ $args['label_for'] ] ) : '';
    ?>
    <input
            type="number"
            min="1"
            id="<?php echo esc_attr( $args['label_for'] ); ?>"
            name="mbek_options[<?php echo esc_attr( $args['label_for'] ); ?>]"
            value="<?php echo esc_attr( $value ); ?>"/>
    <?php
}

/**
 * Textarea field for the options page.
 *
 * @param array $args Array of arguments for the field.
 *
 * @type string $label_for The ID of the field.
 *
 * @return void
 */
function mbek_field_textarea( $args ) {
    $options = get_option( MBEK_OPTIONS );
    $value   = ( ! empty( $options[ $args['label_for'] ] ) ) ? esc_attr( $options[ $args['label_for'] ] ) : '';
    ?>
    <textarea
            id="<?php echo esc_attr( $args['label_for'] ); ?>"
            name="mbek_options[<?php echo esc_attr( $args['label_for'] ); ?>]"
            style="height: 100px; width: 300px;"
    ><?php echo $value; ?></textarea>
    <div>Local IP is <?php echo esc_attr( $_SERVER['REMOTE_ADDR'] ) ?></div>
    <?php
}

/**
 * Generates a multi-select field with dropdown options for selecting family values.
 *
 * @param array $args An associative array of arguments:
 *                    - label_for: The ID attribute for the <select> element.
 *
 * @return void
 */
function mbek_field_family_multi( $args ) {
    $options = get_option( MBEK_OPTIONS );
    $akeneo  = new MBEK_Akeneo();
    $akeneo->start_client();
    $families = array_keys( $akeneo->get_all_families() );
    ?>
    <select
            id="<?php echo esc_attr( $args['label_for'] ); ?>"
            name="mbek_options[<?php echo esc_attr( $args['label_for'] ); ?>][]"
            multiple>
        <option value=""></option>
        <?php
        foreach ( $families as $family ) {
            echo '<option value="' . $family . '"';
            if ( isset( $options[ $args['label_for'] ] )
                 && is_array( $options[ $args['label_for'] ] )
                 && in_array( $family, $options[ $args['label_for'] ] )
            ) {
                echo ' selected';
            }
            echo '>' . $family . '</option>';
        }
        ?>
    </select>
    <?php
}

/**
 * Renders a select field with options based on the available post types
 *
 * @param array $args {
 *     An array of arguments for rendering the select field.
 *
 * @type string $label_for The ID of the select field.
 * }
 */
function mbek_field_select( $args ) {
    $options     = get_option( MBEK_OPTIONS );
    $sel_options = get_post_types(
            array(
//            'public'   => true,
                    '_builtin' => false,
            ),
            'names',
            'and'
    );
    ?>
    <select
            id="mbek_options[<?php echo esc_attr( $args['label_for'] ); ?>]"
            name="mbek_options[<?php echo esc_attr( $args['label_for'] ); ?>]">
        <option></option>
        <?php
        foreach ( $sel_options as $opt ) {
            echo '<option value="' . esc_attr( $opt ) . '"';
            if ( $options[ $args['label_for'] ] == $opt ) {
                echo ' selected';
            }
            echo '>' . esc_attr( $opt ) . '</option>';
        }
        ?>
    </select>
    <?php
}

/**
 * Render the select field for locale in the options page.
 *
 * @param array $args The arguments for the field.
 */
function mbek_field_locale( $args ) {
    $options      = get_option( MBEK_OPTIONS );
    $selected_opt = isset( $options[ $args['label_for'] ] ) ? $options[ $args['label_for'] ] : 'en_US';
//	$sel_options = array( 'en_US' => 'en_US' );
    $akeneo = new MBEK_Akeneo();
    $akeneo->start_client();
    $locales = $akeneo->get_all_locales();
    if ( ! empty( $locales ) ) {
        $sel_options = [];
        foreach ( $locales as $locale ) {
            $sel_options[ $locale['code'] ] = $locale['code'];
        }
    }
//    echo '<pre>'.print_r( $sel_options, true ).'</pre>';
    ?>
    <select
            id="mbek_options[<?php echo esc_attr( $args['label_for'] ); ?>]"
            name="mbek_options[<?php echo esc_attr( $args['label_for'] ); ?>]">
        <?php
        foreach ( $sel_options as $opt ) {
            echo '<option value="' . esc_attr( $opt ) . '"';
            if ( $selected_opt == $opt ) {
                echo ' selected';
            }
            echo '>' . esc_attr( $opt ) . '</option>';
        }
        ?>
    </select>
    <?php
}

/**
 * Renders a dropdown select field for a setting
 *
 * @param array $args The arguments for the field
 */
function mbek_field_paged( $args ) {
    $options     = get_option( MBEK_OPTIONS );
    $sel_options = array(
            20,
            10,
            5,
    );
    ?>
    <select
            id="mbek_options[<?php echo esc_attr( $args['label_for'] ); ?>]"
            name="mbek_options[<?php echo esc_attr( $args['label_for'] ); ?>]">
        <?php
        foreach ( $sel_options as $opt ) {
            echo '<option value="' . esc_attr( $opt ) . '"';
            if ( $options[ $args['label_for'] ] == $opt ) {
                echo ' selected';
            }
            echo '>' . esc_attr( $opt ) . '</option>';
        }
        ?>
    </select>
    <?php
}

/**
 * Renders a select input field for the brand options
 *
 * @param array $args The arguments for the field. It should contain 'label_for' key that corresponds to the option name in the options array.
 *
 * @return void
 */
function mbek_field_brand( $args ) {
    $options = get_option( MBEK_OPTIONS );
    $akeneo  = new MBEK_Akeneo();
    $akeneo->start_client();
    $brand_options = $akeneo->get_brands();
//	echo $akeneo->i_print( $brand_options, '$brand_options' );
    ?>
    <select
            id="mbek_options[<?php echo esc_attr( $args['label_for'] ); ?>]"
            name="mbek_options[<?php echo esc_attr( $args['label_for'] ); ?>]">
        <option></option>
        <?php
        foreach ( $brand_options as $opt ) {
            echo '<option value="' . esc_attr( $opt['code'] ) . '"';
            if ( $options[ $args['label_for'] ] == $opt['code'] ) {
                echo ' selected';
            }
            echo '>' . esc_attr( $opt['labels']['en_US'] ) . '</option>';
        }
        ?>
    </select>
    <?php
}

/**
 * Render the API token field in the settings page
 *
 * @param array $args {
 *     An array of arguments for rendering the API token field.
 *
 * @type string $label_for The identifier for the API token field.
 * }
 */
function mbek_field_token( $args ) {
    $options = get_option( MBEK_OPTIONS );
    ?>
    <div class="mbek-setting-api-token">
        <input type="hidden"
               name="mbek_options[<?php echo esc_attr( $args['label_for'] ); ?>]"
               value="<?php echo esc_attr( $options[ $args['label_for'] ] ); ?>"/>
        <?php if ( ! empty( $options[ $args['label_for'] ] ) ) { ?>
            <div
                    style="white-space: pre-wrap; word-wrap: break-word; max-width: 300px; height: 150px; "><?php echo $options[ $args['label_for'] ]; ?></div>
        <?php } else { ?>
            <!--            No token has been created yet!-->
        <?php } ?>
    </div>
    <?php
}

/**
 * Function to display time for a given field
 *
 * @param array $args The arguments for the field.
 *                    - label_for: The label for the field.
 *
 * @return void
 */
function mbek_field_time_display( $args ) {
    $options = get_option( MBEK_OPTIONS );
    ?>
    <div class="mbek-setting-api-token">
        <input type="hidden"
               name="mbek_options[<?php echo esc_attr( $args['label_for'] ); ?>]"
               value="<?php echo esc_attr( $options[ $args['label_for'] ] ); ?>"/>
        <?php if ( ! empty( $options[ $args['label_for'] ] ) ) { ?>
            <div style="break-word; max-width: 300px; height: 150px; "><h4>Local Time</h4>
                <?php
                $color = 'green';
                if ( $options[ $args['label_for'] ] ) {
                    $token_time = $options[ $args['label_for'] ];
                    $dt         = new DateTime( date( 'Y-m-d H:i:s', $token_time ), new DateTimeZone( 'UTC' ) );
                    $dt->setTimezone( new DateTimeZone( 'America/Detroit' ) );
                }
                echo ( $token_time ) ? '<p>Timestamp: ' . $dt->format( 'n/d/Y g:i A' ) . '</p>' : '';
                ?>
            </div>
        <?php } else { ?>
            <!--            No token has been created yet!-->
        <?php } ?>
    </div>
    <?php
}

/**
 * Display the field for time in the settings page
 *
 * @param array $args The arguments for the field
 */
function mbek_field_time( $args ) {
    $options = get_option( MBEK_OPTIONS );
    ?>
    <div class="mbek-setting-api-token">
        <input type="hidden"
               name="mbek_options[<?php echo esc_attr( $args['label_for'] ); ?>]"
               value="<?php echo esc_attr( $options[ $args['label_for'] ] ); ?>"/>
        <?php if ( ! empty( $options[ $args['label_for'] ] ) ) { ?>
            <div style="break-word; max-width: 300px; height: 150px; "><h4>Local Time</h4>
                <?php
                $color = 'green';
                if ( $options[ $args['label_for'] ] ) {
                    $token_time = $options[ $args['label_for'] ];
                    $dt         = new DateTime( date( 'Y-m-d H:i:s', $token_time ), new DateTimeZone( 'UTC' ) );
                    $dt->setTimezone( new DateTimeZone( 'America/Detroit' ) );
                    $current_time = new DateTime( date( 'Y-m-d H:i:s' ), new DateTimeZone( 'UTC' ) );
                    $current_time->setTimezone( new DateTimeZone( 'America/Detroit' ) );
                    $dt_expire = new DateTime( date( 'Y-m-d H:i:s', $token_time ), new DateTimeZone( 'UTC' ) );
                    $dt_expire->setTimezone( new DateTimeZone( 'America/Detroit' ) );
                    $dt_expire->modify( '+1 hour' );
                    if ( $current_time->format( 'U' ) > $dt_expire->format( 'U' ) ) {
                        $color = 'red';
                    }
                }

                echo '<p>Current Time: ' . $current_time->format( 'n/d/Y g:i A' ) . '</p>';
                echo ( $dt ) ? '<p>Token Timestamp: ' . $dt->format( 'n/d/Y g:i A' ) . '</p>' : '';
                echo ( $dt_expire ) ? '<p style="color: ' . $color . ';">Expires: ' . $dt_expire->format( 'n/d/Y g:i A' ) . '</p>' : '';
                ?>
            </div>
        <?php } else { ?>
            <!--            No token has been created yet!-->
        <?php } ?>
    </div>
    <?php
}

/**
 * Renders a checkbox field in the form
 *
 * @param array $args An array of arguments for rendering the checkbox field
 *                   - label_for (string) The ID of the checkbox field
 *
 * @return void
 */
function mbek_field_checkbox( $args ) {
//	echo '<pre>' . print_r( $args, true ) . '</pre>';
    $options = get_option( MBEK_OPTIONS );
    $value   = ( isset( $options[ $args['label_for'] ] ) && $options[ $args['label_for'] ] === 'true' ) ? 'checked' : '';
    ?>
    <input type="hidden" name="mbek_options[<?php echo esc_attr( $args['label_for'] ); ?>]" value="0">
    <div class="form-check">
        <input
                class="form-check-input"
                type="checkbox"
                id="<?php echo esc_attr( $args['label_for'] ); ?>"
                name="mbek_options[<?php echo esc_attr( $args['label_for'] ); ?>]"
                value="true" <?php echo $value; ?>>
        <label class="form-check-label" for="<?php echo esc_attr( $args['label_for'] ); ?>">Yes</label>
    </div>
    <?php
}

/**
 * Generates the HTML content for the options page.
 *
 * Checks user capabilities and displays the options page content if the user has the 'manage_options' capability.
 * Adds error/update messages if the settings have been submitted and saved successfully.
 * Outputs the options page HTML content.
 *
 * @return void
 */
function mbek_options_page_html() {
    // check user capabilities
    if ( ! current_user_can( 'manage_options' ) ) {
        return;
    }
    MBEK_Admin::mbek_css_and_js();

    // add error/update messages.

    // check if the user have submitted the settings.
    // WordPress will add the "settings-updated" $_GET parameter to the url.
    if ( isset( $_GET['settings-updated'] ) ) {
        // add settings saved message with the class of "updated".
        add_settings_error( 'mbek_messages', 'mbek_message', __( 'Settings Saved', 'mbek' ), 'updated' );
    }

    // show error/update messages.
    settings_errors( 'mbek_messages' );
    ?>
    <div class="wrap">
        <h1>Middleby Akeneo API</h1>
        <form action="options.php" method="post">
            <?php
            submit_button( 'Save Settings' );
            // output security fields for the registered setting "mbek".
            settings_fields( 'mbek' );
            // output setting sections and their fields.
            // (sections are registered for "mbek", each field is registered to a specific section).
            do_settings_sections( 'mbek' );
            // output save settings button.
            submit_button( 'Save Settings' );
            ?>
        </form>
    </div>
    <?php
}
