<div class="wrap">
    <h1>Accessory Mappings</h1>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
				<?php
				$pim_fields = array(
					'product_name' => 'Product Name',
					'model'        => 'Model',
					'PhotoFeature' => 'Photo Feature',
				);

				$wp_acf_fields = array(
					'post_title'        => 'Post Title',
					'pim_model'         => 'PIM Model',
					'pim_photo_feature' => 'PIM Photo Feature'
				);
                function build_select( $name, $values, $selected = null ) {
                    $html  = "<select name='$name'>";
                    $html .= "<option value=''> - Select - </option>";
                    foreach ( $values as $value => $label ) {
                        $html .= "<option value='$value'";
                        if ( $value == $selected ) {
                            $html .= " selected";
                        }
                        $html .= ">$label</option>";
                    }
                    $html .= "</select>";
                    return $html;
                }

				if ( ! empty( $_REQUEST['save'] ) && $_REQUEST['save'] === 'true' ) {
					if ( isset( $_REQUEST['mbek_nonce'] ) && wp_verify_nonce( $_REQUEST['mbek_nonce'], 'mbek_nonce' ) ) {
//                        echo '<pre>'.print_r($_REQUEST, true).'</pre>';
						$accessory_map = $_REQUEST['accessory_map'];
						if ( empty( $accessory_map[0]['pim_field'] ) ) {
							$accessory_map = array_slice( $accessory_map, 1 );
						}
						update_option( MBEK_ACCESSORY_MAPS, $accessory_map );
						?>
                        <div class="col-sm-6">
                            <div class="alert alert-success" role="alert">
                                <h4 class="alert-heading">Success!</h4>
                                <hr>
                                <p class="mb-0">Accessory Mapping Saved Successfully!</p>
                            </div>
                        </div>
						<?php
					}
				}

				$accessory_maps = get_option( MBEK_ACCESSORY_MAPS );
				?>

                <form method="post" class="row g-3"
                      action="<?php echo esc_url( admin_url( 'admin.php' ) ); ?>?page=mbek-accessory-mappings">
                    <input type="hidden" name="mbek_nonce" value="<?php echo wp_create_nonce( 'mbek_nonce' ); ?>">
                    <input type="hidden" name="page" value="mbek-accessory-mappings">
                    <input type="hidden" name="save" value="true">
                    <fieldset>
                        <legend>New Accessory Map</legend>
                        <div class="mb-3 row">
                            <div class="col-md-2">
                                <label for="new_family">PIM Field</label>
                                <?php  echo build_select( "accessory_map[0][pim_field]", $pim_fields ); ?>
                            </div>
                            <div class="col-md-2">
                                <label for="new_family">Wordpress Field</label>
	                            <?php  echo build_select( "accessory_map[0][wp_acf_field]", $wp_acf_fields ); ?>
                            </div>
                            <div class="col-md-1">
                                <button type="submit" class="btn btn-primary">Save</button>
                            </div>
                        </div>
                    </fieldset>

                    <fieldset>
                        <legend>Current Accessory Maps</legend>
						<?php
						if ( ! empty( $accessory_maps ) ) {
							foreach ( $accessory_maps as $accessory_key => $option ) {
                                $acc_key = $accessory_key + 1;
								?>
                                <div class="mb-3 row mbek-asset-row">
                                    <div class="col-md-1">
                                        <span class="dashicons dashicons-trash mbek-delete-asset-map"></span>
                                    </div>
                                    <div class="col-md-2">
                                        <label for="asset_map">PIM Field</label>
	                                    <?php  echo build_select( "accessory_map[$acc_key][pim_field]", $pim_fields, $option['pim_field'] ); ?>
                                    </div>
                                    <div class="col-md-2">
                                        <label for="asset_map">Wordpress Field</label>
	                                    <?php  echo build_select( "accessory_map[$acc_key][wp_acf_field]", $wp_acf_fields, $option['wp_acf_field'] ); ?>
                                    </div>
                                </div>
								<?php
							}
						}
						?>
                    </fieldset>
                    <div class="col-12">
                        <button type="submit" class="btn btn-primary">Save</button>
                    </div>
                </form>

            </div>
        </div>
    </div>
</div>
<script>
    jQuery(function ($) {
        console.log('hello there steve');
        $('.mbek-delete-asset-map').on('click', function () {
            console.log('clicked me!');
            console.log($(this).parents('.mbek-asset-row'));
            $(this).parents('.mbek-asset-row').remove();
        });
    });
</script>