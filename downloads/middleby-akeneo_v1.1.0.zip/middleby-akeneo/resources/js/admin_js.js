'use strict';
jQuery(document).ready( function( $ ) {
    const mbekLoadingHtml = '<div id="i_loading" style="display: none;"><span class="loading_txt"> Loading ...</span></div>';
    const uploadHandlerUrl = '/wp-content/plugins/middleby-akeneo/uploads/';
    const uploadLoaderHandler = function(e, data) {
        if (!$('#i_loading').length)
            $('body').append(mbekLoadingHtml);
        $('#i_loading').show();

        var import_type = 'update';

        $.each(data.result.files, function (index, file) {
            console.log(file);
            $('<p/>').text(file.name).appendTo('#files');

            $.ajaxSetup({async: true, cache: false});
            //Start import data from file
            $('#progress .progress-bar').css(
                'width', '0%'
            );

            var action_type = 'mbek_importer'; // Default action_type
            // If this is the related products import then use
            var dataAction = $('#fileupload').data('action');
            if (dataAction && dataAction === 'related') {
                action_type = 'mbek_importer';
            }
            var info = {
                action: action_type,
                import_file: file.url,
                import_type: import_type,
            };
            // console.log(info);

            $.post(mbek_infos.ajax_url, info).done(function (data) {
                $('#i_loading').hide();
                data = JSON.parse(data);
                // console.log(data);
                if (data.status) {
                    $('#progress .progress-bar').css(
                        'width', '100%'
                    );
                    $('.importer_div_wrapper .success_message').remove();
                    $('#progress').parent().append('<h2 class="success_message">'+data.html+'</h2>');
                }
            }).fail(function(data, status){
                // console.log('Failed',data,status);
                $('#i_loading').hide();
                $('#progress .progress-bar').css(
                    'width', '100%'
                );
                $('.importer_div_wrapper .success_message').remove();
                $('#progress').parent().append('<h2 class="success_message">Failure!</h2>');
            });
        });
    };
    const progressHandler = function(e, data){
        var progress = parseInt(data.loaded / data.total * 100, 10);
        $('#progress .progress-bar').css(
            'width',
            progress + '%'
        );
    };

    // Uploader  --
    $(".fileinput-button").click(function () {
        if ( !confirm( mbek_infos.import_sure_txt ) )
            return false
    });
    if ($('#fileupload').length)
        $('#fileupload').fileupload({
            url: uploadHandlerUrl,
            //autoUpload: false,
            acceptFileTypes: /(\.|\/)(json|JSON)$/i,
            dataType: 'json',
            done: uploadLoaderHandler,
            progressall: progressHandler
        }).prop('disabled', !$.support.fileInput)
            .parent().addClass($.support.fileInput ? undefined : 'disabled');

    //  --  Uploader
});