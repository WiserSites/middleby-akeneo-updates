<?php
use Middleby\Akeneo\MBEK_Akeneo;

$akeneo  = new MBEK_Akeneo();
$akeneo->start_client();
$brands = $akeneo->get_brands();
?>
<div class="wrap">
    <h1>Akeneo Alt Brands</h1>
    <div class="container">
        <div class="row">
            <div class="col-md-6">
		<?php
		/**
		 * Alt Brands Page
		 */
        $fields = array(
            array(
                'label' => 'Enabled',
                'name'  => 'enabled',
            ),
            array(
                'label' => 'Is Primary',
                'name'  => 'is_primary',
            ),
        );
		if ( ! empty( $_REQUEST['save'] ) && $_REQUEST['save'] === 'true' ) {
			if ( isset( $_REQUEST['mbek_nonce'] ) && wp_verify_nonce( $_REQUEST['mbek_nonce'], 'mbek_nonce' ) ) {
				$alt_brands = $_REQUEST['alt_brands'];
                if ( empty( $alt_brands[0]['brand'] ) ) {
                    $alt_brands = array_slice( $alt_brands, 1 );
                }
				update_option( MBEK_ALT_BRANDS, $alt_brands );
				?>
                <div class="col-sm-6">
                    <div class="alert alert-success" role="alert">
                        <h4 class="alert-heading">Success!</h4>
                        <hr>
                        <p class="mb-0">Alt Brand Saved Successfully!</p>
                    </div>
                </div>
				<?php
			}
		}

		$brand_options = get_option( MBEK_ALT_BRANDS );
		?>

        <form method="post" class="row g-3"
              action="<?php echo esc_url( admin_url( 'admin.php' ) ); ?>?page=mbek-brands">
            <input type="hidden" name="mbek_nonce" value="<?php echo wp_create_nonce( 'mbek_nonce' ); ?>">
            <input type="hidden" name="page" value="mbek-brands">
            <input type="hidden" name="save" value="true">
            <fieldset>
                <legend>New Brand</legend>
                <div class="mb-3 row">
                    <div class="col-md-6">
                        <label for="alt_brand_new">Brand Name</label>
                        <select name="alt_brands[][brand]">
                            <option></option>
	                        <?php
	                        foreach ( $brands as $opt ) {
		                        echo '<option value="' . esc_attr( $opt['code'] ) . '"';
		                        echo '>' . esc_attr( $opt['labels'][$akeneo->get_category_locale()] ) . '</option>';
	                        }
	                        ?>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <?php
                        foreach ( $fields as $field ) {
                            echo '<div class="form-check form-check-inline">';
                            echo '<input class="form-check-input" type="checkbox" id="alt_brand_new'.$field['name'].'" name="alt_brands[0][' . $field['name'] . ']" value="1">';
                            echo '<label class="form-check-label" for="alt_brand_new'.$field['name'].'">'.$field['label'].'</label>';
                            echo '</div>';
                        }
                        ?>
                    </div>
                </div>
            </fieldset>

            <fieldset>
                <legend>Current Alt Brands</legend>


			<?php
			if ( ! empty( $brand_options ) ) {
				foreach ( $brand_options as $brand_key => $option ) {
                    $brand_number = $brand_key + 1;
					?>
                    <div class="mb-3 row mbek-brand-row">
                        <div class="col-md-1">
                            <span class="dashicons dashicons-trash mbek-delete-alt-brand"></span>
                        </div>
                        <div class="col-md-6">
                            <select name="alt_brands[<?php echo $brand_number;?>][brand]">
                                <option></option>
		                        <?php
		                        foreach ( $brands as $opt ) {
			                        echo '<option value="' . esc_attr( $opt['code'] ) . '"';
			                        if ( isset( $option['brand'] ) && $option['brand'] == $opt['code'] ) {
				                        echo ' selected';
			                        }
			                        echo '>' . esc_attr( $opt['labels'][$akeneo->get_category_locale()] ) . '</option>';
		                        }
		                        ?>
                            </select>
                        </div>
                        <div class="col-md-5">
                            <?php
                            foreach ( $fields as $key => $field ) {
                                echo '<div class="form-check form-check-inline">';
                                echo '<input class="form-check-input" type="checkbox" id="alt_brand_'.$brand_number.'" name="alt_brands[' . ( $brand_number ) . '][' . $field['name'] . ']" value="1"';
                                if ( isset( $option[ $field['name'] ] ) && $option[ $field['name'] ] ) {
                                    echo ' checked';
                                }
                                echo '>';
                                echo '<label class="form-check-label" for="alt_brand_' . $brand_number . '">' . $field['label'] . '</label>';
                                echo '</div>';
                            }
                            ?>
                        </div>
                    </div>
					<?php
				}
			}
			?>
            </fieldset>
            <div class="col-12">
                <button type="submit" class="btn btn-primary">Save</button>
            </div>
        </form>

            </div>
        </div>
    </div>
</div>
<script>
    jQuery(function($){
        console.log('hello there steve');
        $('.mbek-delete-alt-brand').on('click', function(){
            console.log('clicked me!');
            console.log($(this).parents('.mbek-brand-row'));
            $(this).parents('.mbek-brand-row').remove();
        });
    });
</script>