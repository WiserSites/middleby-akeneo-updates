# Middleby Akeneo #
**Contributors:** wisersites  
**Tags:** Akeneo, Middleby, PIM  
**Requires at least:** 6.6  
**Tested up to:** 6.9.1  
**Stable tag:** 1.1.7  
**Requires PHP:** 8.3  
**License:** GPLv2 or later  
**License URI:** https://www.gnu.org/licenses/gpl-2.0.html  

PIM Integration from Akeneo

## Description ##

Plugin to Integrate the Akeneo PIM. Sync the product and or accessory data from PIM into the wordpress products.

## Installation ##

This section describes how to install the plugin and get it working.

1. Upload `middleby-akeneo` folder to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Run the Setup Wizard (coming)

## Frequently Asked Questions ##

## Screenshots ##


## Unit Testing ##

To run the unit tests, use the following command:

`composer test`

This command executes PHPUnit using the configuration defined in `phpunit.xml.dist`.

## If site is using a caching plugin ##
Add the following to exluded urls in the caching plugin settings:

/wp-json/as-api/v1/failed-tasks


## Changelog ##

### 1.1.8 ###

* Removed the unused `uuid` index from the database schema in `class.mbek.php`.

### 1.1.7 ###
* Added PhotoFeature synchronization for records missing at least one PhotoFeature ACF record.
* Added a new setting to enable or disable PhotoFeature synchronization.
* Refactored API settings to use hidden fields for token management.

### 1.1.6 ###
* Enhanced failed task query logic by adding a parameter for filtering tasks within the last 4 hours.
* Added multiple new CAD design file types to the product configuration.
* Improved data retrieval precision in PIM resource fetching.

### 1.1.5 ###
* Adjusted product update filter to use a precise 12-hour range for better synchronization reliability.
* Enhanced PIM action scheduling and product fetching processes for improved efficiency.
* Introduced functionality to create new WordPress posts directly from PIM data.
* Added methods to clear custom post type entries during data synchronization.
* Improved PIM data processing logic and overall code cleanup.
* Added unit tests for PIM data refresh, product fetching, and scheduling workflows.

### 1.1.4.1 ###
* Enhanced database schema by adding indexes to `uuid`, `updated`, and `post_type` fields for better performance.
* Optimized PIM synchronization query logic and SQL joins.
* Updated `MBEK_DB_VERSION` to `1.0.6`.
* Improved unit tests for database versioning.

### 1.1.4 ###
* Refactored `update_from_pim_table` and `mbek_sync_pim_table` to optimize PIM synchronization and pagination logic.
* Improved database query performance by ensuring explicit `ORDER BY ID ASC` in PIM data retrieval.
* Simplified PIM table update queries by removing redundant `UNION` operations.
* Added explicit global namespace for `error_log` and `trigger_error` calls for better reliability.
* Introduced `MBEK_PaginationTest` to ensure robust unit testing of synchronization pagination and query ordering.
* Added detailed logging for PIM table updates to improve traceability during synchronization.

### 1.1.3 ###
* Refactored `mbek_sync_pim_table` synchronization logic.
* Simplified Akeneo update checks by removing timezone conversion logic.
* Added error logging for exception handling in `pull_resources` and `sync_pim_table`.
* Updated tests to improve coverage for exception logging.
* Set scope handling during `array_merge` operations.
* Cleaned up unused Akeneo asset query logic.

### 1.1.2 ###
* Included `parent` in insert and update queries within import script.
* Ensured proper escaping for the `parent` and 'family' value.

### 1.1.1 ###
* Add REST endpoint to fetch recent failed tasks from Action Scheduler

### 1.1.0 ###
* Schedule 'delete_cpt_not_in_pim' action via Action scheduler for optimized execution.
* Add constants for pagination defaults and replace hardcoded values acress the plugin.
* Updated `delete_cpt_not_in_pim` and `delete_asset_cpt_not_in_pim` to utilize optimized SQL for batch deletions and schedule subsequent runs via Action Scheduler.
* Adjusted test suite to align with new pagination defaults and streamlined `MBEK_AdminTest`.
* Enhanced PIM synchronization to process data in smaller, controlled chunks for greater efficiency.
* Introduced `MBEK_Post_Type_ColumnsTest` to test custom admin column functionality, including hooks, column rendering, and sorting.
* Updated test bootstrap to include mock implementations of WordPress functions like `add_filter`, `add_action`, `get_post_meta`, and date helpers.
* Removed unused `trigger_error` calls in `class.mbek-admin.php` to clean up code.
* Replaced `TRUNCATE` calls with selective `DELETE` queries to preserve necessary data.
* Enhanced `save_brand_categories` and `save_pim_asset_data` with `ON DUPLICATE KEY UPDATE` for efficient database updates.
* Streamlined locale filtering logic for better maintainability.
* Improved code formatting and removed redundant comments for cleaner structure.
* Replaced `tinytext` fields with `varchar(100)` for improved consistency and indexing.
* Marked `code` fields as `UNIQUE` in database schemas.
* Updated `MBEK_DB_VERSION` to `1.0.5`.
* Refactored `get_brand_categories` by introducing a default value for `$first_run` and deprecating unused date filters for cleaner logic.
* Introduced `write_log` method for conditional debugging with `WP_DEBUG`.
* Refactored PIM sync queries to improve data handling efficiency by using `LEFT JOIN` with `postmeta` and `posts`.
* Added detailed logging for product creation, updates, and deletions to enhance traceability.
* Unified SQL queries for main and accessory updates by combining results using `UNION` for improved readability and efficiency.
* Streamlined scheduled actions to simplify parameter passing and handling.
* Removed redundant per-page handling and comparison queries in `mbek-admin`.
* Applied consistent logic for scheduling accessory synchronization tasks.
* Convert post modification timestamps to UTC for consistent PIM synchronization logic. Update scheduling logic to handle partial updates using `number` and `total` checks.

### 1.0.34 ###
* Add custom admin columns (PIM Data and Modified) for configured post types with sorting functionality.
* Add AJAX-based functionality to delete Custom Post Types (CPT) that are no longer in PIM.
* Update PIM data synchronization to cover any post status when deleting obsolete CPTs.
* Optimize PIM data processing by reducing chunk size for improved performance.
* Code cleanup: remove unused methods and obsolete functionalities.
* Test improvements: add PHPUnit tests for core library classes.

### 1.0.33 ###
* Update certain places where the en_US locale is required.

### 1.0.32 ###
* Category synchronization improvements: new settings, improved sync between PIM and WP, filters to prevent unintended category changes, and a fix for category deletion.
* Cron and cache: updated cron timestamp; refresh PIM data cache on first run; improvements to cache reload tooling.
* Update mechanism: updated Plugin Update Checker URL.
* Settings and maintenance updates.

### 1.0.31 ###
* Update for WooTab plugin integration for the 15 new PIM product feature fields.

### 1.0.30 ###
* Start work on creation of new Filters.
* Coding Standards for Wordpress and TODO list for en_US.
* Replace Hard coding of en_US within Settings.
* Update for WooTab plugin integration for the 15 new PIM product feature fields.

### 1.0.29 ###
* Remove E_NOTICE output.

### 1.0.28 ###
* Bug fix for issues with the sub cron parts from pull_products that calls pull_assets and pull_resources.

### 1.0.27 ###
* Can now exclude accessories from PIM if the Accessory flag is set and no post_type is set for accessories.
* When updating PIM categories: Will now set features

### 1.0.26 ###
* Update for delete cpt if use only uuid to delete any cpt without uuid
* Update list product option url
* Delete CPT for assets if no PIM assets exists
* Update the Readme file

### 1.0.25 ###
* Adding two new ajax methods for the mapping
* Replace magic number with DEFINE


### 1.0.24 ###
* Update to dropdown for asset mapping 'family'
* Update cron tools so they require nonce
* Update cron.js - code refactoring
* Add clearing of pim_data and the CPT used for products.
* Also add new setting to limit to one category for products.
* Add clearing of pim_asset table when purging pim_data.
* Add nonce checks for admin ajax calls.
* Add confirm to some of the Tools.

### 1.0.23 ###
* Updating code for check photos to deal with non repeater fields


### 1.0.22 ###
* Turning off the updating of category data from PIM
* Add screen in admin for checking that all CPT have featured photos


### 1.0.21 ###
* Woocommerce Action Schedule updated to version 3.7.2
* Tabulator list product view now has pagination and filtering for name, model and uuid columns
* Documentation Updates
* Setup Grunt and readme
* Updating Cron task

### 1.0.20 ###
* Update PHP Docs
* Cleanup and rename menu items
* Add page for Accessories
* Update woo action scheduler to v3.7.2
* Update Tabulator for list Products to add filtering for Title, Model and UUID
* Add Pagination to List Products (Tabulator)