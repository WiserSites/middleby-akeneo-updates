<?php
if ( function_exists( 'acf_add_options_sub_page' ) ) {
	acf_add_options_sub_page(
		array(
			'page_title'  => 'PIM Search Filters',
			'menu_title'  => 'PIM Search Filters',
			'menu_slug'   => 'mbek-filters-settings',
			'capability'  => 'manage_options',
			'redirect'    => false,
			'parent_slug' => 'mbek',
		)
	);
}
if ( function_exists( 'acf_add_options_sub_page' ) ) {
	add_action(
		'acf/init',
		function () {
			$allowed_pim_types = array(
				'pim_catalog_simpleselect',
				'pim_catalog_multiselect',
			);
			$main_attributes   = get_option( MBEK_ATTRIBUTES );
			$mapped_attributes = get_option( MBEK_ATTRIBUTE_MAPS );
			// $att_map_with_values = array_filter( $mapped_attributes, fn( $n ) => $n['value'] != '' );
			$filtered_attributes = ( is_array( $main_attributes ) ) ? array_filter( $main_attributes, fn( $n ) => in_array( $n['type'], $allowed_pim_types ) && $mapped_attributes[ $n['code'] ]['value'] != '' ) : array();

			$attr_types          = array();

			$pim_field_options = array();
			// echo '<pre>'.print_r($filtered_attributes, true).'</pre>';
			foreach ( $filtered_attributes as $attribute_label => $attribute_data ) {
				// if ( ! isset( $att_map_with_values[$attribute_label] ) ) {
				// continue;
				// }
				$attr_type[ $attribute_data['type'] ] = $attribute_data['type'];
				$label                                = isset( $attribute_data['labels']['en_US'] )
				? $attribute_data['labels']['en_US']
				: $attribute_data['reference_data_name'];
				// $title = isset( $attribute_data['labels']['en_US'] ) ? $attribute_data['labels']['en_US'] : $attribute_data['reference_data_name'];
				// $arr = array_values( array_filter( $mapped_attributes, fn( $n ) => $n['name'] === $attribute_label ) );
				$pim_field_options[ $attribute_label ] = $label;
			}
			// echo '<pre>'.print_r($attr_type, true).'</pre>';
			asort( $pim_field_options );
			// echo '<pre>'.print_r($pim_field_options, true).'</pre>';

			acf_add_local_field_group(
				array(
					'key'                   => 'group_mbek_1',
					'title'                 => 'Search Filters',
					'fields'                => array(
						array(
							'key'               => 'field_mbek_1',
							'label'             => 'PIM Search Filters',
							'name'              => 'mbek_pim_search_filters',
							'aria-label'        => '',
							'type'              => 'repeater',
							'instructions'      => '',
							'required'          => 0,
							'conditional_logic' => 0,
							'wrapper'           => array(
								'width' => '',
								'class' => '',
								'id'    => '',
							),
							'layout'            => 'block',
							'pagination'        => 0,
							'min'               => 0,
							'max'               => 0,
							'collapsed'         => '',
							'button_label'      => 'Add Filter',
							'rows_per_page'     => 20,
							'sub_fields'        => array(
								array(
									'key'               => 'field_mbek_2',
									'label'             => 'Label',
									'name'              => 'mbek_pim_search_label',
									'aria-label'        => '',
									'type'              => 'text',
									'instructions'      => '',
									'required'          => 0,
									'conditional_logic' => 0,
									'wrapper'           => array(
										'width' => '100',
										'class' => '',
										'id'    => '',
									),
									'default_value'     => '',
									'maxlength'         => '',
									'placeholder'       => '',
									'prepend'           => '',
									'append'            => '',
									'parent_repeater'   => 'field_mbek_1',
								),
								array(
									'key'               => 'field_mbek_3',
									'label'             => 'PIM Field',
									'name'              => 'mbek_pim_search_field_ref',
									'aria-label'        => '',
									'type'              => 'select',
									'choices'           => $pim_field_options,
									'allow_null'        => 1,
									'instructions'      => '',
									'required'          => 0,
									'conditional_logic' => 0,
									'wrapper'           => array(
										'width' => '100',
										'class' => '',
										'id'    => '',
									),
									'default_value'     => '',
									'maxlength'         => '',
									'placeholder'       => '',
									'prepend'           => '',
									'append'            => '',
									'parent_repeater'   => 'field_mbek_1',
								),
							),
						),
					),
					'location'              => array(
						array(
							array(
								'param'    => 'options_page',
								'operator' => '==',
								'value'    => 'mbek-filters-settings',
							),
						),
					),
					'menu_order'            => 0,
					'position'              => 'normal',
					'style'                 => 'default',
					'label_placement'       => 'top',
					'instruction_placement' => 'label',
					'hide_on_screen'        => '',
					'active'                => true,
					'description'           => '',
					'show_in_rest'          => 0,
				)
			);
		}
	);
}
